"""
コールセンター業務管理ダッシュボード Excel 生成スクリプト
"""
import os, sys, random

# stdout を UTF-8 に強制（CP932環境・セキュリティ制限環境対応）
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from datetime import date, datetime, timedelta
from openpyxl import Workbook
from openpyxl.styles import (
    PatternFill, Font, Alignment, Border, Side,
    numbers as opxl_numbers
)
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.series import SeriesLabel
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.drawing.image import Image as XLImage

# ─────────────── 定数・設定 ──────────────────────────────────────────────────
# PyInstaller .exe として実行中は sys.executable（.exe の場所）を使う
# 通常の python スクリプト実行時は __file__ を使う
if getattr(sys, "frozen", False):
    OUT_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_FILE  = os.path.join(OUT_DIR, "CallCenter_Dashboard.xlsx")

# データフォルダ（ブックと同階層）
DATA_ROOT = os.path.join(OUT_DIR, "data")

# ─────────────── カラーパレット ──────────────────────────────────────────────
C_YELLOW  = "FFFF99"   # 入力セル
C_GRAY    = "D9D9D9"   # ロックセル
C_BLUE_H  = "1F3864"   # ヘッダー濃紺
C_BLUE_L  = "DDEEFF"   # テーブル薄青
C_GREEN_H = "375623"   # 緑ヘッダー
C_GREEN_L = "E2EFDA"   # 緑薄
C_ORANGE  = "F4B942"   # 強調
C_WHITE   = "FFFFFF"
C_RED_L   = "FDECEA"   # 警告背景
C_ACCENT  = "2E75B6"   # グラフ青
C_ACCENT2 = "ED7D31"   # グラフ橙
C_PRED    = "BDD7EE"   # 予測薄青

# ─────────────── スタイルヘルパー ──────────────────────────────────────────
def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def font(bold=False, size=11, color="000000", name="Meiryo UI"):
    return Font(bold=bold, size=size, color=color, name=name)

def align(h="left", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def thin_border():
    s = Side(style="thin")
    return Border(left=s, right=s, top=s, bottom=s)

def medium_border():
    s = Side(style="medium")
    return Border(left=s, right=s, top=s, bottom=s)

def set_header(ws, row, col, text, bg=C_BLUE_H, fg=C_WHITE, sz=10, bold=True, h="center"):
    c = ws.cell(row=row, column=col, value=text)
    c.fill = fill(bg)
    c.font = font(bold=bold, size=sz, color=fg)
    c.alignment = align(h=h, v="center")
    c.border = thin_border()
    return c

def set_cell(ws, row, col, value, bg=C_WHITE, bold=False, sz=10,
             h="left", border=True, number_format=None, color="000000"):
    c = ws.cell(row=row, column=col, value=value)
    c.fill = fill(bg)
    c.font = font(bold=bold, size=sz, color=color)
    c.alignment = align(h=h, v="center")
    if border:
        c.border = thin_border()
    if number_format:
        c.number_format = number_format
    return c

def set_col_width(ws, col, width):
    ws.column_dimensions[get_column_letter(col)].width = width

def freeze(ws, cell="A2"):
    ws.freeze_panes = cell

# ─────────────── 祝日データ（2024〜2027） ──────────────────────────────────
HOLIDAYS = {
    # 2024年
    date(2024,1,1): "元日",
    date(2024,1,8): "成人の日",
    date(2024,2,11): "建国記念の日",
    date(2024,2,12): "振替休日",
    date(2024,2,23): "天皇誕生日",
    date(2024,3,20): "春分の日",
    date(2024,4,29): "昭和の日",
    date(2024,5,3): "憲法記念日",
    date(2024,5,4): "みどりの日",
    date(2024,5,5): "こどもの日",
    date(2024,5,6): "振替休日",
    date(2024,7,15): "海の日",
    date(2024,8,11): "山の日",
    date(2024,8,12): "振替休日",
    date(2024,9,16): "敬老の日",
    date(2024,9,22): "秋分の日",
    date(2024,9,23): "振替休日",
    date(2024,10,14): "スポーツの日",
    date(2024,11,3): "文化の日",
    date(2024,11,4): "振替休日",
    date(2024,11,23): "勤労感謝の日",
    # 2025年
    date(2025,1,1): "元日",
    date(2025,1,13): "成人の日",
    date(2025,2,11): "建国記念の日",
    date(2025,2,23): "天皇誕生日",
    date(2025,2,24): "振替休日",
    date(2025,3,20): "春分の日",
    date(2025,4,29): "昭和の日",
    date(2025,5,3): "憲法記念日",
    date(2025,5,4): "みどりの日",
    date(2025,5,5): "こどもの日",
    date(2025,5,6): "振替休日",
    date(2025,7,21): "海の日",
    date(2025,8,11): "山の日",
    date(2025,9,15): "敬老の日",
    date(2025,9,23): "秋分の日",
    date(2025,10,13): "スポーツの日",
    date(2025,11,3): "文化の日",
    date(2025,11,23): "勤労感謝の日",
    date(2025,11,24): "振替休日",
    # 2026年
    date(2026,1,1): "元日",
    date(2026,1,12): "成人の日",
    date(2026,2,11): "建国記念の日",
    date(2026,2,23): "天皇誕生日",
    date(2026,3,20): "春分の日",
    date(2026,4,29): "昭和の日",
    date(2026,5,3): "憲法記念日",
    date(2026,5,4): "みどりの日",
    date(2026,5,5): "こどもの日",
    date(2026,5,6): "振替休日",
    date(2026,7,20): "海の日",
    date(2026,8,11): "山の日",
    date(2026,9,21): "敬老の日",
    date(2026,9,22): "振替休日",
    date(2026,9,23): "秋分の日",
    date(2026,10,12): "スポーツの日",
    date(2026,11,3): "文化の日",
    date(2026,11,23): "勤労感謝の日",
    # 2027年
    date(2027,1,1): "元日",
    date(2027,1,11): "成人の日",
    date(2027,2,11): "建国記念の日",
    date(2027,2,23): "天皇誕生日",
    date(2027,3,21): "春分の日",
    date(2027,3,22): "振替休日",
    date(2027,4,29): "昭和の日",
    date(2027,5,3): "憲法記念日",
    date(2027,5,4): "みどりの日",
    date(2027,5,5): "こどもの日",
    date(2027,7,19): "海の日",
    date(2027,8,11): "山の日",
    date(2027,9,20): "敬老の日",
    date(2027,9,23): "秋分の日",
    date(2027,10,11): "スポーツの日",
    date(2027,11,3): "文化の日",
    date(2027,11,23): "勤労感謝の日",
}

CATEGORIES = [
    ("CAT001", "アカウント設定",   1),
    ("CAT002", "料金・請求",       2),
    ("CAT003", "解約・退会",       3),
    ("CAT004", "エラー・不具合",   4),
    ("CAT005", "ログイン・認証",   5),
    ("CAT006", "API連携",          6),
    ("CAT007", "パスワードリセット", 7),
    ("CAT008", "データ移行",       8),
    ("CAT009", "機能の使い方",     9),
    ("CAT010", "その他",           10),
]

CATEGORY_ALIASES = [
    ("アカウント設定",     "CAT001"),
    ("アカウント",         "CAT001"),
    ("account設定",       "CAT001"),
    ("料金",               "CAT002"),
    ("料金・請求",         "CAT002"),
    ("請求",               "CAT002"),
    ("解約",               "CAT003"),
    ("解約・退会",         "CAT003"),
    ("退会",               "CAT003"),
    ("エラー",             "CAT004"),
    ("不具合",             "CAT004"),
    ("障害",               "CAT004"),
    ("ログイン",           "CAT005"),
    ("認証",               "CAT005"),
    ("ログイン・認証",     "CAT005"),
    ("API",                "CAT006"),
    ("API連携",            "CAT006"),
    ("パスワード",         "CAT007"),
    ("PW",                 "CAT007"),
    ("データ移行",         "CAT008"),
    ("移行",               "CAT008"),
    ("使い方",             "CAT009"),
    ("操作方法",           "CAT009"),
    ("その他",             "CAT010"),
    ("その他・一般",       "CAT010"),
]

# ─────────────── カレンダー生成 ──────────────────────────────────────────────
def is_biz_day(d, holidays=HOLIDAYS):
    """営業日判定：土日祝以外=1"""
    return 0 if (d.weekday() >= 5 or d in holidays) else 1

def build_calendar(start=date(2024,4,1), end=date(2027,3,31)):
    rows = []
    d = start
    # 年度内通し番号
    fy_biz_counter = {}
    # 月内通し番号
    mon_biz_counter = {}
    # 週内カウンター（月の第何週・曜日）
    prev_fy = None
    prev_mon = None

    # 前処理：全日のis_biz_dayを計算
    all_days = []
    cur = start
    while cur <= end:
        all_days.append(cur)
        cur += timedelta(days=1)

    # 年度を判定する関数
    def get_fy(d):
        return d.year if d.month >= 4 else d.year - 1

    # カウンターをリセット
    fy_counters = {}
    mon_counters = {}

    for d in all_days:
        fy = get_fy(d)
        mon = (d.year, d.month)
        holiday_name = HOLIDAYS.get(d, "")
        is_b = is_biz_day(d)
        wd_num = d.weekday() + 1  # 1=月, 7=日
        wd_names = ["月","火","水","木","金","土","日"]
        wd = wd_names[d.weekday()]

        # 年度内営業日通し番号
        if fy not in fy_counters:
            fy_counters[fy] = 0
        if is_b:
            fy_counters[fy] += 1
        fy_biz_seq = fy_counters[fy] if is_b else None

        # 月内営業日通し番号
        if mon not in mon_counters:
            mon_counters[mon] = 0
        if is_b:
            mon_counters[mon] += 1
        mon_biz_seq = mon_counters[mon] if is_b else None

        # 月内第何週（1日を1週目として7日ごと）
        week_in_month = (d.day - 1) // 7 + 1

        rows.append({
            "date_key": d,
            "fy": f"FY{fy}",
            "ym_key": d.strftime("%Y%m"),
            "weekday": wd,
            "weekday_num": wd_num,
            "is_holiday": 1 if d in HOLIDAYS else 0,
            "holiday_name": holiday_name,
            "is_special_off": 0,
            "is_biz_day": is_b,
            "biz_day_seq": fy_biz_seq if is_b else "",
            "biz_day_seq_in_month": mon_biz_seq if is_b else "",
            "week_in_month": week_in_month,
        })
    return rows

CAL_DATA = build_calendar()

# 前年同営業日キー（Method A: 月内営業日通し番号）を計算
def add_prev_year_keys(cal_data):
    # インデックス作成：(ym_key, biz_day_seq_in_month) -> date
    idx_a = {}
    # インデックス作成：(ym_key, week_in_month, weekday_num) -> date
    idx_b = {}
    for row in cal_data:
        if row["is_biz_day"]:
            k_a = (row["ym_key"], row["biz_day_seq_in_month"])
            idx_a[k_a] = row["date_key"]
            k_b = (row["ym_key"], row["week_in_month"], row["weekday_num"])
            if k_b not in idx_b:
                idx_b[k_b] = row["date_key"]

    for row in cal_data:
        d = row["date_key"]
        # 前年同月
        try:
            py_month = date(d.year - 1, d.month, 1)
        except:
            py_month = None
        py_ym = py_month.strftime("%Y%m") if py_month else None

        # Method A
        if py_ym and row["biz_day_seq_in_month"]:
            row["prev_year_date_A"] = idx_a.get((py_ym, row["biz_day_seq_in_month"]), "")
        else:
            row["prev_year_date_A"] = ""

        # Method B
        if py_ym:
            row["prev_year_date_B"] = idx_b.get((py_ym, row["week_in_month"], row["weekday_num"]), "")
        else:
            row["prev_year_date_B"] = ""

    return cal_data

CAL_DATA = add_prev_year_keys(CAL_DATA)

# ─────────────── ダミーデータ生成 ──────────────────────────────────────────
random.seed(42)
BIZ_DAYS_FY = [r["date_key"] for r in CAL_DATA if r["is_biz_day"] and
               r["fy"] in ("FY2024", "FY2025") and
               r["date_key"] <= date(2026, 3, 30)]

# calllog ダミー
def gen_calllog(biz_days, n_per_day_in=(40,120), n_per_day_out=(20,60)):
    rows = []
    for d in biz_days:
        # 受電
        for _ in range(random.randint(*n_per_day_in)):
            h = random.choices(range(9,18), weights=[3,8,12,15,12,10,12,10,8])[0]
            m = random.randint(0,59)
            s = random.randint(0,59)
            start = datetime(d.year, d.month, d.day, h, m, s)
            ivr_sec = random.randint(3,15)
            talk_start_sec = ivr_sec + random.randint(2,10)
            dur = random.randint(30, 600)
            result = random.choices(["通話","不応答","放棄"], weights=[70,15,15])[0]
            rows.append({
                "発着": "着信",
                "発信番号": f"0{random.randint(1,9)}{random.randint(1000,9999)}-{random.randint(1000,9999)}",
                "着信番号": "0120-123-456",
                "開始": start.strftime("%Y-%m-%d %H:%M:%S"),
                "IVR応答": (start + timedelta(seconds=ivr_sec)).strftime("%Y-%m-%d %H:%M:%S"),
                "通話開始": (start + timedelta(seconds=talk_start_sec)).strftime("%Y-%m-%d %H:%M:%S"),
                "終了": (start + timedelta(seconds=talk_start_sec + dur)).strftime("%Y-%m-%d %H:%M:%S"),
                "呼び出し結果": result,
            })
        # 発信
        for _ in range(random.randint(*n_per_day_out)):
            h = random.choices(range(9,18), weights=[5,10,12,14,12,10,10,10,7])[0]
            m = random.randint(0,59)
            s = random.randint(0,59)
            start = datetime(d.year, d.month, d.day, h, m, s)
            dur = random.randint(20, 480)
            result = random.choices(["通話","不応答"], weights=[65,35])[0]
            rows.append({
                "発着": "発信",
                "発信番号": "0120-123-456",
                "着信番号": f"0{random.randint(1,9)}{random.randint(1000,9999)}-{random.randint(1000,9999)}",
                "開始": start.strftime("%Y-%m-%d %H:%M:%S"),
                "IVR応答": "",
                "通話開始": (start + timedelta(seconds=random.randint(5,30))).strftime("%Y-%m-%d %H:%M:%S"),
                "終了": (start + timedelta(seconds=dur)).strftime("%Y-%m-%d %H:%M:%S"),
                "呼び出し結果": result,
            })
    return rows

# inquiry ダミー
def gen_inquiry(biz_days):
    rows = []
    cats = [c[1] for c in CATEGORIES]
    weights = [10,15,8,20,12,5,10,5,10,5]
    staff = ["田中 一郎", "鈴木 花子", "山田 太郎", "佐藤 めぐみ", "伊藤 健"]
    statuses = ["完了","完了","完了","解決","対応中","保留","未対応"]
    for d in biz_days:
        n = random.randint(30, 90)
        for _ in range(n):
            h = random.choices(range(9,18), weights=[3,8,12,14,12,10,11,10,8])[0]
            m = random.randint(0,59)
            dt = datetime(d.year, d.month, d.day, h, m)
            cat = random.choices(cats, weights=weights)[0]
            rows.append({
                "受付日時": dt.strftime("%Y-%m-%d %H:%M"),
                "カテゴリ": cat,
                "対応時間（分）": round(random.uniform(1, 45), 1),
                "ステータス": random.choice(statuses),
                "担当者": random.choice(staff),
                "優先度": random.choices(["高","中","低"], weights=[20,50,30])[0],
            })
    return rows

# FY2025（2025/4/1〜2026/3/31）の営業日
BIZ_FY2025 = [r["date_key"] for r in CAL_DATA if r["is_biz_day"] and
              r["fy"] == "FY2025" and r["date_key"] <= date(2026,3,30)]
BIZ_FY2024 = [r["date_key"] for r in CAL_DATA if r["is_biz_day"] and
              r["fy"] == "FY2024"]

CALLLOG_FY  = gen_calllog(BIZ_FY2025)
CALLLOG_LY  = gen_calllog(BIZ_FY2024, n_per_day_in=(35,110), n_per_day_out=(18,55))
INQUIRY_FY  = gen_inquiry(BIZ_FY2025)
INQUIRY_LY  = gen_inquiry(BIZ_FY2024)

print(f"calllog FY: {len(CALLLOG_FY)} rows")
print(f"calllog LY: {len(CALLLOG_LY)} rows")
print(f"inquiry FY: {len(INQUIRY_FY)} rows")
print(f"inquiry LY: {len(INQUIRY_LY)} rows")

# ─────────────── 集計：日別 ──────────────────────────────────────────────────
from collections import defaultdict

def agg_daily_call(records):
    """date -> {IN: n, OUT: n}"""
    d = defaultdict(lambda: {"IN": 0, "OUT": 0})
    for r in records:
        dt = datetime.strptime(r["開始"], "%Y-%m-%d %H:%M:%S").date()
        key = r["発着"]
        if key == "着信":
            d[dt]["IN"] += 1
        else:
            d[dt]["OUT"] += 1
    return dict(d)

def agg_hourly_call(records, target_date):
    """hour -> {IN: n, OUT: n}"""
    d = defaultdict(lambda: {"IN": 0, "OUT": 0})
    for r in records:
        dt = datetime.strptime(r["開始"], "%Y-%m-%d %H:%M:%S")
        if dt.date() != target_date:
            continue
        h = dt.hour
        if r["発着"] == "着信":
            d[h]["IN"] += 1
        else:
            d[h]["OUT"] += 1
    return dict(d)

def agg_daily_cat(records):
    """date -> {cat: n}"""
    d = defaultdict(lambda: defaultdict(int))
    for r in records:
        dt = datetime.strptime(r["受付日時"], "%Y-%m-%d %H:%M").date()
        d[dt][r["カテゴリ"]] += 1
    return dict(d)

DAILY_FY  = agg_daily_call(CALLLOG_FY)
DAILY_LY  = agg_daily_call(CALLLOG_LY)
DAILY_CAT = agg_daily_cat(INQUIRY_FY)

# 基準日：今日
BASE_DATE = date(2026, 3, 30)  # 今日をベースに

# ─────────────── ワークブック作成 ────────────────────────────────────────────
wb = Workbook()
wb.remove(wb.active)

# ================================================================
# Sheet 1: Dashboard
# ================================================================
def make_dashboard(wb):
    ws = wb.create_sheet("Dashboard")
    ws.sheet_view.showGridLines = False

    # ── 列幅設定
    col_widths = [2, 14, 14, 14, 14, 14, 14, 14, 14, 14, 2]
    for i, w in enumerate(col_widths, 1):
        set_col_width(ws, i, w)

    # ── 行高
    for r in range(1, 80):
        ws.row_dimensions[r].height = 18

    ws.row_dimensions[1].height = 8
    ws.row_dimensions[2].height = 40
    ws.row_dimensions[3].height = 22
    ws.row_dimensions[4].height = 20
    ws.row_dimensions[5].height = 10
    ws.row_dimensions[6].height = 28
    ws.row_dimensions[7].height = 22
    ws.row_dimensions[8].height = 22
    ws.row_dimensions[9].height = 22
    ws.row_dimensions[10].height = 10

    # ── タイトルバー (R2)
    ws.merge_cells("B2:J2")
    c = ws["B2"]
    c.value = "📊 コールセンター 業務管理ダッシュボード"
    c.fill = fill(C_BLUE_H)
    c.font = Font(bold=True, size=16, color=C_WHITE, name="Meiryo UI")
    c.alignment = align(h="left", v="center")

    # ── 操作案内バー (R3)
    ws.merge_cells("B3:J3")
    c = ws["B3"]
    c.value = "【更新手順】 ①data/calllog/FY フォルダへCSV投入　②data/toiawase/FYへCSV投入　③[データ]→[すべて更新]　④ このシートで確認"
    c.fill = fill("FFF2CC")
    c.font = Font(bold=False, size=9.5, color="7F6000", name="Meiryo UI")
    c.alignment = align(h="left", v="center")

    # ── 設定行 (R4)
    ws["B4"].value = "基準日:"
    ws["B4"].font = font(bold=True, size=10)
    ws["B4"].alignment = align(h="right")

    ws["C4"].value = BASE_DATE
    ws["C4"].fill = fill(C_YELLOW)
    ws["C4"].font = font(bold=True, size=11)
    ws["C4"].number_format = "yyyy/mm/dd"
    ws["C4"].alignment = align(h="center")
    ws["C4"].border = medium_border()

    ws["E4"].value = "比較方法:"
    ws["E4"].font = font(bold=True, size=10)
    ws["E4"].alignment = align(h="right")

    ws["F4"].value = "A:月内営業日順"
    ws["F4"].fill = fill(C_YELLOW)
    ws["F4"].font = font(bold=True, size=10)
    ws["F4"].alignment = align(h="center")
    ws["F4"].border = medium_border()
    dv = DataValidation(type="list", formula1='"A:月内営業日順,B:同月同週同曜日"', showDropDown=False)
    ws.add_data_validation(dv)
    dv.add(ws["F4"])

    ws["H4"].value = "最終更新:"
    ws["H4"].font = font(size=9)
    ws["H4"].alignment = align(h="right")
    ws["I4"].value = datetime.now()
    ws["I4"].number_format = "yyyy/mm/dd HH:MM"
    ws["I4"].font = font(size=9, color="595959")

    # ── KPIカード セクションタイトル
    ws.merge_cells("B6:J6")
    c = ws["B6"]
    c.value = "▼ 当日 KPI（基準日の実績）"
    c.fill = fill(C_BLUE_H)
    c.font = Font(bold=True, size=11, color=C_WHITE, name="Meiryo UI")
    c.alignment = align(h="left", v="center")

    # KPIカード4枚：受電件数 / 発信件数 / 前年比(受) / 前年比(発)
    today_in  = DAILY_FY.get(BASE_DATE, {}).get("IN", 0)
    today_out = DAILY_FY.get(BASE_DATE, {}).get("OUT", 0)
    # 前年同日（Method A で引く）
    prev_date = None
    for row in CAL_DATA:
        if row["date_key"] == BASE_DATE:
            prev_date = row.get("prev_year_date_A") or row.get("prev_year_date_B")
            break
    prev_in  = DAILY_LY.get(prev_date, {}).get("IN", 0) if prev_date else 0
    prev_out = DAILY_LY.get(prev_date, {}).get("OUT", 0) if prev_date else 0
    diff_in  = today_in - prev_in
    diff_out = today_out - prev_out
    pct_in   = (diff_in / prev_in * 100) if prev_in else 0
    pct_out  = (diff_out / prev_out * 100) if prev_out else 0

    kpi_cards = [
        ("B", "D", "総受電件数", today_in, "件", "2E75B6"),
        ("E", "F", "総発信件数", today_out, "件", "ED7D31"),
        ("G", "H", f"前年比（受電）", f"{diff_in:+d} ({pct_in:+.1f}%)", "", "375623" if diff_in >= 0 else "C00000"),
        ("I", "J", f"前年比（発信）", f"{diff_out:+d} ({pct_out:+.1f}%)", "", "375623" if diff_out >= 0 else "C00000"),
    ]

    kpi_row_label = 7
    kpi_row_val   = 8
    kpi_row_unit  = 9

    for (c1, c2, label, val, unit, vcolor) in kpi_cards:
        # ラベル
        if c1 != c2:
            ws.merge_cells(f"{c1}{kpi_row_label}:{c2}{kpi_row_label}")
            ws.merge_cells(f"{c1}{kpi_row_val}:{c2}{kpi_row_val}")
            ws.merge_cells(f"{c1}{kpi_row_unit}:{c2}{kpi_row_unit}")
        cell_l = ws[f"{c1}{kpi_row_label}"]
        cell_l.value = label
        cell_l.fill = fill("EBF3FB")
        cell_l.font = Font(bold=False, size=9, color="595959", name="Meiryo UI")
        cell_l.alignment = align(h="center")
        cell_l.border = thin_border()

        cell_v = ws[f"{c1}{kpi_row_val}"]
        cell_v.value = val
        cell_v.fill = fill(C_WHITE)
        cell_v.font = Font(bold=True, size=20, color=vcolor, name="Meiryo UI")
        cell_v.alignment = align(h="center")
        cell_v.border = thin_border()

        cell_u = ws[f"{c1}{kpi_row_unit}"]
        cell_u.value = unit
        cell_u.fill = fill("EBF3FB")
        cell_u.font = Font(bold=False, size=9, color="595959", name="Meiryo UI")
        cell_u.alignment = align(h="center")
        cell_u.border = thin_border()

    # ── 折れ線グラフ用データ（集計_中間シートから参照する想定のダミー）
    # 過去30日の実績
    past_30 = sorted([d for d in DAILY_FY if d <= BASE_DATE])[-30:]
    # 未来30日の予測（前年同営業日から引く）
    future_dates = []
    cur = BASE_DATE + timedelta(days=1)
    cnt = 0
    while cnt < 30:
        future_dates.append(cur)
        cur += timedelta(days=1)
        cnt += 1

    # グラフデータを隠しエリアに書き込む（R50以降）
    chart_data_start = 50
    ws.cell(row=chart_data_start, column=2, value="日付")
    ws.cell(row=chart_data_start, column=3, value="受電(実績)")
    ws.cell(row=chart_data_start, column=4, value="発信(実績)")
    ws.cell(row=chart_data_start, column=5, value="受電(前年)")
    ws.cell(row=chart_data_start, column=6, value="受電(予測)")

    for i, d in enumerate(past_30):
        row = chart_data_start + 1 + i
        ws.cell(row=row, column=2, value=d).number_format = "mm/dd"
        ws.cell(row=row, column=3, value=DAILY_FY.get(d, {}).get("IN", 0))
        ws.cell(row=row, column=4, value=DAILY_FY.get(d, {}).get("OUT", 0))
        # 前年同日
        pyd = None
        for calrow in CAL_DATA:
            if calrow["date_key"] == d:
                pyd = calrow.get("prev_year_date_A")
                break
        ws.cell(row=row, column=5, value=DAILY_LY.get(pyd, {}).get("IN", 0) if pyd else None)
        ws.cell(row=row, column=6, value=None)  # 過去は予測なし

    pred_start_row = chart_data_start + 1 + len(past_30)
    for i, d in enumerate(future_dates):
        row = pred_start_row + i
        ws.cell(row=row, column=2, value=d).number_format = "mm/dd"
        ws.cell(row=row, column=3, value=None)
        ws.cell(row=row, column=4, value=None)
        pyd = None
        for calrow in CAL_DATA:
            if calrow["date_key"] == d:
                pyd = calrow.get("prev_year_date_A")
                break
        pred_in = DAILY_LY.get(pyd, {}).get("IN") if pyd else None
        ws.cell(row=row, column=5, value=None)
        ws.cell(row=row, column=6, value=pred_in)

    total_chart_rows = len(past_30) + len(future_dates)

    # 折れ線グラフ作成
    lc = LineChart()
    lc.title = "受電・発信 件数推移（過去30日＋未来30日予測）"
    lc.style = 10
    lc.height = 10
    lc.width  = 22
    lc.y_axis.title = "件数"
    lc.x_axis.title = "日付"

    data_ref = Reference(ws,
        min_col=3, min_row=chart_data_start,
        max_col=6, max_row=chart_data_start + total_chart_rows)
    lc.add_data(data_ref, titles_from_data=True)

    dates_ref = Reference(ws,
        min_col=2, min_row=chart_data_start + 1,
        max_row=chart_data_start + total_chart_rows)
    lc.set_categories(dates_ref)

    # 系列スタイル
    series_colors = [C_ACCENT, C_ACCENT2, "A9C4E2", C_PRED]
    for i, s in enumerate(lc.series):
        s.graphicalProperties.line.width = 18000
        if i == 3:  # 予測
            s.graphicalProperties.line.dashDot = "dash"

    ws.add_chart(lc, "B12")

    # 時間帯別棒グラフ
    hourly = agg_hourly_call(CALLLOG_FY, BASE_DATE)
    hourly_start = chart_data_start + total_chart_rows + 3
    ws.cell(row=hourly_start, column=2, value="時間帯")
    ws.cell(row=hourly_start, column=3, value="受電")
    ws.cell(row=hourly_start, column=4, value="発信")
    for h in range(9, 19):
        row = hourly_start + 1 + (h - 9)
        ws.cell(row=row, column=2, value=f"{h}:00")
        ws.cell(row=row, column=3, value=hourly.get(h, {}).get("IN", 0))
        ws.cell(row=row, column=4, value=hourly.get(h, {}).get("OUT", 0))

    bc = BarChart()
    bc.type = "col"
    bc.grouping = "clustered"
    bc.title = "時間帯別 受電・発信件数（当日）"
    bc.style = 10
    bc.height = 10
    bc.width  = 14
    bc.y_axis.title = "件数"

    bar_data = Reference(ws,
        min_col=3, min_row=hourly_start,
        max_col=4, max_row=hourly_start + 10)
    bc.add_data(bar_data, titles_from_data=True)
    cats_ref = Reference(ws,
        min_col=2, min_row=hourly_start + 1,
        max_row=hourly_start + 10)
    bc.set_categories(cats_ref)
    ws.add_chart(bc, "G12")

    # 分類別ランキング（横棒）
    ws.merge_cells("B33:J33")
    title_c = ws["B33"]
    title_c.value = "▼ 当日 問い合わせ分類別件数 Top10"
    title_c.fill = fill(C_BLUE_H)
    title_c.font = Font(bold=True, size=11, color=C_WHITE, name="Meiryo UI")
    title_c.alignment = align(h="left", v="center")

    day_cats = DAILY_CAT.get(BASE_DATE, {})
    sorted_cats = sorted(day_cats.items(), key=lambda x: -x[1])[:10]

    rank_headers = ["順位", "分類", "件数", "構成比（棒）"]
    rank_cols = [2, 3, 6, 7]
    for col, h in zip(rank_cols, rank_headers):
        set_header(ws, 34, col, h)
    ws.merge_cells("C34:E34")

    total_cat = sum(v for _, v in sorted_cats) or 1
    for i, (cat, cnt) in enumerate(sorted_cats):
        row = 35 + i
        set_cell(ws, row, 2, i+1, h="center", bold=(i==0))
        ws.merge_cells(f"C{row}:E{row}")
        set_cell(ws, row, 3, cat)
        set_cell(ws, row, 6, cnt, h="center")
        # 構成比バー（REPT数式）
        pct = cnt / total_cat
        bar_text = "■" * int(pct * 20)
        ws.merge_cells(f"G{row}:J{row}")
        bar_cell = ws.cell(row=row, column=7, value=bar_text)
        bar_cell.font = Font(color=C_ACCENT, name="Meiryo UI", size=10)
        bar_cell.fill = fill("F2F9FF")
        pct_cell = ws.cell(row=row, column=9)  # already merged

    return ws

ws_db = make_dashboard(wb)

# ================================================================
# Sheet 2: 元データ_今年度
# ================================================================
def make_rawdata(wb, sheet_name, calllog_rows, inquiry_rows):
    ws = wb.create_sheet(sheet_name)
    ws.sheet_view.showGridLines = True

    # ─ calllog テーブル
    call_headers = ["発着","発信番号","着信番号","開始","IVR応答","通話開始","終了","呼び出し結果"]
    tbl_name = "tbl_calllog_fy_raw" if "今年度" in sheet_name else "tbl_calllog_ly_raw"

    # ヘッダー行
    for col, h in enumerate(call_headers, 1):
        set_header(ws, 1, col, h, bg=C_BLUE_H)
        set_col_width(ws, col, 20)

    for row_i, r in enumerate(calllog_rows[:5000], 2):  # 最大5000行（サンプル）
        for col_i, key in enumerate(call_headers, 1):
            c = ws.cell(row=row_i, column=col_i, value=r[key])
            c.font = Font(size=9, name="Meiryo UI")
            c.alignment = Alignment(horizontal="left")

    # Excel Table 定義
    last_row = min(len(calllog_rows), 5000) + 1
    tbl = Table(
        displayName=tbl_name,
        ref=f"A1:{get_column_letter(len(call_headers))}{last_row}"
    )
    style = TableStyleInfo(
        name="TableStyleMedium2",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False
    )
    tbl.tableStyleInfo = style
    ws.add_table(tbl)

    # ─ inquiry テーブル（calllogの右に少し空けて配置）
    inq_col_start = len(call_headers) + 2  # 1列空ける
    inq_headers = ["受付日時","カテゴリ","対応時間（分）","ステータス","担当者","優先度"]
    inq_tbl_name = "tbl_toiawase_fy_raw" if "今年度" in sheet_name else "tbl_toiawase_ly_raw"

    for col, h in enumerate(inq_headers, inq_col_start):
        set_header(ws, 1, col, h, bg=C_GREEN_H)
        set_col_width(ws, col, 20)

    for row_i, r in enumerate(inquiry_rows[:5000], 2):
        for col_j, key in enumerate(inq_headers, inq_col_start):
            c = ws.cell(row=row_i, column=col_j, value=r[key])
            c.font = Font(size=9, name="Meiryo UI")

    inq_last_row = min(len(inquiry_rows), 5000) + 1
    inq_ref_start = get_column_letter(inq_col_start)
    inq_ref_end   = get_column_letter(inq_col_start + len(inq_headers) - 1)
    tbl2 = Table(
        displayName=inq_tbl_name,
        ref=f"{inq_ref_start}1:{inq_ref_end}{inq_last_row}"
    )
    tbl2.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium7",
        showRowStripes=True
    )
    ws.add_table(tbl2)

    # 凡例メモ
    note_col = inq_col_start + len(inq_headers) + 1
    ws.cell(row=1, column=note_col, value="※ Power Query更新後に自動反映されます")
    ws.cell(row=1, column=note_col).font = Font(size=9, color="595959", italic=True, name="Meiryo UI")
    ws.cell(row=2, column=note_col, value="※ このシートは直接編集しないでください")
    ws.cell(row=2, column=note_col).font = Font(size=9, color="C00000", bold=True, name="Meiryo UI")

    freeze(ws, "A2")
    return ws

ws_fy = make_rawdata(wb, "元データ_今年度", CALLLOG_FY, INQUIRY_FY)
ws_ly = make_rawdata(wb, "元データ_前年度", CALLLOG_LY, INQUIRY_LY)

# ================================================================
# Sheet 3: 集計_中間
# ================================================================
def make_agg(wb):
    ws = wb.create_sheet("集計_中間")
    ws.sheet_view.showGridLines = True

    # ── 日別集計（calllog）
    set_header(ws, 1, 1, "▼ 日別受発信集計（agg_daily_call_fy）", bg=C_BLUE_H, sz=11)
    ws.merge_cells("A1:G1")

    headers_d = ["日付","受電件数","発信件数","前年受電","前年発信","前年比受電(件)","前年比受電(%)"]
    for ci, h in enumerate(headers_d, 1):
        set_header(ws, 2, ci, h)
        set_col_width(ws, ci, 16)

    # カレンダー逆引き用
    cal_by_date = {r["date_key"]: r for r in CAL_DATA}

    sorted_dates = sorted(DAILY_FY.keys())
    for ri, d in enumerate(sorted_dates, 3):
        in_c  = DAILY_FY[d].get("IN", 0)
        out_c = DAILY_FY[d].get("OUT", 0)
        cal_row = cal_by_date.get(d, {})
        pyd_a = cal_row.get("prev_year_date_A")
        prev_in  = DAILY_LY.get(pyd_a, {}).get("IN", 0) if pyd_a else 0
        prev_out = DAILY_LY.get(pyd_a, {}).get("OUT", 0) if pyd_a else 0
        diff = in_c - prev_in
        pct  = round((diff / prev_in * 100), 1) if prev_in else None

        ws.cell(row=ri, column=1, value=d).number_format = "yyyy/mm/dd"
        ws.cell(row=ri, column=2, value=in_c)
        ws.cell(row=ri, column=3, value=out_c)
        ws.cell(row=ri, column=4, value=prev_in)
        ws.cell(row=ri, column=5, value=prev_out)
        ws.cell(row=ri, column=6, value=diff)
        ws.cell(row=ri, column=7, value=pct)

    # Excel Table
    last_agg_row = 2 + len(sorted_dates)
    tbl_agg = Table(displayName="tbl_agg_daily_call",
                    ref=f"A2:G{last_agg_row}")
    tbl_agg.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
    ws.add_table(tbl_agg)

    # ── 時間帯別集計（選択日）
    col_h = 9
    set_header(ws, 1, col_h, "▼ 時間帯別集計（agg_hourly_call）", bg=C_GREEN_H, sz=11)
    ws.merge_cells(f"{get_column_letter(col_h)}1:{get_column_letter(col_h+3)}1")
    headers_h = ["日付","時間帯","受電","発信"]
    for ci, h in enumerate(headers_h, col_h):
        set_header(ws, 2, ci, h)
        set_col_width(ws, ci, 14)

    hourly_all = defaultdict(lambda: defaultdict(lambda: {"IN": 0, "OUT": 0}))
    for r in CALLLOG_FY:
        dt = datetime.strptime(r["開始"], "%Y-%m-%d %H:%M:%S")
        hourly_all[dt.date()][dt.hour]["IN" if r["発着"]=="着信" else "OUT"] += 1

    row_h = 3
    for d in sorted(hourly_all.keys())[-30:]:  # 最近30日分
        for h in range(9, 19):
            ws.cell(row=row_h, column=col_h,   value=d).number_format = "yyyy/mm/dd"
            ws.cell(row=row_h, column=col_h+1, value=h)
            ws.cell(row=row_h, column=col_h+2, value=hourly_all[d][h]["IN"])
            ws.cell(row=row_h, column=col_h+3, value=hourly_all[d][h]["OUT"])
            row_h += 1

    # ── 分類別集計
    col_c = col_h + 5
    set_header(ws, 1, col_c, "▼ 分類別集計（agg_daily_category）", bg="7B2C8E", fg=C_WHITE, sz=11)
    ws.merge_cells(f"{get_column_letter(col_c)}1:{get_column_letter(col_c+2)}1")
    headers_c = ["日付","カテゴリ","件数"]
    for ci, h in enumerate(headers_c, col_c):
        set_header(ws, 2, ci, h)
        set_col_width(ws, ci, 18)

    row_c = 3
    for d in sorted(DAILY_CAT.keys())[-30:]:
        for cat, cnt in sorted(DAILY_CAT[d].items(), key=lambda x: -x[1]):
            ws.cell(row=row_c, column=col_c,   value=d).number_format = "yyyy/mm/dd"
            ws.cell(row=row_c, column=col_c+1, value=cat)
            ws.cell(row=row_c, column=col_c+2, value=cnt)
            row_c += 1

    freeze(ws, "A3")
    return ws

ws_agg = make_agg(wb)

# ================================================================
# Sheet 4: マスタ/設定
# ================================================================
def make_master(wb):
    ws = wb.create_sheet("マスタ_設定")
    ws.sheet_view.showGridLines = True

    # ─────── セクション1：フォルダパス設定 (tbl_settings) ──────
    set_header(ws, 1, 1, "【設定1】フォルダパス設定（tbl_settings）", bg=C_BLUE_H, sz=11)
    ws.merge_cells("A1:D1")

    set_header(ws, 2, 1, "キー")
    set_header(ws, 2, 2, "パス（絶対パスを入力）")
    set_header(ws, 2, 3, "説明")
    set_header(ws, 2, 4, "入力例")
    set_col_width(ws, 1, 22)
    set_col_width(ws, 2, 45)
    set_col_width(ws, 3, 28)
    set_col_width(ws, 4, 38)

    path_settings = [
        ("calllog_fy_path",    f"{DATA_ROOT}\\calllog\\FY",    "今年度 calllog CSVフォルダ",   r"C:\Users\...\data\calllog\FY"),
        ("calllog_ly_path",    f"{DATA_ROOT}\\calllog\\LY",    "前年度 calllog CSVフォルダ",   r"C:\Users\...\data\calllog\LY"),
        ("toiawase_fy_path",   f"{DATA_ROOT}\\toiawase\\FY",   "今年度 toiawase CSVフォルダ",  r"C:\Users\...\data\toiawase\FY"),
        ("toiawase_ly_path",   f"{DATA_ROOT}\\toiawase\\LY",   "前年度 toiawase CSVフォルダ",  r"C:\Users\...\data\toiawase\LY"),
    ]
    for ri, (key, path, desc, example) in enumerate(path_settings, 3):
        set_cell(ws, ri, 1, key, bold=True)
        c = set_cell(ws, ri, 2, path, bg=C_YELLOW)
        c.border = medium_border()
        set_cell(ws, ri, 3, desc, color="595959")
        set_cell(ws, ri, 4, example, color="888888")

    tbl_s = Table(displayName="tbl_settings", ref=f"A2:D{2+len(path_settings)}")
    tbl_s.tableStyleInfo = TableStyleInfo(name="TableStyleLight1", showRowStripes=True)
    ws.add_table(tbl_s)

    # ─────── セクション2：カレンダー (tbl_calendar) ──────────
    cal_start_row = 10
    set_header(ws, cal_start_row, 1, "【設定2】営業日カレンダー（tbl_calendar）", bg=C_BLUE_H, sz=11)
    ws.merge_cells(f"A{cal_start_row}:P{cal_start_row}")

    cal_headers = [
        "date_key","fy","ym_key","weekday","weekday_num",
        "is_holiday","holiday_name","is_special_off","is_biz_day",
        "biz_day_seq","biz_day_seq_in_month","week_in_month",
        "prev_year_date_A","prev_year_date_B",
        # 追加：特別休業入力用
        "特別休業理由（任意）",
    ]
    for ci, h in enumerate(cal_headers, 1):
        set_header(ws, cal_start_row+1, ci, h)
        ws.column_dimensions[get_column_letter(ci)].width = 18

    # 今年度・前年度のみ出力（FY2024〜FY2026）
    cal_rows_out = [r for r in CAL_DATA if r["fy"] in ("FY2024","FY2025","FY2026")]
    for ri, row in enumerate(cal_rows_out, cal_start_row+2):
        vals = [
            row["date_key"],
            row["fy"],
            row["ym_key"],
            row["weekday"],
            row["weekday_num"],
            row["is_holiday"],
            row["holiday_name"],
            row["is_special_off"],
            row["is_biz_day"],
            row.get("biz_day_seq",""),
            row.get("biz_day_seq_in_month",""),
            row["week_in_month"],
            row.get("prev_year_date_A",""),
            row.get("prev_year_date_B",""),
            "",  # 特別休業理由（手入力欄）
        ]
        for ci, v in enumerate(vals, 1):
            c = ws.cell(row=ri, column=ci, value=v)
            c.font = Font(size=9, name="Meiryo UI")
            if ci == 1 and isinstance(v, date):
                c.number_format = "yyyy/mm/dd"
            if ci in (13, 14) and isinstance(v, date):
                c.number_format = "yyyy/mm/dd"
            # 祝日行は薄赤
            if row["is_holiday"] or row["is_biz_day"] == 0:
                c.fill = fill("FFF0F0") if row["is_holiday"] else fill("F5F5F5")
            # 特別休業入力セル（is_special_off 列と 理由列）
            if ci in (8, 15):
                c.fill = fill(C_YELLOW)
                c.border = thin_border()

    cal_last_row = cal_start_row + 1 + len(cal_rows_out)
    tbl_cal = Table(displayName="tbl_calendar",
                    ref=f"A{cal_start_row+1}:O{cal_last_row}")
    tbl_cal.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
    ws.add_table(tbl_cal)

    ws.cell(row=cal_start_row+1, column=15).fill = fill(C_YELLOW)

    # ─────── セクション3：分類マスタ (tbl_category_master) ──────
    # 右側（列17〜）に配置
    cat_col = 17
    cat_start_row = 10
    set_header(ws, cat_start_row, cat_col, "【設定3】分類マスタ（tbl_category_master）", bg=C_GREEN_H, sz=11)
    ws.merge_cells(f"{get_column_letter(cat_col)}{cat_start_row}:{get_column_letter(cat_col+3)}{cat_start_row}")

    cat_headers = ["category_id","category_name","sort_order","備考（任意）"]
    for ci, h in enumerate(cat_headers, cat_col):
        set_header(ws, cat_start_row+1, ci, h, bg=C_GREEN_H)
        ws.column_dimensions[get_column_letter(ci)].width = 20

    for ri, (cid, cname, sort) in enumerate(CATEGORIES, cat_start_row+2):
        set_cell(ws, ri, cat_col,   cid)
        c = set_cell(ws, ri, cat_col+1, cname, bg=C_YELLOW)
        c.border = medium_border()
        set_cell(ws, ri, cat_col+2, sort, h="center")
        set_cell(ws, ri, cat_col+3, "", bg=C_YELLOW)  # 備考入力可

    tbl_cat = Table(
        displayName="tbl_category_master",
        ref=f"{get_column_letter(cat_col)}{cat_start_row+1}:{get_column_letter(cat_col+3)}{cat_start_row+1+len(CATEGORIES)}"
    )
    tbl_cat.tableStyleInfo = TableStyleInfo(name="TableStyleMedium14", showRowStripes=True)
    ws.add_table(tbl_cat)

    # ─────── セクション4：表記ゆれ対応表 (tbl_category_alias) ──────
    alias_col = cat_col
    alias_start = cat_start_row + len(CATEGORIES) + 4
    set_header(ws, alias_start, alias_col, "【設定4】表記ゆれ対応表（tbl_category_alias）", bg=C_GREEN_H, sz=11)
    ws.merge_cells(f"{get_column_letter(alias_col)}{alias_start}:{get_column_letter(alias_col+2)}{alias_start}")

    alias_headers = ["alias（CSV上の表記）","category_id","備考"]
    for ci, h in enumerate(alias_headers, alias_col):
        set_header(ws, alias_start+1, ci, h, bg=C_GREEN_H)

    for ri, (alias, cid) in enumerate(CATEGORY_ALIASES, alias_start+2):
        set_cell(ws, ri, alias_col,   alias, bg=C_YELLOW)
        set_cell(ws, ri, alias_col+1, cid)
        set_cell(ws, ri, alias_col+2, "", bg=C_YELLOW)

    # 追加行用の余白（5行）
    for ri in range(alias_start+2+len(CATEGORY_ALIASES),
                    alias_start+2+len(CATEGORY_ALIASES)+5):
        for ci in [alias_col, alias_col+2]:
            set_cell(ws, ri, ci, "", bg=C_YELLOW)
        set_cell(ws, ri, alias_col+1, "")

    tbl_alias = Table(
        displayName="tbl_category_alias",
        ref=f"{get_column_letter(alias_col)}{alias_start+1}:{get_column_letter(alias_col+2)}{alias_start+1+len(CATEGORY_ALIASES)+5}"
    )
    tbl_alias.tableStyleInfo = TableStyleInfo(name="TableStyleLight14", showRowStripes=True)
    ws.add_table(tbl_alias)

    freeze(ws, "A12")
    return ws

ws_master = make_master(wb)

# ================================================================
# Sheet 5: PQ_Mコード（Power Query M コード）
# ================================================================
def make_pq_sheet(wb):
    ws = wb.create_sheet("PQ_Mコード")
    ws.sheet_view.showGridLines = False

    set_header(ws, 1, 1, "Power Query Mコード 設定手順", bg=C_BLUE_H, sz=13)
    ws.merge_cells("A1:B1")
    set_col_width(ws, 1, 18)
    set_col_width(ws, 2, 100)

    instructions = [
        ("【操作手順】", ""),
        ("STEP 1", "[データ] タブ → [データの取得] → [Power Query エディターの起動]"),
        ("STEP 2", "[新しいクエリ] → [その他のソース] → [空のクエリ] を選択"),
        ("STEP 3", "数式バーに以下のMコードを貼り付けて「完了」"),
        ("STEP 4", "クエリ名を左側パネルで「tbl_calllog_fy_raw」等に変更"),
        ("STEP 5", "[ホーム] → [閉じて読み込む] → [閉じて次に読み込む] → 既存シートを指定"),
        ("", ""),
        ("【重要】", "マスタ/設定シートの「フォルダパス設定」を先に入力してください"),
        ("", "パスは絶対パス（例：C:\\Users\\xxx\\data\\calllog\\FY）を使用"),
        ("", ""),
    ]

    mcode_blocks = {
        "fnGetFolderPath（パス取得関数）": '''(key as text) as text =>
let
    Tbl = Excel.CurrentWorkbook(){[Name="tbl_settings"]}[Content],
    Row = Table.SelectRows(Tbl, each [キー] = key),
    Val = Row{0}[パス（絶対パスを入力）]
in
    Val''',

        "src_calllog_fy（calllog FY フォルダ取り込み）": '''let
    FolderPath = fnGetFolderPath("calllog_fy_path"),
    Source = Folder.Files(FolderPath),
    FilterCSV = Table.SelectRows(Source, each [Extension] = ".csv"),
    AddContent = Table.AddColumn(FilterCSV, "Data", each
        Csv.Document([Content],
            [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv,
             HasHeaders=true])
    ),
    Combined = Table.ExpandTableColumn(
        Table.SelectColumns(AddContent, {"Name","Data"}),
        "Data",
        {"発着","発信番号","着信番号","開始","IVR応答","通話開始","終了","呼び出し結果"}
    ),
    AddDateKey = Table.AddColumn(Combined, "date_key",
        each try Date.From(DateTime.FromText([開始])) otherwise null, type date),
    AddHour = Table.AddColumn(AddDateKey, "hour_key",
        each try Time.Hour(DateTime.Time(DateTime.FromText([開始]))) otherwise null, Int64.Type),
    AddDirection = Table.AddColumn(AddHour, "direction",
        each if [発着] = "着信" then "IN" else "OUT", type text),
    AddYM = Table.AddColumn(AddDirection, "ym_key",
        each if [date_key] <> null then Date.ToText([date_key], "yyyyMM") else null, type text),
    AddCount = Table.AddColumn(AddYM, "count", each 1, Int64.Type)
in
    AddCount''',

        "src_toiawase_fy（toiawase FY フォルダ取り込み）": '''let
    FolderPath = fnGetFolderPath("toiawase_fy_path"),
    Source = Folder.Files(FolderPath),
    FilterCSV = Table.SelectRows(Source, each [Extension] = ".csv"),
    AddContent = Table.AddColumn(FilterCSV, "Data", each
        Csv.Document([Content],
            [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv,
             HasHeaders=true])
    ),
    Combined = Table.ExpandTableColumn(
        Table.SelectColumns(AddContent, {"Name","Data"}),
        "Data",
        {"受付日時","カテゴリ","対応時間（分）","ステータス","担当者","優先度"}
    ),
    FilterEmpty = Table.SelectRows(Combined, each [受付日時] <> null and [受付日時] <> ""),
    AddDateKey = Table.AddColumn(FilterEmpty, "date_key",
        each try Date.From(DateTime.FromText([受付日時])) otherwise null, type date),
    AddHour = Table.AddColumn(AddDateKey, "hour_key",
        each try Time.Hour(DateTime.Time(DateTime.FromText([受付日時]))) otherwise null, Int64.Type),
    AddYM = Table.AddColumn(AddHour, "ym_key",
        each if [date_key] <> null then Date.ToText([date_key], "yyyyMM") else null, type text),
    // 表記ゆれ正規化（tbl_category_alias と結合）
    AliasTable = Excel.CurrentWorkbook(){[Name="tbl_category_alias"]}[Content],
    JoinAlias = Table.NestedJoin(AddYM, {"カテゴリ"}, AliasTable,
        {"alias（CSV上の表記）"}, "alias_match", JoinKind.LeftOuter),
    ExpandAlias = Table.ExpandTableColumn(JoinAlias, "alias_match",
        {"category_id"}, {"category_id"}),
    AddCategoryNorm = Table.AddColumn(ExpandAlias, "category_normalized",
        each if [category_id] <> null then [category_id] else [カテゴリ], type text),
    AddCount = Table.AddColumn(AddCategoryNorm, "count", each 1, Int64.Type)
in
    AddCount''',

        "agg_daily_call（日別集計）": '''let
    Source = tbl_calllog_fy_raw,
    Grouped = Table.Group(Source, {"date_key", "direction"}, {
        {"total_count", each List.Sum([count]), Int64.Type}
    }),
    Pivoted = Table.Pivot(
        Grouped,
        List.Distinct(Grouped[direction]),
        "direction",
        "total_count",
        List.Sum
    )
in
    Pivoted''',
    }

    row = 3
    for label, text in instructions:
        ws.cell(row=row, column=1, value=label).font = Font(bold=(label != ""), size=10, name="Meiryo UI")
        ws.cell(row=row, column=2, value=text).font = Font(size=10, name="Meiryo UI")
        row += 1

    for title, code in mcode_blocks.items():
        row += 1
        set_header(ws, row, 1, "▼ クエリ名", bg="4472C4")
        set_header(ws, row, 2, title, bg="4472C4")
        row += 1
        cell = ws.cell(row=row, column=2, value=code)
        cell.font = Font(name="Consolas", size=9)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = max(15 * (code.count("\n") + 2), 80)
        ws.cell(row=row, column=1, value="Mコード").font = Font(size=9, name="Meiryo UI", bold=True)
        row += 2

    return ws

ws_pq = make_pq_sheet(wb)

# ================================================================
# Sheet 6: 更新方法
# ================================================================
def make_howto(wb):
    ws = wb.create_sheet("更新方法")
    ws.sheet_view.showGridLines = False
    set_col_width(ws, 1, 4)
    set_col_width(ws, 2, 60)

    set_header(ws, 1, 1, "更新方法（操作マニュアル）", bg=C_BLUE_H, sz=14)
    ws.merge_cells("A1:B1")
    ws.row_dimensions[1].height = 32

    steps = [
        ("", ""),
        ("─ 毎日の更新作業（所要時間：1〜3分） ─", ""),
        ("", ""),
        ("STEP 1", "CSVファイルを所定フォルダへ投入"),
        ("", "  📂 calllog（受発信履歴）→  data\\calllog\\FY\\"),
        ("", "       ファイル名例：calllog_202604.csv（月次）または calllog_20260401.csv（日次）"),
        ("", "  📂 toiawase（問い合わせ票）→  data\\toiawase\\FY\\"),
        ("", "       ファイル名例：toiawase_20260401_0900.csv"),
        ("", "  ⚠ 同じ日のファイルを入れ直すときは古いファイルを削除または上書き"),
        ("", ""),
        ("STEP 2", "Excelを開く（既に開いている場合はそのまま）"),
        ("", ""),
        ("STEP 3", "[データ] タブ → [すべて更新] をクリック"),
        ("", "  ※ 更新には数十秒〜数分かかります。完了するまで待ってください"),
        ("", "  ※ 「セキュリティの警告」が表示された場合は [コンテンツを有効にする] をクリック"),
        ("", ""),
        ("STEP 4", "Dashboard シートで確認"),
        ("", "  ・基準日セル（黄色）が今日の日付になっているか確認"),
        ("", "  ・KPIカードの数値が最新になっているか確認"),
        ("", ""),
        ("─ 初期設定（初回のみ） ─", ""),
        ("", ""),
        ("初期設定1", "マスタ/設定シートのフォルダパスを設定"),
        ("", "  セル B3〜B6（黄色セル）に実際のフォルダパス（絶対パス）を入力"),
        ("", "  例：C:\\Users\\[ユーザー名]\\[作業フォルダ]\\data\\calllog\\FY"),
        ("", ""),
        ("初期設定2", "Power Query の接続設定（PQ_Mコードシートを参照）"),
        ("", "  [データ] → [データの取得] → [Power Query エディターの起動]"),
        ("", "  PQ_Mコードシートのコードを各クエリにコピペして設定"),
        ("", ""),
        ("初期設定3", "カテゴリマスタの確認"),
        ("", "  マスタ/設定シートの「分類マスタ」「表記ゆれ対応表」を確認・追記"),
        ("", ""),
        ("─ 前年度データの追加 ─", ""),
        ("", ""),
        ("前年データ", "data\\calllog\\LY\\ および data\\toiawase\\LY\\ へ前年CSVを投入"),
        ("", "  投入後に [すべて更新] を実行すると 元データ_前年度 シートが更新される"),
        ("", ""),
        ("─ トラブルシューティング ─", ""),
        ("", ""),
        ("Q1", "更新後にデータが表示されない"),
        ("", "  → マスタ/設定のフォルダパスが正しいか確認"),
        ("", "  → CSVのファイル名が正しいか確認（拡張子 .csv であること）"),
        ("", "  → Power Query クエリが設定されているか確認（PQ_Mコードシート参照）"),
        ("", ""),
        ("Q2", "「外部データへの接続がブロックされました」と表示される"),
        ("", "  → [データ] → [クエリと接続] で各クエリの状態を確認"),
        ("", "  → [ファイル] → [オプション] → [セキュリティセンター] → [外部コンテンツ] を確認"),
        ("", ""),
        ("Q3", "前年比が正しく表示されない"),
        ("", "  → マスタ/設定の tbl_calendar で prev_year_date_A 列が空でないか確認"),
        ("", "  → LY フォルダに前年CSVが入っているか確認"),
        ("", ""),
        ("Q4", "分類が「その他」にまとまってしまう"),
        ("", "  → マスタ/設定の「表記ゆれ対応表」にCSV上の表記を追加（黄色セル）"),
        ("", "  → 追記後に [すべて更新] を実行"),
        ("", ""),
        ("─ セル色ルール ─", ""),
        ("", ""),
        ("黄色セル",   "入力・変更してよいセル"),
        ("灰色セル",   "触らないこと（数式・自動計算）"),
        ("濃紺ヘッダ", "テーブルヘッダー（変更不可）"),
        ("薄赤行",     "祝日・休日（カレンダー上）"),
    ]

    for ri, (step, desc) in enumerate(steps, 2):
        ws.row_dimensions[ri].height = 18
        c1 = ws.cell(row=ri, column=1, value=step)
        c2 = ws.cell(row=ri, column=2, value=desc)

        if "─" in step:
            ws.merge_cells(f"A{ri}:B{ri}")
            c1.value = step
            c1.fill = fill("D6E4F7")
            c1.font = Font(bold=True, size=11, color=C_BLUE_H, name="Meiryo UI")
            c1.alignment = align(h="center")
        elif step.startswith("STEP") or step.startswith("初期"):
            c1.fill = fill("FFF2CC")
            c1.font = Font(bold=True, size=10, color="7F6000", name="Meiryo UI")
            c1.alignment = align(h="center")
            c2.font = Font(bold=True, size=10, color="7F6000", name="Meiryo UI")
        elif step.startswith("Q") or step in ("前年データ","黄色セル","灰色セル","濃紺ヘッダ","薄赤行"):
            c1.fill = fill("E2EFDA")
            c1.font = Font(bold=True, size=10, color=C_GREEN_H, name="Meiryo UI")
            c1.alignment = align(h="center")
            c2.font = Font(size=10, name="Meiryo UI")
        else:
            c2.font = Font(size=9.5, name="Meiryo UI")
            c1.font = Font(size=9.5, name="Meiryo UI")

    return ws

ws_how = make_howto(wb)

# ================================================================
# シート順序の並び替え
# ================================================================
sheet_order = [
    "Dashboard",
    "元データ_今年度",
    "元データ_前年度",
    "集計_中間",
    "マスタ_設定",
    "PQ_Mコード",
    "更新方法",
]
for i, name in enumerate(sheet_order):
    if name in wb.sheetnames:
        ws_ = wb[name]
        wb.move_sheet(ws_, offset=-(wb.index(ws_) - i))

# Dashboardをアクティブに
wb.active = wb["Dashboard"]

# ================================================================
# データフォルダ作成
# ================================================================
for path in [
    os.path.join(DATA_ROOT, "calllog", "FY"),
    os.path.join(DATA_ROOT, "calllog", "LY"),
    os.path.join(DATA_ROOT, "toiawase", "FY"),
    os.path.join(DATA_ROOT, "toiawase", "LY"),
]:
    os.makedirs(path, exist_ok=True)

# サンプルCSVをFYフォルダへ出力（1か月分）
import csv, io

def write_sample_csv(path, headers, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)

# calllog 今年度 2026/03 分
calllog_mar = [r for r in CALLLOG_FY
               if datetime.strptime(r["開始"], "%Y-%m-%d %H:%M:%S").month == 3
               and datetime.strptime(r["開始"], "%Y-%m-%d %H:%M:%S").year == 2026]
write_sample_csv(
    os.path.join(DATA_ROOT, "calllog", "FY", "calllog_202603.csv"),
    ["発着","発信番号","着信番号","開始","IVR応答","通話開始","終了","呼び出し結果"],
    calllog_mar
)

# toiawase 今年度 2026/03 分
inq_mar = [r for r in INQUIRY_FY
           if datetime.strptime(r["受付日時"], "%Y-%m-%d %H:%M").month == 3
           and datetime.strptime(r["受付日時"], "%Y-%m-%d %H:%M").year == 2026]
write_sample_csv(
    os.path.join(DATA_ROOT, "toiawase", "FY", "toiawase_202603.csv"),
    ["受付日時","カテゴリ","対応時間（分）","ステータス","担当者","優先度"],
    inq_mar
)

print(f"Sample CSVs written:")
print(f"  calllog_202603.csv: {len(calllog_mar)} rows")
print(f"  toiawase_202603.csv: {len(inq_mar)} rows")

# ================================================================
# 保存
# ================================================================
wb.save(OUT_FILE)
print("DONE: " + OUT_FILE)
print("sheets: " + str(wb.sheetnames))
