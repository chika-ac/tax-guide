#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
deploy_prod.py  - dev/ → prod/ 反映
使用方法: python scripts/deploy_prod.py
"""
import os, sys, shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEV  = os.path.join(ROOT, 'dev')
PROD = os.path.join(ROOT, 'prod')

print('=== deploy_prod.py 開始 ===')

# 必須ファイル確認
for fn in ['index.html', 'app.js', 'styles.css', 'data.js']:
    if not os.path.exists(os.path.join(DEV, fn)):
        print(f'[ERROR] dev/{fn} が見つかりません。先に update_dev.bat を実行してください。')
        sys.exit(1)

os.makedirs(PROD, exist_ok=True)

# ファイルコピー（index.html は dev/ の完成済みインライン版をそのままコピー）
for fn in ['index.html', 'app.js', 'styles.css', 'data.js']:
    src = os.path.join(DEV, fn)
    dst = os.path.join(PROD, fn)
    shutil.copy2(src, dst)
    print(f'[OK] {fn}')

# assets コピー
src_assets = os.path.join(ROOT, 'assets', 'figures')
dst_assets = os.path.join(PROD, 'assets', 'figures')
if os.path.exists(src_assets):
    os.makedirs(dst_assets, exist_ok=True)
    for fn in os.listdir(src_assets):
        shutil.copy2(os.path.join(src_assets, fn), os.path.join(dst_assets, fn))
    print(f'[OK] assets/figures')

print('=== 完了: prod/ に反映しました ===')
