@echo off
chcp 65001 > nul
setlocal

:: ── deploy_prod.bat ──────────────────────────────────────────
:: dev/ → prod/ 反映スクリプト
:: ─────────────────────────────────────────────────────────────

set "SCRIPT_DIR=%~dp0"
set "ROOT_DIR=%SCRIPT_DIR%.."
set "DEV=%ROOT_DIR%\dev"
set "PROD=%ROOT_DIR%\prod"

echo [deploy_prod] 開始...

if not exist "%DEV%\index.html" (
    echo [ERROR] dev\index.html が見つかりません。先に update_dev.bat を実行してください。
    pause
    exit /b 1
)
if not exist "%DEV%\data.js" (
    echo [ERROR] dev\data.js が見つかりません。先に update_dev.bat を実行してください。
    pause
    exit /b 1
)

:: Python版を優先
where python >nul 2>&1
if not errorlevel 1 (
    python "%SCRIPT_DIR%deploy_prod.py"
    if not errorlevel 1 (
        echo.
        echo [完了] prod\ に反映しました。
        echo        prod\index.html を利用者に配布してください。
        pause
        exit /b 0
    )
)

:: フォールバック: xcopy版
if not exist "%PROD%" mkdir "%PROD%"
copy /Y "%DEV%\index.html" "%PROD%\index.html" >nul
copy /Y "%DEV%\app.js"     "%PROD%\app.js"     >nul
copy /Y "%DEV%\styles.css" "%PROD%\styles.css" >nul
copy /Y "%DEV%\data.js"    "%PROD%\data.js"    >nul

if not exist "%PROD%\assets\figures" mkdir "%PROD%\assets\figures"
xcopy /E /I /Y "%ROOT_DIR%\assets\figures" "%PROD%\assets\figures" >nul 2>&1

echo.
echo [完了] prod\ に反映しました。
echo        prod\index.html を利用者に配布してください。
pause
endlocal
