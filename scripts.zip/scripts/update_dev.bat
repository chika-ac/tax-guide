@echo off
chcp 65001 > nul
setlocal

:: ── update_dev.bat ───────────────────────────────────────────
:: Excel → dev/data.js 変換
:: 優先順位: Python版 → Node.js版
:: 実行前提: Python 3.8+ (推奨) または Node.js 16+
:: ─────────────────────────────────────────────────────────────

set "SCRIPT_DIR=%~dp0"
set "ROOT_DIR=%SCRIPT_DIR%.."
set "PY_SCRIPT=%SCRIPT_DIR%update_dev.py"
set "NODE_SCRIPT=%SCRIPT_DIR%update_dev.js"

echo [update_dev] 開始...

:: ── Python版を試みる（推奨） ──────────────────────────────────
where python >nul 2>&1
if not errorlevel 1 (
    python -c "import openpyxl" >nul 2>&1
    if errorlevel 1 (
        echo [INFO] openpyxl をインストールします...
        python -m pip install openpyxl
        if errorlevel 1 (
            echo [WARN] pip install 失敗。Node.js版にフォールバックします。
            goto TryNode
        )
    )
    echo [INFO] Python で変換します...
    python "%PY_SCRIPT%"
    if not errorlevel 1 (
        echo.
        echo [完了] dev\data.js が更新されました。
        echo        dev\index.html をブラウザで開いて確認してください。
        pause
        exit /b 0
    )
    echo [WARN] Python版失敗。Node.js版にフォールバックします。
)

:TryNode
:: ── Node.js版を試みる ────────────────────────────────────────
where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python も Node.js も見つかりません。
    echo         Python 3.8+ をインストールしてください:
    echo         https://www.python.org/downloads/
    pause
    exit /b 1
)

if not exist "%ROOT_DIR%\node_modules\xlsx" (
    echo [INFO] npm install 中...
    pushd "%ROOT_DIR%"
    call npm install
    if errorlevel 1 (
        echo [ERROR] npm install に失敗しました。
        popd
        pause
        exit /b 1
    )
    popd
)

node "%NODE_SCRIPT%"
if errorlevel 1 (
    echo [ERROR] 変換処理に失敗しました。上記エラーを確認してください。
    pause
    exit /b 1
)

echo.
echo [完了] dev\data.js が更新されました。
echo        dev\index.html をブラウザで開いて確認してください。
pause
endlocal
