# 給付・届出 初動対応ツール

認定担当者が安全に初動対応できるよう、タブ／アコーディオン／FAQ検索で情報を即参照できるツールです。

---

## 1. このツールの目的

採用・転居・出生・就職など、各種届出が発生した際に担当者が：

- **認定基準・認定シーン**を素早く確認できる
- **添付書類一覧**を確認できる
- **よくある質問（FAQ）**を検索・参照できる
- **基本トーク・主管課・電話番号**を即座に引ける

ようにした社内向け静的 Web ツールです。  
`file://` プロトコルでローカルファイルを開くだけで動作します（サーバー不要）。

---

## 2. 全体構造

```
project/
├── data/
│   └── data.xlsx          ← 元データ（全情報の唯一の管理場所）
├── assets/
│   └── figures/           ← 図・画像ファイル（SVG/PNG/JPG）
├── scripts/
│   ├── update_dev.bat     ← ① Excel→dev/data.js 変換（Windows用）
│   ├── update_dev.py      ← ① 変換スクリプト本体（Python）
│   ├── update_dev.js      ← ① 変換スクリプト本体（Node.js版）
│   └── deploy_prod.bat    ← ② dev/→prod/ 反映（Windows用）
├── dev/                   ← 作業用（編集・確認はここ）
│   ├── index.html
│   ├── app.js
│   ├── styles.css
│   ├── data.js            ← ビルド生成物（直接編集しない）
│   └── assets/figures/    ← assetsのコピー
├── prod/                  ← 本番（配布用）
│   ├── index.html
│   ├── app.js
│   ├── styles.css
│   ├── data.js
│   └── assets/figures/
├── package.json           ← Node.js依存定義
└── README.md              ← このファイル
```

### 役割の分離

| 層 | ファイル | 役割 |
|---|---|---|
| 骨組み | `dev/index.html` | HTML構造のみ。直接編集不要 |
| 見た目 | `dev/styles.css` | CSS変数・レイアウト・印刷 |
| 制御 | `dev/app.js` | 描画ロジック・検索・アコーディオン |
| データ | `data/data.xlsx` | **コンテンツの唯一の管理場所** |
| データ（生成物） | `dev/data.js` | Excelから自動生成。**直接編集禁止** |

---

## 3. シート一覧と役割

| シート名 | 役割 |
|---|---|
| `category_master` | 左タブ（業務カテゴリ・共通・FAQ）定義 |
| `section_master` | 右上タブ（セクション）定義 |
| `section_blocks` | カテゴリ×セクションに配置するブロック定義 |
| `content` | **メインコンテンツ（FAQ・基準・書類等）** |
| `faq_map` | カテゴリ別FAQのデフォルト表示マッピング |
| `messages` | 共通文言（注意文・ラベル等） |
| `templates` | トーク・メール文面テンプレ |
| `requirements` | 要件・条件（制度/業務ルール） |
| `escalation` | エスカレーション基準・連絡先 |
| `decision_logic` | 判定ロジック（金額→OK/NG等） |
| `view_settings` | 各トピックの表示形式指定 |
| `ui_settings` | 初期表示・タイトル等の全体設定 |
| `assets_map` | 画像・図のパス・キャプション管理 |
| `flow` | フロー図とコンテンツの紐づけ |
| `calc_logic` | 計算ロジック定義 |

---

## 4. キー列一覧（何が何と繋がるか）

```
category_master.category_id
  ↕ section_blocks.category_id
  ↕ content.category_id
  ↕ faq_map.category_id

section_master.section_id
  ↕ section_blocks.section_id
  ↕ content.section_id

content.topic_id（ユニーク）
  ↕ faq_map.faq_topic_id
  ↕ view_settings.topic_id
  ↕ flow.related_topic_id

assets_map.asset_id
  ↕ section_blocks.source_ref（source_type=asset_id のとき）
  ↕ content.asset_id
  ↕ flow.asset_id

messages.message_key
  ↕ section_blocks.source_ref（source_type=message_key のとき）
  ↕ decision_logic.ok_message_key / ng_message_key
```

---

## 5. 表示の流れ

```
data.xlsx
  ↓ scripts/update_dev.bat 実行
dev/data.js（window.__DATA__ = {...}）
  ↓ ブラウザが <script src="data.js"> で読み込み
dev/app.js が描画
  ├─ 左タブ ← category_master
  ├─ 右上タブ ← section_master × section_blocks
  └─ コンテンツ ← section_blocks.source_ref → content / messages / assets_map
```

### ブロックのsource_type別解決ルール

| source_type | source_ref の書式 | 解決先 |
|---|---|---|
| `content_query` | `key=val;key=val` | `content`シートをフィルタ |
| `topic_ids` | `id1\|id2\|id3` | `content`の指定topic_id群 |
| `message_key` | メッセージキー | `messages`シート |
| `asset_id` | アセットID | `assets_map`シート |
| `rule_id` | ルールID | `decision_logic`シート |

---

## 6. よくある更新と編集箇所

| やりたいこと | 編集するシート／場所 |
|---|---|
| 左タブを追加・名称変更 | `category_master` |
| 右上タブを追加・名称変更 | `section_master` |
| コンテンツ（本文・FAQ）の追加・修正 | `content` |
| カテゴリ別FAQの表示増減 | `faq_map` |
| 共通の注意文・定型ラベル変更 | `messages` |
| トーク・メール文面変更 | `templates` |
| 判定条件変更 | `decision_logic` |
| 計算式変更 | `calc_logic` |
| エスカレ基準変更 | `escalation` |
| 画像差し替え | `assets/figures/`に上書き保存（パス変更なら`assets_map`も更新） |
| 項目を一時的に非表示 | 該当行の`visible`列を`no`に変更（削除しない） |
| 初期表示カテゴリ変更 | `ui_settings` の `default_category` |
| ページタイトル変更 | `ui_settings` の `page_title` |

---

## 7. やってはいけないこと

| ❌ NG | 理由 |
|---|---|
| `dev/data.js` を直接編集する | 次回ビルドで上書きされる |
| `prod/` 内のファイルを直接編集する | `deploy_prod.bat`で上書きされる |
| HTMLの`body`列にHTMLタグを書く | XSS対策でテキストとして表示される |
| `topic_id`・`category_id`等のIDにスペース・大文字を使う | 参照整合性が壊れる |
| 行を削除して非表示にする | `visible=no`を使うこと（後で戻せなくなる） |
| `category_id`等の参照キーを表記ゆれさせる | `tsukin`と`Tsukin`は別物として扱われる |

---

## 8. 公開手順

### 通常の更新フロー

```
① data/data.xlsx を編集（画像があれば assets/figures/ も更新）
          ↓
② scripts\update_dev.bat をダブルクリック実行
          ↓
③ dev\index.html をブラウザで開いて表示を確認
          ↓
④ scripts\deploy_prod.bat をダブルクリック実行
          ↓
⑤ prod\ フォルダごと共有サーバー等に配置
   （prod\index.html をブラウザで開くだけで動作）
```

### 初回セットアップ（Python版・推奨）

```
1. Python 3.8+ をインストール
   https://www.python.org/downloads/
   ※ インストール時「Add Python to PATH」にチェックを入れる

2. openpyxl をインストール（初回のみ）
   コマンドプロンプトで:
   pip install openpyxl

3. scripts\update_dev.bat をダブルクリック
   → 自動で openpyxl の有無を確認し、変換を実行
```

### Node.js版を使う場合

```
1. Node.js 16+ をインストール
   https://nodejs.org/

2. プロジェクトルートで:
   npm install

3. scripts\update_dev.bat をダブルクリック
   （Python未検出時は自動でNode.js版を使用）
```

---

## 9. トラブル時の確認ポイント

### 画面が真っ白・コンテンツが表示されない

- `dev\data.js` が存在するか確認
- ブラウザの開発者ツール（F12）→ コンソールタブでエラー確認
- `data.js` の1行目が `window.__DATA__ = {` で始まっているか確認

### update_dev.bat でエラーが出る

- Python / Node.js がインストールされているか確認
  ```
  python --version
  node --version
  ```
- `data/data.xlsx` が存在するか確認
- Excelが開いたままだとファイルロックが発生する場合あり → 閉じてから実行

### バリデーションエラーが出る

エラーメッセージを読み、該当シートの該当列を修正する。

| エラー種別 | 対処 |
|---|---|
| 重複ID | 該当シートで同じIDが2行以上ないか確認 |
| visible値不正 | `yes` または `no` 以外の値を修正 |
| 参照整合性 | 参照先のIDが正しく存在するか確認 |
| 画像なし（WARN） | `assets/figures/`にファイルがあるか確認 |

### 画像が表示されない

- `assets_map`の`figure_path`が `assets/figures/ファイル名` 形式か確認
- `update_dev.bat`を再実行して `dev/assets/figures/` にコピーされているか確認
- 画像ファイル名に全角文字・スペースが含まれていないか確認

### FAQ検索で結果が出ない

- 対象コンテンツの`content_type`が`faq`になっているか確認
- 対象コンテンツの`visible`が`yes`になっているか確認
- `ui_settings`の`search_min_chars`の値（デフォルト2）以上のキーワードで検索しているか確認

---

## 10. 変更履歴の付け方

`content`シートの運用列を使ってください：

| 列 | 記入内容 |
|---|---|
| `updated_at` | 変更日（`YYYY-MM-DD`形式） |
| `updated_by` | 変更者名または担当課 |
| `change_reason` | 変更理由（簡潔に） |
| `badge_text` | `NEW`や`更新`など、画面上に表示したいバッジ文言 |
| `badge_until` | バッジを表示する期限（`YYYY-MM-DD`）※未使用時は空欄 |

シート全体の更新履歴は別途Excelのシートや管理台帳で管理することを推奨します。

---

## 補足事項

### `visible=no` の意味

`visible=no` は「論理削除」です。行を削除した場合と異なり：
- データは残るため後で`yes`に戻せる
- 参照整合性チェックの対象外にならないため、整合性が維持される
- 過去の経緯・履歴として追跡できる

### 参照整合性チェックについて

`update_dev.bat` 実行時に自動でチェックされます：
- 存在しないIDへの参照（エラー）
- 重複ID（エラー）
- 画像ファイルの実在確認（警告）
- `visible`値の妥当性（エラー）

エラーがある場合は`data.js`が生成されません。

### 画像欠落時の扱い

`assets_map`に登録されているが実ファイルが存在しない場合：
- `update_dev.bat`で**警告（WARN）**として表示されます（エラーではない）
- 画面上では`<img>`タグの`alt`テキストが表示されます
- 運用上は速やかにファイルを補完してください

### HTMLは原則直接編集しない

`dev/index.html` はHTML構造のみを持ちます。  
コンテンツの変更は必ず `data/data.xlsx` で行ってください。  
レイアウト・デザインの変更は `dev/styles.css` を編集してください。  
`prod/` 内のファイルは `deploy_prod.bat` の生成物であり、直接編集しても次回上書きされます。
