' build.vbs - Excel to HTML generator (VBScript / WSH)
' Requirements: Windows built-in (no Python, no PowerShell signing needed)
' Microsoft Excel must be installed.

Option Explicit

Dim fso, BADGE(4,1)
Set fso = CreateObject("Scripting.FileSystemObject")

BADGE(0,0) = ChrW(37197) & ChrW(20598) & ChrW(32773) & ChrW(65288) & ChrW(38738) & ChrW(65289)
BADGE(0,1) = "b-blue"
BADGE(1,0) = ChrW(25206) & ChrW(39178) & ChrW(65288) & ChrW(32209) & ChrW(65289)
BADGE(1,1) = "b-green"
BADGE(2,0) = ChrW(38556) & ChrW(23475) & ChrW(32773) & ChrW(65288) & ChrW(27225) & ChrW(65289)
BADGE(2,1) = "b-amber"
BADGE(3,0) = ChrW(12402) & ChrW(12392) & ChrW(12426) & ChrW(35242) & Chr(47) & ChrW(23521) & ChrW(23142) & ChrW(65288) & ChrW(36196) & ChrW(65289)
BADGE(3,1) = "b-red"
BADGE(4,0) = ChrW(26412) & ChrW(20154) & ChrW(12381) & ChrW(12398) & ChrW(20182) & ChrW(65288) & ChrW(32043) & ChrW(65289)
BADGE(4,1) = "b-purple"

Dim SHEET_NAME, SECTION_SELF
SHEET_NAME   = ChrW(12459) & ChrW(12540) & ChrW(12489) & ChrW(19968) & ChrW(35239)
SECTION_SELF = ChrW(26412) & ChrW(20154)

Dim TOOLS_DIR, ROOT_DIR, XLSX, TMPL, OUTPUT, LOG_DIR, LOG_FILE
TOOLS_DIR = fso.GetParentFolderName(WScript.ScriptFullName) & "\"
ROOT_DIR  = fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName)) & "\"
XLSX      = ROOT_DIR & "data\tax_guide_cards.xlsx"
TMPL      = ROOT_DIR & "src\template.html"
OUTPUT    = ROOT_DIR & "dist\tax_guide.html"
LOG_DIR   = TOOLS_DIR & "logs"
LOG_FILE  = LOG_DIR & "\build_" & Fmt(Now) & ".log"

Dim logBuf
logBuf = ""

Function Fmt(dt)
    Fmt = Year(dt) & Z2(Month(dt)) & Z2(Day(dt)) & "_" & Z2(Hour(dt)) & Z2(Minute(dt)) & Z2(Second(dt))
End Function
Function Z2(n)
    Z2 = Right("0" & n, 2)
End Function

Sub Log(msg)
    Dim line
    line = "[" & Z2(Hour(Now)) & ":" & Z2(Minute(Now)) & ":" & Z2(Second(Now)) & "] " & msg
    WScript.Echo line
    logBuf = logBuf & line & vbCrLf
End Sub

Sub FlushLog()
    If Not fso.FolderExists(LOG_DIR) Then fso.CreateFolder(LOG_DIR)
    Dim f
    Set f = fso.CreateTextFile(LOG_FILE, True, True)
    f.Write logBuf
    f.Close
End Sub

Sub Die(msg)
    Log Chr(69) & Chr(82) & Chr(82) & Chr(79) & Chr(82) & Chr(58) & Chr(32) & msg
    FlushLog
    WScript.Quit 1
End Sub

Function GetBadge(name)
    Dim i
    For i = 0 To 4
        If BADGE(i,0) = name Then GetBadge = BADGE(i,1) : Exit Function
    Next
    GetBadge = ""
End Function

Function JsStr(s)
    Dim t
    t = CStr(s)
    t = Replace(t, "\", "\\")
    t = Replace(t, """", "\""")
    t = Replace(t, vbCrLf, "\n")
    t = Replace(t, vbCr,   "\n")
    t = Replace(t, vbLf,   "\n")
    JsStr = """" & t & """"
End Function

Function T(s)
    If IsNull(s) Or IsEmpty(s) Then T = "" Else T = Trim(CStr(s))
End Function

' =====================================================================
' 1. Read Excel
' =====================================================================
Function ReadCards()
    Log Chr(82) & Chr(101) & Chr(97) & Chr(100) & Chr(105) & Chr(110) & Chr(103) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(58) & Chr(32) & XLSX
    If Not fso.FileExists(XLSX) Then Die Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(32) & Chr(102) & Chr(105) & Chr(108) & Chr(101) & Chr(32) & Chr(110) & Chr(111) & Chr(116) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(58) & Chr(32) & XLSX

    Dim xl
    On Error Resume Next
    Set xl = CreateObject("Excel.Application")
    If Err.Number <> 0 Then Die Chr(77) & Chr(105) & Chr(99) & Chr(114) & Chr(111) & Chr(115) & Chr(111) & Chr(102) & Chr(116) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(32) & Chr(110) & Chr(111) & Chr(116) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(46) & Chr(32) & Chr(80) & Chr(108) & Chr(101) & Chr(97) & Chr(115) & Chr(101) & Chr(32) & Chr(105) & Chr(110) & Chr(115) & Chr(116) & Chr(97) & Chr(108) & Chr(108) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(46)
    On Error GoTo 0

    xl.Visible = False
    xl.DisplayAlerts = False

    Dim wb, ws
    On Error Resume Next
    Set wb = xl.Workbooks.Open(XLSX, 0, True)
    Set ws = wb.Sheets(SHEET_NAME)
    If Err.Number <> 0 Then
        xl.Quit
        Die Chr(83) & Chr(104) & Chr(101) & Chr(101) & Chr(116) & Chr(32) & Chr(110) & Chr(111) & Chr(116) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(46) & Chr(32) & Chr(67) & Chr(104) & Chr(101) & Chr(99) & Chr(107) & Chr(32) & Chr(116) & Chr(104) & Chr(101) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(32) & Chr(102) & Chr(105) & Chr(108) & Chr(101) & Chr(46)
    End If
    On Error GoTo 0

    Dim cards(), cardCount, errors(), errCount
    cardCount = 0 : errCount = 0
    ReDim cards(0) : ReDim errors(0)

    Dim row
    row = 4
    Do While True
        Dim cellA
        cellA = T(ws.Cells(row,1).Value)
        If cellA = "" Then Exit Do

        Dim cardId, title, secRaw, section, sortInc, badgeName, badgeText
        Dim isNewRaw, isNew, incomeReq, amountSh, badge
        cardId    = T(ws.Cells(row,1).Value)
        title     = T(ws.Cells(row,2).Value)
        secRaw    = T(ws.Cells(row,3).Value)
        section   = ""
        If secRaw = SECTION_SELF Then section = "self"
        Dim sv : sv = ws.Cells(row,4).Value
        sortInc   = 0
        If Not (IsNull(sv) Or IsEmpty(sv) Or sv = "") Then sortInc = CInt(sv)
        badgeName = T(ws.Cells(row,5).Value)
        badgeText = T(ws.Cells(row,6).Value)
        isNewRaw  = UCase(T(ws.Cells(row,7).Value))
        isNew     = (isNewRaw = "TRUE")
        incomeReq = T(ws.Cells(row,8).Value)
        amountSh  = T(ws.Cells(row,9).Value)

        badge = GetBadge(badgeName)
        If badge = "" Then
            ReDim Preserve errors(errCount)
            errors(errCount) = Chr(82) & Chr(111) & Chr(119) & Chr(32) & row & Chr(58) & Chr(32) & Chr(73) & Chr(110) & Chr(118) & Chr(97) & Chr(108) & Chr(105) & Chr(100) & Chr(32) & Chr(98) & Chr(97) & Chr(100) & Chr(103) & Chr(101) & Chr(32) & Chr(99) & Chr(111) & Chr(108) & Chr(111) & Chr(114) & Chr(32) & Chr(91) & badgeName & "]"
            errCount = errCount + 1
        End If
        If title = "" Then
            ReDim Preserve errors(errCount)
            errors(errCount) = Chr(82) & Chr(111) & Chr(119) & Chr(32) & row & Chr(32) & Chr(40) & Chr(73) & Chr(68) & Chr(58) & cardId & Chr(93) & Chr(58) & Chr(32) & Chr(84) & Chr(105) & Chr(116) & Chr(108) & Chr(101) & Chr(32) & Chr(105) & Chr(115) & Chr(32) & Chr(101) & Chr(109) & Chr(112) & Chr(116) & Chr(121)
            errCount = errCount + 1
        End If
        If incomeReq = "" Then
            ReDim Preserve errors(errCount)
            errors(errCount) = Chr(82) & Chr(111) & Chr(119) & Chr(32) & row & Chr(32) & Chr(40) & Chr(73) & Chr(68) & Chr(58) & cardId & Chr(93) & Chr(58) & Chr(32) & Chr(67) & Chr(111) & Chr(108) & Chr(117) & Chr(109) & Chr(110) & Chr(32) & Chr(72) & Chr(32) & Chr(105) & Chr(115) & Chr(32) & Chr(101) & Chr(109) & Chr(112) & Chr(116) & Chr(121)
            errCount = errCount + 1
        End If

        ' conditions (cols 10-21, 3 cols x 4)
        Dim conds(3,2), ci
        For ci = 0 To 3
            Dim base : base = 10 + ci * 3
            conds(ci,0) = T(ws.Cells(row, base  ).Value)
            conds(ci,1) = T(ws.Cells(row, base+1).Value)
            conds(ci,2) = T(ws.Cells(row, base+2).Value)
        Next

        ' amounts (col 22)
        Dim amtRaw, amtLines, amounts(20,1), amtCount
        amtRaw   = T(ws.Cells(row,22).Value)
        amtLines = Split(amtRaw, vbLf)
        amtCount = 0
        Dim ai
        For ai = 0 To UBound(amtLines)
            Dim aline : aline = Trim(amtLines(ai))
            Dim arrowPos : arrowPos = InStr(aline, ChrW(8594))
            If arrowPos > 0 Then
                amounts(amtCount, 0) = Trim(Left(aline, arrowPos - 1))
                amounts(amtCount, 1) = Trim(Mid(aline, arrowPos + 1))
                amtCount = amtCount + 1
            End If
        Next

        Dim matchRule, note
        matchRule = T(ws.Cells(row,23).Value)
        note      = T(ws.Cells(row,24).Value)

        ' Store card as string (serialised for later use)
        ReDim Preserve cards(cardCount)
        cards(cardCount) = cardId & vbTab & T(section) & vbTab & sortInc & vbTab & _
                           badge & vbTab & badgeText & vbTab & title & vbTab & _
                           CStr(isNew) & vbTab & amountSh & vbTab & incomeReq & vbTab & _
                           matchRule & vbTab & note & vbTab & _
                           conds(0,0) & vbTab & conds(0,1) & vbTab & conds(0,2) & vbTab & _
                           conds(1,0) & vbTab & conds(1,1) & vbTab & conds(1,2) & vbTab & _
                           conds(2,0) & vbTab & conds(2,1) & vbTab & conds(2,2) & vbTab & _
                           conds(3,0) & vbTab & conds(3,1) & vbTab & conds(3,2) & vbTab & _
                           amtCount
        ' Append amounts
        Dim amti
        For amti = 0 To amtCount - 1
            cards(cardCount) = cards(cardCount) & vbTab & amounts(amti,0) & vbTab & amounts(amti,1)
        Next

        cardCount = cardCount + 1
        row = row + 1
    Loop

    wb.Close False
    xl.Quit

    If errCount > 0 Then
        Log Chr(45) & Chr(45) & Chr(45) & Chr(32) & Chr(73) & Chr(110) & Chr(112) & Chr(117) & Chr(116) & Chr(32) & Chr(101) & Chr(114) & Chr(114) & Chr(111) & Chr(114) & Chr(115) & Chr(32) & Chr(45) & Chr(45) & Chr(45)
        Dim ei
        For ei = 0 To errCount - 1
            Log "  [X] " & errors(ei)
        Next
        Die errCount & Chr(32) & Chr(101) & Chr(114) & Chr(114) & Chr(111) & Chr(114) & Chr(40) & Chr(115) & Chr(41) & Chr(46) & Chr(32) & Chr(70) & Chr(105) & Chr(120) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(32) & Chr(97) & Chr(110) & Chr(100) & Chr(32) & Chr(114) & Chr(101) & Chr(116) & Chr(114) & Chr(121) & Chr(46)
    End If

    Log Chr(67) & Chr(97) & Chr(114) & Chr(100) & Chr(115) & Chr(32) & Chr(108) & Chr(111) & Chr(97) & Chr(100) & Chr(101) & Chr(100) & Chr(58) & Chr(32) & cardCount
    ReadCards = cards
End Function

' =====================================================================
' 2. Build DEDUCTIONS JS
' =====================================================================
Function BuildDEDUCTIONSjs(cards)
    Dim sb, i
    sb = "const DEDUCTIONS = [" & vbCrLf
    For i = 0 To UBound(cards)
        Dim f : f = Split(cards(i), vbTab)
        ' f(0)=id f(1)=section f(2)=sortIncome f(3)=badge f(4)=badgeText
        ' f(5)=title f(6)=isNew f(7)=amountShort f(8)=incomeReq
        ' f(9)=matchRule f(10)=note
        ' f(11..22)=conds(0..3)x3  f(23)=amtCount  f(24..)=amt pairs
        sb = sb & vbCrLf & "  /* ---- " & f(5) & " ----*/" & vbCrLf
        sb = sb & "  {" & vbCrLf
        sb = sb & "    id:" & JsStr(f(0)) & ", sortIncome:" & f(2) & ", badge:" & JsStr(f(3)) & ", badgeText:" & JsStr(f(4)) & "," & vbCrLf
        sb = sb & "    title:" & JsStr(f(5)) & "," & vbCrLf
        If f(6) = "True" Then sb = sb & "    isNew:true," & vbCrLf
        sb = sb & "    amountShort:" & JsStr(f(7)) & "," & vbCrLf
        sb = sb & "    incomeReq:" & JsStr(f(8)) & "," & vbCrLf
        If f(1) <> "" Then sb = sb & "    section:" & JsStr(f(1)) & "," & vbCrLf
        sb = sb & "    matchRule:{ " & f(9) & " }," & vbCrLf

        ' conditions
        Dim hasC : hasC = False
        Dim ci2
        For ci2 = 0 To 3
            Dim base2 : base2 = 11 + ci2 * 3
            If f(base2) <> "" Or f(base2+1) <> "" Then
                If Not hasC Then sb = sb & "    conditions:[" & vbCrLf : hasC = True
                Dim cl : cl = "      { l:" & JsStr(f(base2)) & ", v:" & JsStr(f(base2+1))
                If f(base2+2) <> "" Then cl = cl & ", s:" & JsStr(f(base2+2))
                sb = sb & cl & " }," & vbCrLf
            End If
        Next
        If hasC Then sb = sb & "    ]," & vbCrLf

        ' amounts
        Dim amtCnt : amtCnt = CInt(f(23))
        If amtCnt > 0 Then
            sb = sb & "    amounts:[" & vbCrLf
            Dim amti2
            For amti2 = 0 To amtCnt - 1
                Dim abase : abase = 24 + amti2 * 2
                sb = sb & "      { c:" & JsStr(f(abase)) & ", a:" & JsStr(f(abase+1)) & " }," & vbCrLf
            Next
            sb = sb & "    ]," & vbCrLf
        End If

        sb = sb & "    note:" & JsStr(f(10)) & "," & vbCrLf
        sb = sb & "  }," & vbCrLf
    Next
    sb = sb & "];" & vbCrLf
    BuildDEDUCTIONSjs = sb
End Function

' =====================================================================
' 3. Read UTF-8 file without BOM
' =====================================================================
Function ReadUTF8(path)
    Dim stream
    Set stream = CreateObject("ADODB.Stream")
    stream.Charset = "utf-8"
    stream.Open
    stream.LoadFromFile path
    ReadUTF8 = stream.ReadText
    stream.Close
End Function

' =====================================================================
' 4. Write UTF-8 file without BOM
' =====================================================================
Sub WriteUTF8(path, content)
    ' Write with BOM first, then strip BOM bytes
    Dim s1
    Set s1 = CreateObject("ADODB.Stream")
    s1.Charset = "utf-8"
    s1.Open
    s1.WriteText content
    s1.Position = 0
    s1.Type = 1 ' binary
    s1.Position = 3 ' skip 3-byte BOM
    Dim s2
    Set s2 = CreateObject("ADODB.Stream")
    s2.Type = 1
    s2.Open
    s1.CopyTo s2
    s2.SaveToFile path, 2
    s1.Close
    s2.Close
End Sub

' =====================================================================
' 5. Build HTML
' =====================================================================
Sub BuildHTML(cards)
    Log Chr(76) & Chr(111) & Chr(97) & Chr(100) & Chr(105) & Chr(110) & Chr(103) & Chr(32) & Chr(116) & Chr(101) & Chr(109) & Chr(112) & Chr(108) & Chr(97) & Chr(116) & Chr(101) & Chr(46) & Chr(46) & Chr(46)
    If Not fso.FileExists(TMPL) Then Die Chr(84) & Chr(101) & Chr(109) & Chr(112) & Chr(108) & Chr(97) & Chr(116) & Chr(101) & Chr(32) & Chr(110) & Chr(111) & Chr(116) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(58) & Chr(32) & TMPL

    Dim tmpl : tmpl = ReadUTF8(TMPL)

    Dim deductionsJs : deductionsJs = BuildDEDUCTIONSjs(cards)
    Dim today : today = Year(Now) & "-" & Z2(Month(Now)) & "-" & Z2(Day(Now))

    Dim html : html = tmpl
    html = Replace(html, "{{DEDUCTIONS_JS}}", deductionsJs)
    html = Replace(html, "{{BUILD_DATE}}", today)

    Dim distDir : distDir = fso.GetParentFolderName(OUTPUT)
    If Not fso.FolderExists(distDir) Then fso.CreateFolder(distDir)

    WriteUTF8 OUTPUT, html
    Log Chr(72) & Chr(84) & Chr(77) & Chr(76) & Chr(32) & Chr(103) & Chr(101) & Chr(110) & Chr(101) & Chr(114) & Chr(97) & Chr(116) & Chr(101) & Chr(100) & Chr(58) & Chr(32) & OUTPUT
    BuildHTML = html
End Sub

' =====================================================================
' 6. Verify
' =====================================================================
Function Verify(cards, html)
    Log Chr(45) & Chr(45) & Chr(45) & Chr(32) & Chr(86) & Chr(101) & Chr(114) & Chr(105) & Chr(102) & Chr(105) & Chr(99) & Chr(97) & Chr(116) & Chr(105) & Chr(111) & Chr(110) & Chr(32) & Chr(45) & Chr(45) & Chr(45)
    Dim ok : ok = True

    ' Count id:"..." excluding xxx_yyy
    Dim pos, cnt
    cnt = 0 : pos = 1
    Do
        pos = InStr(pos, html, "id:""")
        If pos = 0 Then Exit Do
        Dim idVal : idVal = Mid(html, pos+4, InStr(pos+4, html, """") - pos - 4)
        If idVal <> "xxx_yyy" Then cnt = cnt + 1
        pos = pos + 4
    Loop
    If cnt = UBound(cards)+1 Then
        Log Chr(32) & Chr(32) & Chr(91) & Chr(79) & Chr(75) & Chr(93) & Chr(32) & Chr(67) & Chr(97) & Chr(114) & Chr(100) & Chr(32) & Chr(99) & Chr(111) & Chr(117) & Chr(110) & Chr(116) & Chr(58) & Chr(32) & cnt
    Else
        Log Chr(32) & Chr(32) & Chr(91) & Chr(88) & Chr(93) & Chr(32) & Chr(67) & Chr(97) & Chr(114) & Chr(100) & Chr(32) & Chr(99) & Chr(111) & Chr(117) & Chr(110) & Chr(116) & Chr(32) & Chr(109) & Chr(105) & Chr(115) & Chr(109) & Chr(97) & Chr(116) & Chr(99) & Chr(104) & Chr(58) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(61) & (UBound(cards)+1) & Chr(32) & Chr(72) & Chr(84) & Chr(77) & Chr(76) & Chr(61) & cnt
        ok = False
    End If

    Dim req(4)
    req(0)="dep_minor" : req(1)="spouse_ctrl" : req(2)="kiso" : req(3)="kyuyo" : req(4)="student"
    Dim ri
    For ri = 0 To 4
        If InStr(html, "id:""" & req(ri) & """") > 0 Then
            Log Chr(32) & Chr(32) & Chr(91) & Chr(79) & Chr(75) & Chr(93) & Chr(32) & Chr(82) & Chr(101) & Chr(113) & Chr(117) & Chr(105) & Chr(114) & Chr(101) & Chr(100) & Chr(32) & Chr(99) & Chr(97) & Chr(114) & Chr(100) & Chr(58) & Chr(32) & req(ri)
        Else
            Log Chr(32) & Chr(32) & Chr(91) & Chr(88) & Chr(93) & Chr(32) & Chr(77) & Chr(105) & Chr(115) & Chr(115) & Chr(105) & Chr(110) & Chr(103) & Chr(32) & Chr(99) & Chr(97) & Chr(114) & Chr(100) & Chr(58) & Chr(32) & req(ri)
            ok = False
        End If
    Next

    If InStr(html, Chr(99) & Chr(111) & Chr(110) & Chr(115) & Chr(116) & Chr(32) & Chr(68) & Chr(69) & Chr(68) & Chr(85) & Chr(67) & Chr(84) & Chr(73) & Chr(79) & Chr(78) & Chr(83) & Chr(32) & Chr(61) & Chr(32) & Chr(91)) > 0 Then
        Log Chr(32) & Chr(32) & Chr(91) & Chr(79) & Chr(75) & Chr(93) & Chr(32) & Chr(68) & Chr(69) & Chr(68) & Chr(85) & Chr(67) & Chr(84) & Chr(73) & Chr(79) & Chr(78) & Chr(83) & Chr(32) & Chr(100) & Chr(97) & Chr(116) & Chr(97) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100)
    Else
        Log Chr(32) & Chr(32) & Chr(91) & Chr(88) & Chr(93) & Chr(32) & Chr(68) & Chr(69) & Chr(68) & Chr(85) & Chr(67) & Chr(84) & Chr(73) & Chr(79) & Chr(78) & Chr(83) & Chr(32) & Chr(100) & Chr(97) & Chr(116) & Chr(97) & Chr(32) & Chr(109) & Chr(105) & Chr(115) & Chr(115) & Chr(105) & Chr(110) & Chr(103)
        ok = False
    End If

    If ok Then Log Chr(45) & Chr(45) & Chr(45) & Chr(32) & Chr(65) & Chr(108) & Chr(108) & Chr(32) & Chr(99) & Chr(104) & Chr(101) & Chr(99) & Chr(107) & Chr(115) & Chr(32) & Chr(112) & Chr(97) & Chr(115) & Chr(115) & Chr(101) & Chr(100) & Chr(32) & Chr(45) & Chr(45) & Chr(45) Else Log Chr(45) & Chr(45) & Chr(45) & Chr(32) & Chr(86) & Chr(101) & Chr(114) & Chr(105) & Chr(102) & Chr(105) & Chr(99) & Chr(97) & Chr(116) & Chr(105) & Chr(111) & Chr(110) & Chr(32) & Chr(102) & Chr(97) & Chr(105) & Chr(108) & Chr(101) & Chr(100) & Chr(32) & Chr(45) & Chr(45) & Chr(45)
    Verify = ok
End Function

' =====================================================================
' Main
' =====================================================================
Log Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61)
Log Chr(32) & Chr(84) & Chr(97) & Chr(120) & Chr(32) & Chr(71) & Chr(117) & Chr(105) & Chr(100) & Chr(101) & Chr(32) & Chr(72) & Chr(84) & Chr(77) & Chr(76) & Chr(32) & Chr(66) & Chr(117) & Chr(105) & Chr(108) & Chr(100) & Chr(101) & Chr(114) & Chr(32) & Chr(40) & Chr(86) & Chr(66) & Chr(83) & Chr(99) & Chr(114) & Chr(105) & Chr(112) & Chr(116) & Chr(41)
Log Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61) & Chr(61)

Dim cards : cards = ReadCards()
Dim html  : html  = BuildHTML(cards)
Dim ok    : ok    = Verify(cards, html)
FlushLog
Log Chr(76) & Chr(111) & Chr(103) & Chr(58) & Chr(32) & LOG_FILE
If ok Then
    Log Chr(68) & Chr(111) & Chr(110) & Chr(101) & Chr(33)
    WScript.Quit 0
Else
    Log Chr(87) & Chr(97) & Chr(114) & Chr(110) & Chr(105) & Chr(110) & Chr(103) & Chr(58) & Chr(32) & Chr(105) & Chr(115) & Chr(115) & Chr(117) & Chr(101) & Chr(115) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(46) & Chr(32) & Chr(67) & Chr(104) & Chr(101) & Chr(99) & Chr(107) & Chr(32) & Chr(100) & Chr(105) & Chr(115) & Chr(116) & Chr(92) & Chr(116) & Chr(97) & Chr(120) & Chr(95) & Chr(103) & Chr(117) & Chr(105) & Chr(100) & Chr(101) & Chr(46) & Chr(104) & Chr(116) & Chr(109) & Chr(108)
    WScript.Quit 1
End If
