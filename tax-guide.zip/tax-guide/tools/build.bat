@echo off
chcp 65001 > nul
title Tax Guide - HTML Builder

echo ============================================================
echo  Tax Guide HTML Builder
echo  No Python required - Windows built-in only
echo ============================================================
echo.

cd /d "%~dp0.."

cscript //nologo tools\build.js
set BUILD_RESULT=%errorlevel%

echo.
if %BUILD_RESULT% equ 0 (
    echo ============================================================
    echo  Done! Check dist\tax_guide.html
echo ============================================================
    echo.
    set /p OPEN="Open in browser? [Y/N]: "
    if /i "%OPEN%"=="Y" (
        start dist\tax_guide.html
    )
) else (
    echo ============================================================
    echo  Error occurred. See messages above.
    echo ============================================================
    echo.
    echo  Common causes:
    echo    - Microsoft Excel is not installed
    echo    - data\tax_guide_cards.xlsx is open in Excel
    echo    - Invalid badge color in column E
    echo.
    echo  See tools\logs folder for details.
)

echo.
pause
