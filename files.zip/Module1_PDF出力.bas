'==============================================================================
' モジュール名  : Module1_PDF出力
' 概要         : 「お知らせ」シートをPDF化し、SharePoint同期フォルダへ上書き保存する
' 対象ファイル  : チームごとのExcelブック（A/B/C/D それぞれに配置）
' 作成日       : 2025年
' 依存ライブラリ: Excel標準VBAのみ（外部参照不要）
'==============================================================================

Option Explicit

' ─────────────────────────────────────────────
'  ★ ここだけ各ブックで変更する設定値 ★
' ─────────────────────────────────────────────
Private Const TEAM_PDF_NAME As String = "teamA.pdf"   ' 出力するPDFファイル名
                                                        ' teamB.pdf / teamC.pdf / teamD.pdf に変更
Private Const NOTICE_SHEET_NAME As String = "お知らせ" ' PDF化するシート名（固定）
Private Const SETTINGS_SHEET_NAME As String = "_設定"  ' 設定保存用隠しシート名（固定）
Private Const SETTINGS_CELL_SYNC_ROOT As String = "B1" ' 同期ルートパスを保存するセル
' ─────────────────────────────────────────────

'==============================================================================
' Public Sub : ExportNoticeToPDF
' 概要       : メインの「PDF出力」処理。ボタンに登録するサブルーチン。
'==============================================================================
Public Sub ExportNoticeToPDF()
    Dim syncRoot As String
    Dim outputPath As String
    Dim noticeSheet As Worksheet

    ' ── 1. 「お知らせ」シートの存在確認 ──────────────────────────────
    If Not SheetExists(NOTICE_SHEET_NAME) Then
        MsgBox "『" & NOTICE_SHEET_NAME & "』シートが見つかりません。" & vbCrLf & _
               "シート名を確認してください。", _
               vbCritical, "シートエラー"
        Exit Sub
    End If
    Set noticeSheet = ThisWorkbook.Sheets(NOTICE_SHEET_NAME)

    ' ── 2. 出力先フォルダ（currentフォルダ）の取得 ──────────────────
    syncRoot = GetOrSetSyncRoot()
    If syncRoot = "" Then
        ' ユーザーがフォルダ選択をキャンセルした場合
        MsgBox "出力先フォルダが設定されていないためキャンセルしました。", _
               vbInformation, "キャンセル"
        Exit Sub
    End If

    ' ── 3. currentフォルダの存在確認 ────────────────────────────────
    If Not FolderExists(syncRoot) Then
        MsgBox "出力先フォルダが見つかりません：" & vbCrLf & syncRoot & vbCrLf & vbCrLf & _
               "フォルダが存在するか確認し、[設定リセット]ボタン（または ResetSyncRoot）で" & _
               "再設定してください。", _
               vbCritical, "フォルダ未検出"
        ' 保存パスをクリアして次回再選択できるようにする
        SaveSyncRoot ""
        Exit Sub
    End If

    ' ── 4. 出力フルパスの組み立て ───────────────────────────────────
    outputPath = EnsureTrailingBackslash(syncRoot) & TEAM_PDF_NAME

    ' ── 5. 印刷範囲の確認・自動設定 ────────────────────────────────
    Call EnsurePrintArea(noticeSheet)

    ' ── 6. PDF出力実行 ──────────────────────────────────────────────
    On Error GoTo ErrHandler
    noticeSheet.ExportAsFixedFormat _
        Type:=xlTypePDF, _
        Filename:=outputPath, _
        Quality:=xlQualityStandard, _
        IncludeDocProperties:=False, _
        IgnorePrintAreas:=False, _
        OpenAfterPublish:=False

    MsgBox "PDF出力が完了しました。" & vbCrLf & vbCrLf & _
           "保存先：" & outputPath, _
           vbInformation, "完了"
    Exit Sub

ErrHandler:
    Dim errNum As Long
    Dim errMsg As String
    errNum = Err.Number
    errMsg = Err.Description

    ' エラー種別ごとに次アクションを案内
    Dim userMsg As String
    Select Case errNum
        Case 70   ' アクセス拒否（ファイルが開かれている等）
            userMsg = "PDFファイルが他のアプリで開かれている可能性があります。" & vbCrLf & _
                      "PDFビューアを閉じてから、再度ボタンを押してください。"
        Case 76   ' フォルダ未存在
            userMsg = "出力先フォルダが見つかりません。" & vbCrLf & _
                      "OneDrive/SharePointの同期が完了しているか確認し、" & vbCrLf & _
                      "[設定リセット]で出力先を再設定してください。"
        Case Else
            userMsg = "予期しないエラーが発生しました。" & vbCrLf & _
                      "エラー番号：" & errNum & vbCrLf & _
                      "詳細：" & errMsg & vbCrLf & vbCrLf & _
                      "・PDFが開かれていないか確認してください。" & vbCrLf & _
                      "・フォルダへの書き込み権限を確認してください。"
    End Select

    MsgBox userMsg, vbCritical, "PDF出力エラー"
End Sub

'==============================================================================
' Public Sub : ResetSyncRoot
' 概要       : 出力先フォルダを手動で再設定する。「設定リセット」ボタンに登録。
'==============================================================================
Public Sub ResetSyncRoot()
    SaveSyncRoot ""  ' 一旦クリア
    Dim newPath As String
    newPath = GetOrSetSyncRoot()
    If newPath <> "" Then
        MsgBox "出力先フォルダを設定しました。" & vbCrLf & newPath, _
               vbInformation, "設定完了"
    Else
        MsgBox "キャンセルされました。設定は変更されていません。", _
               vbInformation, "キャンセル"
    End If
End Sub

'==============================================================================
' Private Function : GetOrSetSyncRoot
' 概要    : 保存済みパスを返す。未設定または無効なら選択ダイアログを表示して保存。
' 戻り値  : 有効なフォルダパス文字列、またはキャンセル時は ""
'==============================================================================
Private Function GetOrSetSyncRoot() As String
    Dim savedPath As String
    savedPath = LoadSyncRoot()

    ' 保存済みパスが有効かチェック
    If savedPath <> "" And FolderExists(savedPath) Then
        GetOrSetSyncRoot = savedPath
        Exit Function
    End If

    ' 未設定 or 無効→ダイアログで選択させる
    MsgBox "出力先の「current」フォルダを選択してください。" & vbCrLf & vbCrLf & _
           "例：C:\Users\YourName\OneDrive - 会社名\現場\current", _
           vbInformation, "出力先フォルダの選択"

    Dim selectedPath As String
    selectedPath = SelectFolder("「current」フォルダを選択してください")

    If selectedPath = "" Then
        GetOrSetSyncRoot = ""
        Exit Function
    End If

    ' 選択されたパスを保存
    SaveSyncRoot selectedPath
    GetOrSetSyncRoot = selectedPath
End Function

'==============================================================================
' Private Sub : EnsurePrintArea
' 概要    : 印刷範囲が未設定のとき、UsedRange＋余白を考慮して自動設定する。
'           図形がはみ出さないよう1行1列余裕を持たせる。
'           既設定なら何もしない（既存ページ設定を尊重）。
'==============================================================================
Private Sub EnsurePrintArea(ws As Worksheet)
    ' すでに印刷範囲が設定されていれば何もしない
    If ws.PageSetup.PrintArea <> "" Then Exit Sub

    ' UsedRange に余裕を加えた範囲を印刷範囲に設定
    Dim ur As Range
    Set ur = ws.UsedRange

    Dim lastRow As Long
    Dim lastCol As Long
    lastRow = ur.Row + ur.Rows.Count - 1
    lastCol = ur.Column + ur.Columns.Count - 1

    ' 図形が UsedRange 外にはみ出していないか確認して余裕行/列を追加
    lastRow = GetLastRowConsideringShapes(ws, lastRow)
    lastCol = GetLastColConsideringShapes(ws, lastCol)

    ' 印刷範囲を設定（1行1列余裕を加える、ただし超過は防ぐ）
    Dim maxRow As Long
    Dim maxCol As Long
    maxRow = Application.Min(lastRow + 1, ws.Rows.Count)
    maxCol = Application.Min(lastCol + 1, ws.Columns.Count)

    ws.PageSetup.PrintArea = ws.Range(ws.Cells(1, 1), ws.Cells(maxRow, maxCol)).Address
End Sub

'==============================================================================
' Private Function : GetLastRowConsideringShapes
' 概要    : シート上の図形の最下端行を考慮して、最終行を返す。
'==============================================================================
Private Function GetLastRowConsideringShapes(ws As Worksheet, currentLastRow As Long) As Long
    Dim shp As Shape
    Dim shapeBottom As Long
    Dim maxRow As Long
    maxRow = currentLastRow

    For Each shp In ws.Shapes
        ' 図形の下端セル行を求める
        On Error Resume Next
        shapeBottom = ws.Rows(1).Height  ' ダミー初期化
        Dim bottomCell As Range
        Set bottomCell = ws.Cells.Find(What:="*", _
            After:=ws.Cells(1, 1), _
            LookIn:=xlValues, _
            SearchOrder:=xlByRows, _
            SearchDirection:=xlPrevious)
        On Error GoTo 0

        ' 図形の Top+Height から行インデックスを概算
        Dim shapeEndRow As Long
        shapeEndRow = 0
        On Error Resume Next
        shapeEndRow = ws.Rows(1).Height
        Dim r As Long
        Dim cumH As Double
        cumH = 0
        For r = 1 To ws.Rows.Count
            cumH = cumH + ws.Rows(r).Height
            If cumH >= shp.Top + shp.Height Then
                shapeEndRow = r
                Exit For
            End If
        Next r
        On Error GoTo 0

        If shapeEndRow > maxRow Then maxRow = shapeEndRow
    Next shp

    GetLastRowConsideringShapes = maxRow
End Function

'==============================================================================
' Private Function : GetLastColConsideringShapes
' 概要    : シート上の図形の最右端列を考慮して、最終列を返す。
'==============================================================================
Private Function GetLastColConsideringShapes(ws As Worksheet, currentLastCol As Long) As Long
    Dim shp As Shape
    Dim maxCol As Long
    maxCol = currentLastCol

    For Each shp In ws.Shapes
        Dim shapeEndCol As Long
        shapeEndCol = 0
        On Error Resume Next
        Dim c As Long
        Dim cumW As Double
        cumW = 0
        For c = 1 To ws.Columns.Count
            cumW = cumW + ws.Columns(c).Width
            If cumW >= shp.Left + shp.Width Then
                shapeEndCol = c
                Exit For
            End If
        Next c
        On Error GoTo 0

        If shapeEndCol > maxCol Then maxCol = shapeEndCol
    Next shp

    GetLastColConsideringShapes = maxCol
End Function

'==============================================================================
' Private Function : SelectFolder
' 概要    : フォルダ選択ダイアログを表示し、選択されたパスを返す。
'           キャンセル時は "" を返す。
'==============================================================================
Private Function SelectFolder(dialogTitle As String) As String
    Dim shell As Object
    Set shell = CreateObject("Shell.Application")

    Dim folder As Object
    Set folder = shell.BrowseForFolder(0, dialogTitle, 0, "")

    If folder Is Nothing Then
        SelectFolder = ""
    Else
        SelectFolder = folder.Self.Path
    End If
End Function

'==============================================================================
' Private Sub : SaveSyncRoot
' 概要    : 隠しシート（_設定）にパスを保存する。シートが無ければ作成する。
'==============================================================================
Private Sub SaveSyncRoot(path As String)
    Dim ws As Worksheet

    If Not SheetExists(SETTINGS_SHEET_NAME) Then
        ' 隠しシートを新規作成
        Set ws = ThisWorkbook.Sheets.Add(After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.Count))
        ws.Name = SETTINGS_SHEET_NAME
        ws.Visible = xlSheetVeryHidden  ' VBAからしか見えないよう隠す
        ws.Cells(1, 1).Value = "出力先フォルダ（currentパス）"
    Else
        Set ws = ThisWorkbook.Sheets(SETTINGS_SHEET_NAME)
    End If

    ws.Range(SETTINGS_CELL_SYNC_ROOT).Value = path
    ThisWorkbook.Save  ' 設定を即座に保存
End Sub

'==============================================================================
' Private Function : LoadSyncRoot
' 概要    : 隠しシートからパスを読み込んで返す。未設定なら "" を返す。
'==============================================================================
Private Function LoadSyncRoot() As String
    If Not SheetExists(SETTINGS_SHEET_NAME) Then
        LoadSyncRoot = ""
        Exit Function
    End If

    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets(SETTINGS_SHEET_NAME)
    LoadSyncRoot = Trim(ws.Range(SETTINGS_CELL_SYNC_ROOT).Value)
End Function

'==============================================================================
' Private Function : SheetExists
' 概要    : 指定名のシートがブック内に存在するか確認する。
'==============================================================================
Private Function SheetExists(sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Sheets(sheetName)
    On Error GoTo 0
    SheetExists = Not (ws Is Nothing)
End Function

'==============================================================================
' Private Function : FolderExists
' 概要    : 指定パスのフォルダが存在するか確認する。
'==============================================================================
Private Function FolderExists(folderPath As String) As Boolean
    If folderPath = "" Then
        FolderExists = False
        Exit Function
    End If
    FolderExists = (Dir(EnsureTrailingBackslash(folderPath), vbDirectory) <> "")
End Function

'==============================================================================
' Private Function : EnsureTrailingBackslash
' 概要    : パス末尾に「\」が無ければ付加して返す。
'==============================================================================
Private Function EnsureTrailingBackslash(path As String) As String
    If Right(path, 1) <> "\" Then
        EnsureTrailingBackslash = path & "\"
    Else
        EnsureTrailingBackslash = path
    End If
End Function
