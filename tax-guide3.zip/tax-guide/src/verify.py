#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify.py  ―  2つのHTMLファイルのカードデータ同一性を検証するツール
使い方:  python src/verify.py dist/tax_guide.html 旧版/tax_guide.html
"""
import sys, re
from pathlib import Path

def parse_cards(html):
    """DEDUCTIONSブロックから各カードの実値を抽出"""
    m = re.search(r'const DEDUCTIONS = \[(.*?)\];', html, re.DOTALL)
    if not m:
        return None, 'DEDUCTIONSデータが見つかりません'
    block = m.group(1)
    cards = []
    for card_block in re.split(r'\n  /\* ----', block):
        id_m = re.search(r'id:"([^"]+)"', card_block)
        if not id_m or id_m.group(1) == 'xxx_yyy':
            continue
        conds = re.findall(r'\{ l:"([^"]*)"[^}]*v:"([^"]*)"(?:[^}]*s:"([^"]*)")?', card_block)
        amts  = re.findall(r'\{ c:"([^"]*)"[^}]*a:"([^"]*)"', card_block)
        title_m  = re.search(r'title:"([^"]+)"', card_block)
        amt_m    = re.search(r'amountShort:"([^"]+)"', card_block)
        income_m = re.search(r'incomeReq:"([^"]+)"', card_block)
        note_m   = re.search(r'note:"(.*?)"(?:,\n  }|,\n})', card_block, re.DOTALL)
        cards.append({
            'id':          id_m.group(1),
            'title':       title_m.group(1) if title_m else '',
            'amountShort': amt_m.group(1) if amt_m else '',
            'incomeReq':   income_m.group(1) if income_m else '',
            'note':        note_m.group(1) if note_m else '',
            'conditions':  [(l, v, s) for l, v, s in conds],
            'amounts':     [(c, a) for c, a in amts],
        })
    return cards, None


def verify(file_a, file_b):
    html_a = Path(file_a).read_text(encoding='utf-8')
    html_b = Path(file_b).read_text(encoding='utf-8')

    cards_a, err_a = parse_cards(html_a)
    cards_b, err_b = parse_cards(html_b)

    if err_a:
        print(f'❌ {file_a}: {err_a}')
        return False
    if err_b:
        print(f'❌ {file_b}: {err_b}')
        return False

    print(f'ファイルA: {file_a}  ({len(cards_a)}件)')
    print(f'ファイルB: {file_b}  ({len(cards_b)}件)')
    print()

    all_ok = True

    # 件数確認
    if len(cards_a) != len(cards_b):
        print(f'❌ カード件数が異なります: A={len(cards_a)} B={len(cards_b)}')
        all_ok = False

    # 各カードの比較
    ids_a = {c['id']: c for c in cards_a}
    ids_b = {c['id']: c for c in cards_b}

    only_a = set(ids_a) - set(ids_b)
    only_b = set(ids_b) - set(ids_a)
    if only_a:
        print(f'❌ Aのみに存在するカード: {only_a}')
        all_ok = False
    if only_b:
        print(f'❌ Bのみに存在するカード: {only_b}')
        all_ok = False

    for id_ in sorted(set(ids_a) & set(ids_b)):
        ca, cb = ids_a[id_], ids_b[id_]
        issues = []
        for field in ['title', 'amountShort', 'incomeReq', 'note']:
            if ca[field] != cb[field]:
                issues.append(f'{field}が異なる')
        if ca['conditions'] != cb['conditions']:
            issues.append(f'conditions ({len(ca["conditions"])}件 vs {len(cb["conditions"])}件)')
        if ca['amounts'] != cb['amounts']:
            issues.append(f'amounts ({len(ca["amounts"])}件 vs {len(cb["amounts"])}件)')

        if issues:
            all_ok = False
            print(f'❌ {id_}: {", ".join(issues)}')
            # 詳細を表示
            for field in ['title', 'amountShort', 'incomeReq']:
                if ca[field] != cb[field]:
                    print(f'   {field}:')
                    print(f'     A: {ca[field][:80]!r}')
                    print(f'     B: {cb[field][:80]!r}')
        else:
            print(f'✅ {id_}')

    print()
    if all_ok:
        print('✅ 全カードのデータが一致しています。')
    else:
        print('❌ 差分が見つかりました。上記を確認してください。')
    return all_ok


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print(f'使い方: python {sys.argv[0]} ファイルA.html ファイルB.html')
        sys.exit(1)
    ok = verify(sys.argv[1], sys.argv[2])
    sys.exit(0 if ok else 1)
