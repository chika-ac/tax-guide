// build.js - Excel to HTML generator (JScript / WSH)
// Usage: cscript //nologo tools\build.js
// Requirements: Windows, Microsoft Excel installed (no Python needed)

var ROOT = (function() {
  var fso = new ActiveXObject("Scripting.FileSystemObject");
  return fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName));
})();

var fso   = new ActiveXObject("Scripting.FileSystemObject");
var DATA_XLSX   = ROOT + "\\data\\tax_guide_cards.xlsx";
var TEMPLATE    = ROOT + "\\src\\template.html";
var OUTPUT_HTML = ROOT + "\\dist\\tax_guide.html";
var LOG_DIR     = ROOT + "\\tools\\logs";

var now = new Date();
function pad2(n){ return n < 10 ? "0"+n : ""+n; }
var ts = now.getFullYear() + pad2(now.getMonth()+1) + pad2(now.getDate()) +
         "_" + pad2(now.getHours()) + pad2(now.getMinutes()) + pad2(now.getSeconds());
var LOG_FILE = LOG_DIR + "\\build_" + ts + ".log";
var logLines = [];

function log(msg) {
  var line = "[" + pad2(now.getHours())+":"+pad2(now.getMinutes())+":"+pad2(now.getSeconds()) + "] " + msg;
  WScript.Echo(line);
  logLines.push(line);
}

function flushLog() {
  if (!fso.FolderExists(LOG_DIR)) fso.CreateFolder(LOG_DIR);
  var f = fso.CreateTextFile(LOG_FILE, true, true);
  f.WriteLine(logLines.join("\r\n"));
  f.Close();
}

function die(msg) {
  log("ERROR: " + msg);
  flushLog();
  WScript.Quit(1);
}

// Badge color mapping (Japanese Excel value -> CSS class)
var BADGE_MAP = {};
BADGE_MAP["\u914d\u5076\u8005\uff08\u9752\uff09"]          = "b-blue";
BADGE_MAP["\u6276\u990a\uff08\u7dd1\uff09"]                = "b-green";
BADGE_MAP["\u969c\u5bb3\u8005\uff08\u6a59\uff09"]          = "b-amber";
BADGE_MAP["\u3072\u3068\u308a\u89aa/\u5bfa\u5a66\uff08\u8d64\uff09"] = "b-red";
BADGE_MAP["\u672c\u4eba\u305d\u306e\u4ed6\uff08\u7d2b\uff09"] = "b-purple";

// Sheet name
var SHEET_NAME = "\u30ab\u30fc\u30c9\u4e00\u89a7";

function jsStr(s) {
  if (!s) return '""';
  s = String(s);
  s = s.replace(/\\/g, "\\\\");
  s = s.replace(/"/g, '\\"');
  s = s.replace(/\r\n/g, "\\n");
  s = s.replace(/\r/g, "\\n");
  s = s.replace(/\n/g, "\\n");
  return '"' + s + '"';
}

function readExcel(path) {
  log("Reading Excel: " + path);
  if (!fso.FileExists(path)) {
    die("Excel file not found: " + path);
  }
  var xl;
  try {
    xl = new ActiveXObject("Excel.Application");
  } catch(e) {
    die("Microsoft Excel not found. Please install Excel.");
  }
  xl.Visible = false;
  xl.DisplayAlerts = false;

  var wb, ws;
  try {
    wb = xl.Workbooks.Open(path, 0, true);
    ws = wb.Sheets(SHEET_NAME);
  } catch(e) {
    try { xl.Quit(); } catch(e2){}
    die("Sheet '" + SHEET_NAME + "' not found. Check the Excel file.");
  }

  var cards = [];
  var errors = [];
  var row = 4;

  while (true) {
    var cellA = ws.Cells(row, 1).Value;
    if (!cellA || String(cellA).replace(/^\s+|\s+$/g,"") === "") break;

    var cardId    = String(ws.Cells(row,1).Value||"").replace(/^\s+|\s+$/g,"");
    var title     = String(ws.Cells(row,2).Value||"").replace(/^\s+|\s+$/g,"");
    var sectionRaw= String(ws.Cells(row,3).Value||"").replace(/^\s+|\s+$/g,"");
    var section   = (sectionRaw === "\u672c\u4eba") ? "self" : "";
    var sortRaw   = ws.Cells(row,4).Value;
    var sortInc   = (sortRaw !== null && sortRaw !== undefined && sortRaw !== "") ? parseInt(sortRaw) : 0;
    var badgeName = String(ws.Cells(row,5).Value||"").replace(/^\s+|\s+$/g,"");
    var badgeText = String(ws.Cells(row,6).Value||"").replace(/^\s+|\s+$/g,"");
    var isNewRaw  = String(ws.Cells(row,7).Value||"").toUpperCase().replace(/^\s+|\s+$/g,"");
    var isNew     = (isNewRaw === "TRUE");
    var incomeReq = String(ws.Cells(row,8).Value||"").replace(/^\s+|\s+$/g,"");
    var amountSh  = String(ws.Cells(row,9).Value||"").replace(/^\s+|\s+$/g,"");

    var badge = BADGE_MAP[badgeName] || "";
    if (!badge)   errors.push("Row " + row + ": Invalid badge color [" + badgeName + "]");
    if (!title)   errors.push("Row " + row + " (ID:" + cardId + "): Title is empty");
    if (!incomeReq) errors.push("Row " + row + " (ID:" + cardId + "): Column H is empty");

    var conditions = [];
    for (var ci = 0; ci < 4; ci++) {
      var base = 10 + ci * 3;
      var lVal = String(ws.Cells(row,base).Value    ||"").replace(/^\s+|\s+$/g,"");
      var vVal = String(ws.Cells(row,base+1).Value  ||"").replace(/^\s+|\s+$/g,"");
      var sVal = String(ws.Cells(row,base+2).Value  ||"").replace(/^\s+|\s+$/g,"");
      if (lVal || vVal) conditions.push({l:lVal, v:vVal, s:sVal});
    }

    var amtRaw = String(ws.Cells(row,22).Value||"").replace(/^\s+|\s+$/g,"");
    var amounts = [];
    var amtLines = amtRaw.split("\n");
    for (var ai = 0; ai < amtLines.length; ai++) {
      var line = amtLines[ai].replace(/^\s+|\s+$/g,"");
      var arrow = line.indexOf("\u2192");
      if (arrow >= 0) {
        amounts.push({
          c: line.substring(0, arrow).replace(/^\s+|\s+$/g,""),
          a: line.substring(arrow+1).replace(/^\s+|\s+$/g,"")
        });
      }
    }

    var matchRule = String(ws.Cells(row,23).Value||"").replace(/^\s+|\s+$/g,"");
    var note      = String(ws.Cells(row,24).Value||"").replace(/^\s+|\s+$/g,"");

    cards.push({id:cardId, section:section, sortIncome:sortInc, badge:badge,
                badgeText:badgeText, title:title, isNew:isNew,
                amountShort:amountSh, incomeReq:incomeReq, matchRule:matchRule,
                conditions:conditions, amounts:amounts, note:note});
    row++;
  }

  try { wb.Close(false); } catch(e){}
  try { xl.Quit(); }       catch(e){}

  if (errors.length > 0) {
    log("--- Input errors ---");
    for (var ei = 0; ei < errors.length; ei++) log("  [X] " + errors[ei]);
    die(errors.length + " error(s) found. Fix Excel and retry.");
  }

  log("Cards loaded: " + cards.length);
  return cards;
}

function buildDEDUCTIONSjs(cards) {
  var lines = ["const DEDUCTIONS = ["];
  for (var i = 0; i < cards.length; i++) {
    var d = cards[i];
    lines.push("\n  /* ---- " + d.title + " ----*/");
    lines.push("  {");
    lines.push("    id:"+jsStr(d.id)+", sortIncome:"+d.sortIncome+
               ", badge:"+jsStr(d.badge)+", badgeText:"+jsStr(d.badgeText)+",");
    lines.push("    title:"+jsStr(d.title)+",");
    if (d.isNew) lines.push("    isNew:true,");
    lines.push("    amountShort:"+jsStr(d.amountShort)+",");
    lines.push("    incomeReq:"+jsStr(d.incomeReq)+",");
    if (d.section) lines.push("    section:"+jsStr(d.section)+",");
    lines.push("    matchRule:{ "+d.matchRule+" },");
    if (d.conditions.length > 0) {
      lines.push("    conditions:[");
      for (var ci = 0; ci < d.conditions.length; ci++) {
        var c = d.conditions[ci];
        var cl = "      { l:"+jsStr(c.l)+", v:"+jsStr(c.v);
        if (c.s) cl += ", s:"+jsStr(c.s);
        lines.push(cl+" },");
      }
      lines.push("    ],");
    }
    if (d.amounts.length > 0) {
      lines.push("    amounts:[");
      for (var ai = 0; ai < d.amounts.length; ai++) {
        var a = d.amounts[ai];
        lines.push("      { c:"+jsStr(a.c)+", a:"+jsStr(a.a)+" },");
      }
      lines.push("    ],");
    }
    lines.push("    note:"+jsStr(d.note)+",");
    lines.push("  },");
  }
  lines.push("];");
  return lines.join("\r\n");
}

function buildHTML(cards) {
  log("Loading template...");
  if (!fso.FileExists(TEMPLATE)) die("Template not found: " + TEMPLATE);

  var stream = new ActiveXObject("ADODB.Stream");
  stream.Charset = "UTF-8";
  stream.Open();
  stream.LoadFromFile(TEMPLATE);
  var tmpl = stream.ReadText();
  stream.Close();

  var deductionsJs = buildDEDUCTIONSjs(cards);
  var today = now.getFullYear()+"-"+pad2(now.getMonth()+1)+"-"+pad2(now.getDate());
  var html = tmpl.replace("{{DEDUCTIONS_JS}}", deductionsJs);
  html = html.replace("{{BUILD_DATE}}", today);

  var distDir = fso.GetParentFolderName(OUTPUT_HTML);
  if (!fso.FolderExists(distDir)) fso.CreateFolder(distDir);

  var out = new ActiveXObject("ADODB.Stream");
  out.Charset = "UTF-8";
  out.Open();
  out.WriteText(html);
  out.SaveToFile(OUTPUT_HTML, 2);
  out.Close();

  log("HTML generated: " + OUTPUT_HTML);
  return html;
}

function verify(cards, html) {
  log("--- Verification ---");
  var ok = true;
  var idMatches = html.match(/id:"([^"]+)"/g) || [];
  var count = 0;
  for (var i = 0; i < idMatches.length; i++) {
    if (idMatches[i].indexOf("xxx_yyy") < 0) count++;
  }
  if (count === cards.length) {
    log("  [OK] Card count: " + cards.length);
  } else {
    log("  [X] Card count mismatch: Excel=" + cards.length + " HTML=" + count);
    ok = false;
  }
  var required = ["dep_minor","spouse_ctrl","kiso","kyuyo","student"];
  for (var ri = 0; ri < required.length; ri++) {
    if (html.indexOf('id:"'+required[ri]+'"') >= 0) {
      log("  [OK] Required card: " + required[ri]);
    } else {
      log("  [X] Missing card: " + required[ri]);
      ok = false;
    }
  }
  if (html.indexOf("const DEDUCTIONS = [") >= 0) {
    log("  [OK] DEDUCTIONS data found");
  } else {
    log("  [X] DEDUCTIONS data missing");
    ok = false;
  }
  log(ok ? "--- All checks passed ---" : "--- Verification failed ---");
  return ok;
}

// main
log("============================================================");
log(" Tax Guide HTML Builder");
log("============================================================");

var cards = readExcel(DATA_XLSX);
var html  = buildHTML(cards);
var ok    = verify(cards, html);
flushLog();
log("Log: " + LOG_FILE);
if (ok) {
  log("Done!");
  WScript.Quit(0);
} else {
  log("Warning: issues found. Check dist\\tax_guide.html");
  WScript.Quit(1);
}
