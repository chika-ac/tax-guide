' build.vbs - Excel to HTML generator (VBScript / WSH)
' Requirements: Windows built-in, Microsoft Excel installed.
' No Python, no PowerShell signing required.
Option Explicit

' === Global objects and constants ===
Dim fso, BADGE(4,1)
Set fso = CreateObject("Scripting.FileSystemObject")

BADGE(0,0) = ChrW(37197) & ChrW(20598) & ChrW(32773) & ChrW(65288) & ChrW(38738) & ChrW(65289)
BADGE(0,1) = "b-blue"
BADGE(1,0) = ChrW(25206) & ChrW(39178) & ChrW(65288) & ChrW(32209) & ChrW(65289)
BADGE(1,1) = "b-green"
BADGE(2,0) = ChrW(38556) & ChrW(23475) & ChrW(32773) & ChrW(65288) & ChrW(27225) & ChrW(65289)
BADGE(2,1) = "b-amber"
BADGE(3,0) = ChrW(12402) & ChrW(12392) & ChrW(12426) & ChrW(35242) & Chr(47) & ChrW(23521) & ChrW(23142) & ChrW(65288) & ChrW(36196) & ChrW(65289)
BADGE(3,1) = "b-red"
BADGE(4,0) = ChrW(26412) & ChrW(20154) & ChrW(12381) & ChrW(12398) & ChrW(20182) & ChrW(65288) & ChrW(32043) & ChrW(65289)
BADGE(4,1) = "b-purple"

Dim SHEET_NAME, SECTION_SELF, ARROW
SHEET_NAME   = ChrW(12459) & ChrW(12540) & ChrW(12489) & ChrW(19968) & ChrW(35239)
SECTION_SELF = ChrW(26412) & ChrW(20154)
ARROW        = ChrW(8594)

Dim TOOLS_DIR, ROOT_DIR, XLSX, TMPL, OUTPUT_PATH, LOG_DIR
TOOLS_DIR   = fso.GetParentFolderName(WScript.ScriptFullName) & Chr(92)
ROOT_DIR    = fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName)) & Chr(92)
XLSX        = ROOT_DIR & "data" & Chr(92) & "tax_guide_cards.xlsx"
TMPL        = ROOT_DIR & "src"  & Chr(92) & "template.html"
OUTPUT_PATH = ROOT_DIR & "dist" & Chr(92) & "tax_guide.html"
LOG_DIR     = TOOLS_DIR & "logs"

Dim logBuf : logBuf = ""

Function Fmt(dt)
    Fmt = Year(dt) & Z2(Month(dt)) & Z2(Day(dt)) & "_" & Z2(Hour(dt)) & Z2(Minute(dt)) & Z2(Second(dt))
End Function

Function Z2(n)
    Z2 = Right("0" & CStr(n), 2)
End Function

Sub LogMsg(msg)
    Dim line
    line = "[" & Z2(Hour(Now)) & ":" & Z2(Minute(Now)) & ":" & Z2(Second(Now)) & "] " & msg
    WScript.Echo line
    logBuf = logBuf & line & vbCrLf
End Sub

Sub FlushLog(logFile)
    Dim f
    If Not fso.FolderExists(LOG_DIR) Then fso.CreateFolder(LOG_DIR)
    Set f = fso.CreateTextFile(logFile, True, True)
    f.Write logBuf
    f.Close
End Sub

Sub Die(msg, logFile)
    LogMsg "ERROR: " & msg
    FlushLog logFile
    WScript.Quit 1
End Sub

Function GetBadge(name)
    Dim i
    GetBadge = ""
    For i = 0 To 4
        If BADGE(i,0) = name Then
            GetBadge = BADGE(i,1)
            Exit Function
        End If
    Next
End Function

Function JsStr(s)
    Dim t
    t = CStr(s)
    t = Replace(t, Chr(92), Chr(92) & Chr(92))
    t = Replace(t, Chr(34), Chr(92) & Chr(34))
    t = Replace(t, vbCrLf, Chr(92) & "n")
    t = Replace(t, vbCr,   Chr(92) & "n")
    t = Replace(t, vbLf,   Chr(92) & "n")
    JsStr = Chr(34) & t & Chr(34)
End Function

Function TS(v)
    If IsNull(v) Or IsEmpty(v) Then
        TS = ""
    Else
        TS = Trim(CStr(v))
    End If
End Function

Function ReadUTF8(path)
    Dim st
    Set st = CreateObject("ADODB.Stream")
    st.Charset = "utf-8"
    st.Open
    st.LoadFromFile path
    ReadUTF8 = st.ReadText
    st.Close
End Function

Sub WriteUTF8NoBOM(path, content)
    Dim s1, s2
    Set s1 = CreateObject("ADODB.Stream")
    s1.Charset = "utf-8"
    s1.Open
    s1.WriteText content
    s1.Position = 0
    s1.Type = 1
    s1.Position = 3
    Set s2 = CreateObject("ADODB.Stream")
    s2.Type = 1
    s2.Open
    s1.CopyTo s2
    s2.SaveToFile path, 2
    s1.Close
    s2.Close
End Sub

Function ReadCards(logFile)
    Dim xl, wb, ws
    Dim cardsArr(), cardCount
    Dim errList(), errCount
    Dim row, cellA
    Dim cardId, title, secRaw, section
    Dim sortRaw, sortInc
    Dim badgeName, badgeText, badge
    Dim isNewRaw, isNew
    Dim incomeReq, amountSh, sv
    Dim ci, base
    Dim cL0,cV0,cS0, cL1,cV1,cS1, cL2,cV2,cS2, cL3,cV3,cS3
    Dim amtRaw, amtParts, amtCount
    Dim amtC0,amtA0,amtC1,amtA1,amtC2,amtA2,amtC3,amtA3
    Dim amtC4,amtA4,amtC5,amtA5,amtC6,amtA6,amtC7,amtA7
    Dim amtC8,amtA8,amtC9,amtA9
    Dim ai, aline, arrowPos
    Dim matchRule, note
    Dim amti, ei, packed

    LogMsg Chr(82) & Chr(101) & Chr(97) & Chr(100) & Chr(105) & Chr(110) & Chr(103) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(58) & Chr(32) & XLSX
    If Not fso.FileExists(XLSX) Then Die Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(32) & Chr(102) & Chr(105) & Chr(108) & Chr(101) & Chr(32) & Chr(110) & Chr(111) & Chr(116) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(58) & Chr(32) & XLSX, logFile

    On Error Resume Next
    Set xl = CreateObject("Excel.Application")
    If Err.Number <> 0 Then
        On Error GoTo 0
        Die Chr(77) & Chr(105) & Chr(99) & Chr(114) & Chr(111) & Chr(115) & Chr(111) & Chr(102) & Chr(116) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(32) & Chr(110) & Chr(111) & Chr(116) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(46) & Chr(32) & Chr(80) & Chr(108) & Chr(101) & Chr(97) & Chr(115) & Chr(101) & Chr(32) & Chr(105) & Chr(110) & Chr(115) & Chr(116) & Chr(97) & Chr(108) & Chr(108) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(46), logFile
    End If
    On Error GoTo 0

    xl.Visible       = False
    xl.DisplayAlerts = False

    On Error Resume Next
    Set wb = xl.Workbooks.Open(XLSX, 0, True)
    Set ws = wb.Sheets(SHEET_NAME)
    If Err.Number <> 0 Then
        On Error GoTo 0
        xl.Quit
        Die Chr(83) & Chr(104) & Chr(101) & Chr(101) & Chr(116) & Chr(32) & Chr(110) & Chr(111) & Chr(116) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(46) & Chr(32) & Chr(67) & Chr(104) & Chr(101) & Chr(99) & Chr(107) & Chr(32) & Chr(116) & Chr(104) & Chr(101) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(32) & Chr(102) & Chr(105) & Chr(108) & Chr(101) & Chr(46), logFile
    End If
    On Error GoTo 0

    cardCount = 0 : errCount = 0
    ReDim cardsArr(0) : ReDim errList(0)

    row = 4
    Do While True
        cellA = TS(ws.Cells(row, 1).Value)
        If cellA = "" Then Exit Do

        cardId    = TS(ws.Cells(row, 1).Value)
        title     = TS(ws.Cells(row, 2).Value)
        secRaw    = TS(ws.Cells(row, 3).Value)
        section   = ""
        If secRaw = SECTION_SELF Then section = "self"

        sv = ws.Cells(row, 4).Value
        If IsNull(sv) Or IsEmpty(sv) Or CStr(sv) = "" Then
            sortInc = 0
        Else
            sortInc = CInt(sv)
        End If

        badgeName = TS(ws.Cells(row, 5).Value)
        badgeText = TS(ws.Cells(row, 6).Value)
        isNewRaw  = UCase(TS(ws.Cells(row, 7).Value))
        isNew     = (isNewRaw = "TRUE")
        incomeReq = TS(ws.Cells(row, 8).Value)
        amountSh  = TS(ws.Cells(row, 9).Value)

        badge = GetBadge(badgeName)
        If badge = "" Then
            ReDim Preserve errList(errCount)
            errList(errCount) = "Row " & row & ": Invalid badge [" & badgeName & "]"
            errCount = errCount + 1
        End If
        If title = "" Then
            ReDim Preserve errList(errCount)
            errList(errCount) = "Row " & row & " (ID:" & cardId & "): Title empty"
            errCount = errCount + 1
        End If
        If incomeReq = "" Then
            ReDim Preserve errList(errCount)
            errList(errCount) = "Row " & row & " (ID:" & cardId & "): Col H empty"
            errCount = errCount + 1
        End If

        ' conditions: cols J=10 to U=21
        cL0 = TS(ws.Cells(row,10).Value) : cV0 = TS(ws.Cells(row,11).Value) : cS0 = TS(ws.Cells(row,12).Value)
        cL1 = TS(ws.Cells(row,13).Value) : cV1 = TS(ws.Cells(row,14).Value) : cS1 = TS(ws.Cells(row,15).Value)
        cL2 = TS(ws.Cells(row,16).Value) : cV2 = TS(ws.Cells(row,17).Value) : cS2 = TS(ws.Cells(row,18).Value)
        cL3 = TS(ws.Cells(row,19).Value) : cV3 = TS(ws.Cells(row,20).Value) : cS3 = TS(ws.Cells(row,21).Value)

        ' amounts: col V=22
        amtRaw   = TS(ws.Cells(row, 22).Value)
        amtParts = Split(amtRaw, vbLf)
        amtCount = 0
        amtC0="" : amtA0=""
        amtC1="" : amtA1=""
        amtC2="" : amtA2=""
        amtC3="" : amtA3=""
        amtC4="" : amtA4=""
        amtC5="" : amtA5=""
        amtC6="" : amtA6=""
        amtC7="" : amtA7=""
        amtC8="" : amtA8=""
        amtC9="" : amtA9=""
        For ai = 0 To UBound(amtParts)
            aline    = Trim(amtParts(ai))
            arrowPos = InStr(aline, ARROW)
            If arrowPos > 0 Then
                Select Case amtCount
                    Case 0 : amtC0 = Trim(Left(aline,arrowPos-1)) : amtA0 = Trim(Mid(aline,arrowPos+1))
                    Case 1 : amtC1 = Trim(Left(aline,arrowPos-1)) : amtA1 = Trim(Mid(aline,arrowPos+1))
                    Case 2 : amtC2 = Trim(Left(aline,arrowPos-1)) : amtA2 = Trim(Mid(aline,arrowPos+1))
                    Case 3 : amtC3 = Trim(Left(aline,arrowPos-1)) : amtA3 = Trim(Mid(aline,arrowPos+1))
                    Case 4 : amtC4 = Trim(Left(aline,arrowPos-1)) : amtA4 = Trim(Mid(aline,arrowPos+1))
                    Case 5 : amtC5 = Trim(Left(aline,arrowPos-1)) : amtA5 = Trim(Mid(aline,arrowPos+1))
                    Case 6 : amtC6 = Trim(Left(aline,arrowPos-1)) : amtA6 = Trim(Mid(aline,arrowPos+1))
                    Case 7 : amtC7 = Trim(Left(aline,arrowPos-1)) : amtA7 = Trim(Mid(aline,arrowPos+1))
                    Case 8 : amtC8 = Trim(Left(aline,arrowPos-1)) : amtA8 = Trim(Mid(aline,arrowPos+1))
                    Case 9 : amtC9 = Trim(Left(aline,arrowPos-1)) : amtA9 = Trim(Mid(aline,arrowPos+1))
                End Select
                amtCount = amtCount + 1
            End If
        Next

        matchRule = TS(ws.Cells(row, 23).Value)
        note      = TS(ws.Cells(row, 24).Value)

        ' Pack all fields: id|section|sort|badge|badgeText|title|isNew|amountShort|
        '   incomeReq|matchRule|note|cL0|cV0|cS0|...|cL3|cV3|cS3|amtCount|amtC0|amtA0|...
        packed = cardId  & vbTab & section   & vbTab & CStr(sortInc) & vbTab & _
                 badge   & vbTab & badgeText & vbTab & title         & vbTab & _
                 CStr(isNew) & vbTab & amountSh & vbTab & incomeReq  & vbTab & _
                 matchRule   & vbTab & note & vbTab & _
                 cL0 & vbTab & cV0 & vbTab & cS0 & vbTab & _
                 cL1 & vbTab & cV1 & vbTab & cS1 & vbTab & _
                 cL2 & vbTab & cV2 & vbTab & cS2 & vbTab & _
                 cL3 & vbTab & cV3 & vbTab & cS3 & vbTab & _
                 CStr(amtCount)
        If amtCount >= 1 Then packed = packed & vbTab & amtC0 & vbTab & amtA0
        If amtCount >= 2 Then packed = packed & vbTab & amtC1 & vbTab & amtA1
        If amtCount >= 3 Then packed = packed & vbTab & amtC2 & vbTab & amtA2
        If amtCount >= 4 Then packed = packed & vbTab & amtC3 & vbTab & amtA3
        If amtCount >= 5 Then packed = packed & vbTab & amtC4 & vbTab & amtA4
        If amtCount >= 6 Then packed = packed & vbTab & amtC5 & vbTab & amtA5
        If amtCount >= 7 Then packed = packed & vbTab & amtC6 & vbTab & amtA6
        If amtCount >= 8 Then packed = packed & vbTab & amtC7 & vbTab & amtA7
        If amtCount >= 9 Then packed = packed & vbTab & amtC8 & vbTab & amtA8
        If amtCount >= 10 Then packed = packed & vbTab & amtC9 & vbTab & amtA9

        ReDim Preserve cardsArr(cardCount)
        cardsArr(cardCount) = packed
        cardCount = cardCount + 1
        row = row + 1
    Loop

    wb.Close False
    xl.Quit

    If errCount > 0 Then
        LogMsg "--- Input errors ---"
        For ei = 0 To errCount - 1
            LogMsg "  [X] " & errList(ei)
        Next
        Die CStr(errCount) & Chr(32) & Chr(101) & Chr(114) & Chr(114) & Chr(111) & Chr(114) & Chr(40) & Chr(115) & Chr(41) & Chr(46) & Chr(32) & Chr(70) & Chr(105) & Chr(120) & Chr(32) & Chr(69) & Chr(120) & Chr(99) & Chr(101) & Chr(108) & Chr(32) & Chr(97) & Chr(110) & Chr(100) & Chr(32) & Chr(114) & Chr(101) & Chr(116) & Chr(114) & Chr(121) & Chr(46), logFile
    End If

    LogMsg Chr(67) & Chr(97) & Chr(114) & Chr(100) & Chr(115) & Chr(32) & Chr(108) & Chr(111) & Chr(97) & Chr(100) & Chr(101) & Chr(100) & Chr(58) & Chr(32) & cardCount
    ReadCards = cardsArr
End Function

Function BuildJS(cardsArr)
    Dim i, f, ci2, base2, cl2, hasC, amtCnt, amti2, abase
    Dim sb : sb = "const DEDUCTIONS = [" & vbCrLf

    For i = 0 To UBound(cardsArr)
        f = Split(cardsArr(i), vbTab)
        ' f(0)=id f(1)=section f(2)=sort f(3)=badge f(4)=badgeText
        ' f(5)=title f(6)=isNew f(7)=amountShort f(8)=incomeReq
        ' f(9)=matchRule f(10)=note
        ' f(11..22)=cL0,cV0,cS0,...,cL3,cV3,cS3
        ' f(23)=amtCount  f(24..)=amtC,amtA pairs

        sb = sb & vbCrLf & "  /* ---- " & f(5) & " ----*/" & vbCrLf
        sb = sb & "  {" & vbCrLf
        sb = sb & "    id:" & JsStr(f(0)) & ", sortIncome:" & f(2) & _
               ", badge:" & JsStr(f(3)) & ", badgeText:" & JsStr(f(4)) & "," & vbCrLf
        sb = sb & "    title:" & JsStr(f(5)) & "," & vbCrLf
        If f(6) = "True" Then sb = sb & "    isNew:true," & vbCrLf
        sb = sb & "    amountShort:" & JsStr(f(7)) & "," & vbCrLf
        sb = sb & "    incomeReq:"   & JsStr(f(8)) & "," & vbCrLf
        If f(1) <> "" Then sb = sb & "    section:" & JsStr(f(1)) & "," & vbCrLf
        sb = sb & "    matchRule:{ " & f(9) & " }," & vbCrLf

        hasC = False
        For ci2 = 0 To 3
            base2 = 11 + ci2 * 3
            If f(base2) <> "" Or f(base2+1) <> "" Then
                If Not hasC Then sb = sb & "    conditions:[" & vbCrLf : hasC = True
                cl2 = "      { l:" & JsStr(f(base2)) & ", v:" & JsStr(f(base2+1))
                If f(base2+2) <> "" Then cl2 = cl2 & ", s:" & JsStr(f(base2+2))
                sb = sb & cl2 & " }," & vbCrLf
            End If
        Next
        If hasC Then sb = sb & "    ]," & vbCrLf

        amtCnt = CInt(f(23))
        If amtCnt > 0 Then
            sb = sb & "    amounts:[" & vbCrLf
            For amti2 = 0 To amtCnt - 1
                abase = 24 + amti2 * 2
                sb = sb & "      { c:" & JsStr(f(abase)) & ", a:" & JsStr(f(abase+1)) & " }," & vbCrLf
            Next
            sb = sb & "    ]," & vbCrLf
        End If

        sb = sb & "    note:" & JsStr(f(10)) & "," & vbCrLf
        sb = sb & "  }," & vbCrLf
    Next
    sb = sb & "];" & vbCrLf
    BuildJS = sb
End Function

Function BuildHTML(cardsArr, logFile)
    Dim tmplContent, jsContent, todayStr, htmlContent, distDir
    LogMsg Chr(76) & Chr(111) & Chr(97) & Chr(100) & Chr(105) & Chr(110) & Chr(103) & Chr(32) & Chr(116) & Chr(101) & Chr(109) & Chr(112) & Chr(108) & Chr(97) & Chr(116) & Chr(101) & Chr(46) & Chr(46) & Chr(46)
    If Not fso.FileExists(TMPL) Then Die Chr(84) & Chr(101) & Chr(109) & Chr(112) & Chr(108) & Chr(97) & Chr(116) & Chr(101) & Chr(32) & Chr(110) & Chr(111) & Chr(116) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(58) & Chr(32) & TMPL, logFile

    tmplContent = ReadUTF8(TMPL)
    jsContent   = BuildJS(cardsArr)
    todayStr    = CStr(Year(Now)) & "-" & Z2(Month(Now)) & "-" & Z2(Day(Now))

    htmlContent = Replace(tmplContent, "{{DEDUCTIONS_JS}}", jsContent)
    htmlContent = Replace(htmlContent,  "{{BUILD_DATE}}",   todayStr)

    distDir = fso.GetParentFolderName(OUTPUT_PATH)
    If Not fso.FolderExists(distDir) Then fso.CreateFolder(distDir)

    WriteUTF8NoBOM OUTPUT_PATH, htmlContent
    LogMsg Chr(72) & Chr(84) & Chr(77) & Chr(76) & Chr(32) & Chr(103) & Chr(101) & Chr(110) & Chr(101) & Chr(114) & Chr(97) & Chr(116) & Chr(101) & Chr(100) & Chr(58) & Chr(32) & OUTPUT_PATH
    BuildHTML = htmlContent
End Function

Function VerifyOutput(cardsArr, htmlContent, logFile)
    Dim ok, pos, cnt, idVal, ri
    Dim req0, req1, req2, req3, req4
    LogMsg "--- Verification ---"
    ok = True : cnt = 0 : pos = 1

    Do While True
        pos = InStr(pos, htmlContent, "id:" & Chr(34))
        If pos = 0 Then Exit Do
        idVal = Mid(htmlContent, pos+4, InStr(pos+4, htmlContent, Chr(34)) - pos - 4)
        If idVal <> "xxx_yyy" Then cnt = cnt + 1
        pos = pos + 4
    Loop

    If cnt = UBound(cardsArr) + 1 Then
        LogMsg "  [OK] Card count: " & cnt
    Else
        LogMsg "  [X] Mismatch: Excel=" & (UBound(cardsArr)+1) & " HTML=" & cnt
        ok = False
    End If

    req0 = "dep_minor"   : req1 = "spouse_ctrl" : req2 = "kiso"
    req3 = "kyuyo"       : req4 = "student"
    For ri = 0 To 4
        Dim reqVal
        Select Case ri
            Case 0 : reqVal = req0
            Case 1 : reqVal = req1
            Case 2 : reqVal = req2
            Case 3 : reqVal = req3
            Case 4 : reqVal = req4
        End Select
        If InStr(htmlContent, "id:" & Chr(34) & reqVal & Chr(34)) > 0 Then
            LogMsg "  [OK] " & reqVal
        Else
            LogMsg "  [X] Missing: " & reqVal
            ok = False
        End If
    Next

    If InStr(htmlContent, "const DEDUCTIONS = [") > 0 Then
        LogMsg "  [OK] DEDUCTIONS found"
    Else
        LogMsg "  [X] DEDUCTIONS missing"
        ok = False
    End If

    If ok Then LogMsg "--- All checks passed ---" Else LogMsg "--- Verification failed ---"
    VerifyOutput = ok
End Function

' === Main ===
Dim g_logFile, g_cards, g_html, g_ok
g_logFile = LOG_DIR & Chr(92) & "build_" & Fmt(Now) & ".log"

LogMsg "============================================================"
LogMsg " Tax Guide HTML Builder (VBScript)"
LogMsg "============================================================"

g_cards = ReadCards(g_logFile)
g_html  = BuildHTML(g_cards, g_logFile)
g_ok    = VerifyOutput(g_cards, g_html, g_logFile)

FlushLog g_logFile
LogMsg "Log: " & g_logFile

If g_ok Then
    LogMsg "Done!"
    WScript.Quit 0
Else
    LogMsg Chr(87) & Chr(97) & Chr(114) & Chr(110) & Chr(105) & Chr(110) & Chr(103) & Chr(58) & Chr(32) & Chr(105) & Chr(115) & Chr(115) & Chr(117) & Chr(101) & Chr(115) & Chr(32) & Chr(102) & Chr(111) & Chr(117) & Chr(110) & Chr(100) & Chr(46)
    WScript.Quit 1
End If