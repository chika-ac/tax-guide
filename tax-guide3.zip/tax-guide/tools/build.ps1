﻿# build.ps1 - Excel to HTML generator (PowerShell)
# Requirements: Windows PowerShell 5.0+ (built-in), Microsoft Excel installed
# No Python, no Node.js required.

$ErrorActionPreference = "Stop"

# --- Paths ---
$ROOT       = Split-Path (Split-Path $PSCommandPath -Parent) -Parent
$XLSX       = Join-Path $ROOT "data\tax_guide_cards.xlsx"
$TEMPLATE   = Join-Path $ROOT "src\template.html"
$OUTPUT     = Join-Path $ROOT "dist\tax_guide.html"
$LOG_DIR    = Join-Path $ROOT "tools\logs"
$TIMESTAMP  = Get-Date -Format "yyyyMMdd_HHmmss"
$LOG_FILE   = Join-Path $LOG_DIR "build_$TIMESTAMP.log"

$logLines = @()
function Log($msg) {
    $line = "[$(Get-Date -Format 'HH:mm:ss')] $msg"
    Write-Host $line
    $script:logLines += $line
}
function FlushLog {
    if (-not (Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR | Out-Null }
    $logLines | Out-File -FilePath $LOG_FILE -Encoding UTF8
}
function Die($msg) {
    Log "ERROR: $msg"
    FlushLog
    exit 1
}

# --- Badge map ---
$BADGE_MAP = @{
    "配偶者（青）"          = "b-blue"
    "扶養（緑）"            = "b-green"
    "障害者（橙）"          = "b-amber"
    "ひとり親/寡婦（赤）"   = "b-red"
    "本人その他（紫）"      = "b-purple"
}

# --- JS string escape ---
function JsStr($s) {
    if ($null -eq $s) { return '""' }
    $s = [string]$s
    $s = $s -replace '\\', '\\\\'
    $s = $s -replace '"', '\"'
    $s = $s -replace "`r`n", '\n'
    $s = $s -replace "`r",   '\n'
    $s = $s -replace "`n",   '\n'
    return '"' + $s + '"'
}

# =====================================================================
# 1. Read Excel via COM
# =====================================================================
function Read-Cards {
    Log "Reading Excel: $XLSX"
    if (-not (Test-Path $XLSX)) { Die "Excel file not found: $XLSX" }

    try {
        $xl = New-Object -ComObject Excel.Application
    } catch {
        Die "Microsoft Excel not found. Please install Excel."
    }
    $xl.Visible = $false
    $xl.DisplayAlerts = $false

    try {
        $wb = $xl.Workbooks.Open($XLSX, 0, $true)
        $ws = $wb.Sheets.Item("カード一覧")
    } catch {
        try { $xl.Quit() } catch {}
        Die "Sheet 'カード一覧' not found. Check the Excel file."
    }

    $cards  = @()
    $errors = @()
    $row    = 4

    while ($true) {
        $cellA = $ws.Cells.Item($row, 1).Value2
        if (-not $cellA -or ([string]$cellA).Trim() -eq "") { break }

        $cardId    = ([string]$ws.Cells.Item($row,1).Value2).Trim()
        $title     = ([string]$ws.Cells.Item($row,2).Value2).Trim()
        $secRaw    = ([string]$ws.Cells.Item($row,3).Value2).Trim()
        $section   = if ($secRaw -eq "本人") { "self" } else { "" }
        $sortRaw   = $ws.Cells.Item($row,4).Value2
        $sortInc   = if ($null -ne $sortRaw) { [int]$sortRaw } else { 0 }
        $badgeName = ([string]$ws.Cells.Item($row,5).Value2).Trim()
        $badgeText = ([string]$ws.Cells.Item($row,6).Value2).Trim()
        $isNewRaw  = ([string]$ws.Cells.Item($row,7).Value2).Trim().ToUpper()
        $isNew     = ($isNewRaw -eq "TRUE")
        $incomeReq = ([string]$ws.Cells.Item($row,8).Value2).Trim()
        $amountSh  = ([string]$ws.Cells.Item($row,9).Value2).Trim()

        $badge = $BADGE_MAP[$badgeName]
        if (-not $badge)     { $errors += "Row ${row}: Invalid badge color [$badgeName]" }
        if (-not $title)     { $errors += "Row ${row} (ID:$cardId): Title is empty" }
        if (-not $incomeReq) { $errors += "Row ${row} (ID:$cardId): Column H is empty" }

        $conditions = @()
        for ($ci = 0; $ci -lt 4; $ci++) {
            $base = 10 + $ci * 3
            $lv = ([string]$ws.Cells.Item($row,$base  ).Value2).Trim()
            $vv = ([string]$ws.Cells.Item($row,$base+1).Value2).Trim()
            $sv = ([string]$ws.Cells.Item($row,$base+2).Value2).Trim()
            if ($lv -or $vv) {
                $conditions += [PSCustomObject]@{ l=$lv; v=$vv; s=$sv }
            }
        }

        $amtRaw  = ([string]$ws.Cells.Item($row,22).Value2).Trim()
        $amounts = @()
        foreach ($line in ($amtRaw -split "`n")) {
            $line = $line.Trim()
            $idx  = $line.IndexOf("→")
            if ($idx -ge 0) {
                $amounts += [PSCustomObject]@{
                    c = $line.Substring(0,$idx).Trim()
                    a = $line.Substring($idx+1).Trim()
                }
            }
        }

        $matchRule = ([string]$ws.Cells.Item($row,23).Value2).Trim()
        $note      = ([string]$ws.Cells.Item($row,24).Value2).Trim()

        $cards += [PSCustomObject]@{
            id=$cardId; section=$section; sortIncome=$sortInc
            badge=$badge; badgeText=$badgeText; title=$title; isNew=$isNew
            amountShort=$amountSh; incomeReq=$incomeReq; matchRule=$matchRule
            conditions=$conditions; amounts=$amounts; note=$note
        }
        $row++
    }

    try { $wb.Close($false) } catch {}
    try { $xl.Quit() }        catch {}
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($xl) | Out-Null

    if ($errors.Count -gt 0) {
        Log "--- Input errors ---"
        foreach ($e in $errors) { Log "  [X] $e" }
        Die "$($errors.Count) error(s). Fix Excel and retry."
    }

    Log "Cards loaded: $($cards.Count)"
    return $cards
}

# =====================================================================
# 2. Build DEDUCTIONS JS
# =====================================================================
function Build-DEDUCTIONSjs($cards) {
    $sb = [System.Text.StringBuilder]::new()
    [void]$sb.AppendLine("const DEDUCTIONS = [")
    foreach ($d in $cards) {
        [void]$sb.AppendLine("")
        [void]$sb.AppendLine("  /* ---- $($d.title) ----*/")
        [void]$sb.AppendLine("  {")
        [void]$sb.AppendLine("    id:$(JsStr $d.id), sortIncome:$($d.sortIncome), badge:$(JsStr $d.badge), badgeText:$(JsStr $d.badgeText),")
        [void]$sb.AppendLine("    title:$(JsStr $d.title),")
        if ($d.isNew) { [void]$sb.AppendLine("    isNew:true,") }
        [void]$sb.AppendLine("    amountShort:$(JsStr $d.amountShort),")
        [void]$sb.AppendLine("    incomeReq:$(JsStr $d.incomeReq),")
        if ($d.section) { [void]$sb.AppendLine("    section:$(JsStr $d.section),") }
        [void]$sb.AppendLine("    matchRule:{ $($d.matchRule) },")
        if ($d.conditions.Count -gt 0) {
            [void]$sb.AppendLine("    conditions:[")
            foreach ($c in $d.conditions) {
                $cl = "      { l:$(JsStr $c.l), v:$(JsStr $c.v)"
                if ($c.s) { $cl += ", s:$(JsStr $c.s)" }
                $cl += " },"
                [void]$sb.AppendLine($cl)
            }
            [void]$sb.AppendLine("    ],")
        }
        if ($d.amounts.Count -gt 0) {
            [void]$sb.AppendLine("    amounts:[")
            foreach ($a in $d.amounts) {
                [void]$sb.AppendLine("      { c:$(JsStr $a.c), a:$(JsStr $a.a) },")
            }
            [void]$sb.AppendLine("    ],")
        }
        [void]$sb.AppendLine("    note:$(JsStr $d.note),")
        [void]$sb.AppendLine("  },")
    }
    [void]$sb.AppendLine("];")
    return $sb.ToString()
}

# =====================================================================
# 3. Generate HTML
# =====================================================================
function Build-HTML($cards) {
    Log "Loading template..."
    if (-not (Test-Path $TEMPLATE)) { Die "Template not found: $TEMPLATE" }

    # UTF-8 BOMなしで読み込み
    $tmpl = [System.IO.File]::ReadAllText($TEMPLATE, [System.Text.Encoding]::UTF8)

    $deductionsJs = Build-DEDUCTIONSjs $cards
    $today = Get-Date -Format "yyyy-MM-dd"

    $html = $tmpl.Replace("{{DEDUCTIONS_JS}}", $deductionsJs)
    $html = $html.Replace("{{BUILD_DATE}}", $today)

    # dist フォルダ確認
    $distDir = Split-Path $OUTPUT -Parent
    if (-not (Test-Path $distDir)) { New-Item -ItemType Directory -Path $distDir | Out-Null }

    # UTF-8 BOMなしで書き出し
    [System.IO.File]::WriteAllText($OUTPUT, $html, [System.Text.Encoding]::UTF8)

    Log "HTML generated: $OUTPUT"
    return $html
}

# =====================================================================
# 4. Verify
# =====================================================================
function Verify-Output($cards, $html) {
    Log "--- Verification ---"
    $ok = $true

    $ids = ([regex]::Matches($html, 'id:"([^"]+)"') | Where-Object { $_.Groups[1].Value -ne "xxx_yyy" }).Count
    if ($ids -eq $cards.Count) {
        Log "  [OK] Card count: $($cards.Count)"
    } else {
        Log "  [X] Card count mismatch: Excel=$($cards.Count) HTML=$ids"
        $ok = $false
    }

    foreach ($rid in @("dep_minor","spouse_ctrl","kiso","kyuyo","student")) {
        if ($html -match [regex]::Escape("id:`"$rid`"")) {
            Log "  [OK] Required card: $rid"
        } else {
            Log "  [X] Missing card: $rid"
            $ok = $false
        }
    }

    if ($html -match "const DEDUCTIONS = \[") {
        Log "  [OK] DEDUCTIONS data found"
    } else {
        Log "  [X] DEDUCTIONS data missing"
        $ok = $false
    }

    Log $(if ($ok) { "--- All checks passed ---" } else { "--- Verification failed ---" })
    return $ok
}

# =====================================================================
# Main
# =====================================================================
Log "============================================================"
Log " Tax Guide HTML Builder (PowerShell)"
Log "============================================================"

$cards = Read-Cards
$html  = Build-HTML $cards
$ok    = Verify-Output $cards $html
FlushLog
Log "Log: $LOG_FILE"

if ($ok) {
    Log "Done!"
    exit 0
} else {
    Log "Warning: issues found. Check dist\tax_guide.html"
    exit 1
}
