Attribute VB_Name = "ModCompare"
Option Explicit

'==============================================================
' ModCompare：差分検出モジュール
' 2つのシートを受け取り項番単位で差分を検出してDiffBlock配列で返す
' UIや反映処理とは切り離す
'==============================================================

' セル1つの差分情報
Public Type DiffCell
    ColIndex  As Long    ' 列番号
    ColHeader As String  ' 列ヘッダー名
    ValA      As String  ' A側の値
    ValB      As String  ' B側の値
End Type

' 項番1つ分の差分情報
Public Type DiffBlock
    Bango     As String   ' 項番の値
    Status    As String   ' "差分あり" / "Aのみ" / "Bのみ" / "重複あり"
    RowIndexA As Long     ' AシートでのRow番号（0=存在しない）
    RowIndexB As Long     ' BシートでのRow番号（0=存在しない）
    DiffCells As Variant  ' DiffCell配列（差分ありの場合のみ使用）
    DiffCount As Long     ' 差分セル数
End Type

'--------------------------------------------------------------
' CompareSheets：2シートを比較してDiffBlock配列を返す
'--------------------------------------------------------------
Public Function CompareSheets( _
    ByVal wsA As Worksheet, _
    ByVal wsB As Worksheet) As DiffBlock()

    Dim bangoHeader As String
    Dim bangoColA   As Long
    Dim bangoColB   As Long
    Dim mapA        As Object
    Dim mapB        As Object
    Dim lastColA    As Long
    Dim lastColB    As Long
    Dim lastCol     As Long
    Dim diffLimit   As Long
    Dim results()   As DiffBlock
    Dim count       As Long
    Dim key         As Variant

    bangoHeader = ModConfig.GetBangoHeader()
    diffLimit   = ModConfig.GetDiffLimit()

    bangoColA = FindBangoCol(wsA, bangoHeader)
    bangoColB = FindBangoCol(wsB, bangoHeader)

    If bangoColA = 0 Then
        Call ModUtil.ShowError("シート「" & wsA.Name & "」のA側に項番列が見つかりません。" & vbCrLf & _
            "設定シートの「項番列のヘッダー名」を確認してください。")
        CompareSheets = results
        Exit Function
    End If
    If bangoColB = 0 Then
        Call ModUtil.ShowError("シート「" & wsB.Name & "」のB側に項番列が見つかりません。" & vbCrLf & _
            "設定シートの「項番列のヘッダー名」を確認してください。")
        CompareSheets = results
        Exit Function
    End If

    ' 項番→行番号のマップをA・B両方で作る
    Set mapA = BuildBangoMap(wsA, bangoColA)
    Set mapB = BuildBangoMap(wsB, bangoColB)

    ' 比較に使う最終列を取得する（A・Bのうち広い方を採用）
    lastColA = GetLastUsedCol(wsA)
    lastColB = GetLastUsedCol(wsB)
    lastCol  = IIf(lastColA > lastColB, lastColA, lastColB)

    ReDim results(1 To diffLimit + 1)
    count = 0

    '--- Aの項番をベースに比較する ---
    For Each key In mapA.Keys
        If count >= diffLimit Then
            Call ModUtil.ShowInfo("差分項番数が上限（" & diffLimit & "件）を超えました。" & vbCrLf & _
                "設定シートの「差分表示上限」を増やすか比較シートを絞ってください。")
            Exit For
        End If

        Dim bango As String
        Dim rowA  As Long
        Dim rowB  As Long
        Dim block As DiffBlock

        bango = CStr(key)

        ' A側に重複項番がある場合は警告ブロックとして追加する
        If mapA(key) = "DUPLICATE" Then
            count           = count + 1
            block.Bango     = bango
            block.Status    = "重複あり"
            block.RowIndexA = 0
            block.RowIndexB = 0
            block.DiffCount = 0
            results(count)  = block
            GoTo NextKeyA
        End If

        rowA = CLng(mapA(key))

        If mapB.Exists(key) Then
            ' B側も重複していた場合
            If mapB(key) = "DUPLICATE" Then
                count           = count + 1
                block.Bango     = bango
                block.Status    = "重複あり"
                block.RowIndexA = rowA
                block.RowIndexB = 0
                block.DiffCount = 0
                results(count)  = block
                GoTo NextKeyA
            End If

            rowB = CLng(mapB(key))
            ' 同一項番の行をセル単位で比較する
            Dim cells() As DiffCell
            cells = CompareSingleRow(wsA, wsB, rowA, rowB, lastCol, bangoColA, bangoColB)

            ' 差分があった場合のみDiffBlockとして記録する
            If UBound(cells) >= LBound(cells) Then
                count           = count + 1
                block.Bango     = bango
                block.Status    = "差分あり"
                block.RowIndexA = rowA
                block.RowIndexB = rowB
                block.DiffCells = cells
                block.DiffCount = UBound(cells) - LBound(cells) + 1
                results(count)  = block
            End If
        Else
            ' Aにのみ存在する項番
            count           = count + 1
            block.Bango     = bango
            block.Status    = "Aのみ"
            block.RowIndexA = rowA
            block.RowIndexB = 0
            block.DiffCount = 0
            results(count)  = block
        End If
NextKeyA:
    Next key

    '--- Bにのみ存在する項番を追加する ---
    For Each key In mapB.Keys
        If count >= diffLimit Then Exit For
        bango = CStr(key)
        If Not mapA.Exists(key) Then
            count           = count + 1
            block.Bango     = bango
            block.Status    = "Bのみ"
            block.RowIndexA = 0
            If mapB(key) = "DUPLICATE" Then
                block.RowIndexB = 0
            Else
                block.RowIndexB = CLng(mapB(key))
            End If
            block.DiffCount = 0
            results(count)  = block
        End If
    Next key

    ' 実際に検出された件数で配列をリサイズして返す
    If count = 0 Then
        CompareSheets = Split("", ",")
        Exit Function
    End If

    ReDim Preserve results(1 To count)
    CompareSheets = results
End Function

'--------------------------------------------------------------
' FindBangoCol：項番列の列番号を返す（見つからなければ0）
'--------------------------------------------------------------
Public Function FindBangoCol(ByVal ws As Worksheet, ByVal header As String) As Long
    Dim lastCol As Long
    Dim i       As Long
    lastCol = GetLastUsedCol(ws)
    For i = 1 To lastCol
        If Trim(ModUtil.SafeString(ws.Cells(1, i).Value)) = Trim(header) Then
            FindBangoCol = i
            Exit Function
        End If
    Next i
    FindBangoCol = 0
End Function

'--------------------------------------------------------------
' BuildBangoMap：項番→行番号のDictionaryを作る
' 重複している項番は値を "DUPLICATE" にする
'--------------------------------------------------------------
Public Function BuildBangoMap(ByVal ws As Worksheet, ByVal bangoCol As Long) As Object
    Dim dict    As Object
    Dim lastRow As Long
    Dim i       As Long
    Dim bango   As String

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare  ' 大文字小文字を区別しない

    ' 2行目以降（ヘッダー行を除く）を走査する
    lastRow = ws.Cells(ws.Rows.Count, bangoCol).End(xlUp).Row

    For i = 2 To lastRow
        bango = Trim(ModUtil.SafeString(ws.Cells(i, bangoCol).Value))
        If bango = "" Then GoTo NextRowBM
        If dict.Exists(bango) Then
            ' すでに登録済みの場合は重複フラグを立てる
            dict(bango) = "DUPLICATE"
        Else
            dict.Add bango, CLng(i)
        End If
NextRowBM:
    Next i

    Set BuildBangoMap = dict
End Function

'--------------------------------------------------------------
' CompareSingleRow：1行分のセルを比較して差分セル配列を返す
' 項番列自体は比較対象から除外する
'--------------------------------------------------------------
Public Function CompareSingleRow( _
    ByVal wsA       As Worksheet, _
    ByVal wsB       As Worksheet, _
    ByVal rowA      As Long, _
    ByVal rowB      As Long, _
    ByVal lastCol   As Long, _
    ByVal bangoColA As Long, _
    ByVal bangoColB As Long) As DiffCell()

    Dim results() As DiffCell
    Dim count     As Long
    Dim i         As Long
    Dim valA      As String
    Dim valB      As String
    Dim dc        As DiffCell

    ReDim results(1 To lastCol)
    count = 0

    For i = 1 To lastCol
        ' 項番列は比較対象から除外する
        If i = bangoColA Or i = bangoColB Then GoTo NextColSR

        valA = ModUtil.SafeString(wsA.Cells(rowA, i).Value)
        valB = ModUtil.SafeString(wsB.Cells(rowB, i).Value)

        ' 値が異なる場合のみ差分として記録する
        If valA <> valB Then
            count          = count + 1
            dc.ColIndex    = i
            dc.ColHeader   = ModUtil.SafeString(wsA.Cells(1, i).Value)
            dc.ValA        = valA
            dc.ValB        = valB
            results(count) = dc
        End If
NextColSR:
    Next i

    ' 差分がなかった場合は空配列を返す
    If count = 0 Then
        CompareSingleRow = Split("", ",")
        Exit Function
    End If

    ReDim Preserve results(1 To count)
    CompareSingleRow = results
End Function

'--------------------------------------------------------------
' GetLastUsedCol：シートの最終使用列番号を返す
'--------------------------------------------------------------
Public Function GetLastUsedCol(ByVal ws As Worksheet) As Long
    Dim lastCol As Long
    On Error Resume Next
    lastCol = ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column
    On Error GoTo 0
    If lastCol < 1 Then lastCol = 1
    GetLastUsedCol = lastCol
End Function
