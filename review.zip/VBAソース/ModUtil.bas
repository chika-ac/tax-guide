Attribute VB_Name = "ModUtil"
Option Explicit

'==============================================================
' ModUtil：共通ユーティリティモジュール
' エラー表示・確認ダイアログ・型変換など汎用処理をまとめる
' 複数のモジュールから呼ばれる
'==============================================================

'--------------------------------------------------------------
' ShowError：エラーメッセージをMsgBoxで表示する
'--------------------------------------------------------------
Public Sub ShowError(ByVal msg As String)
    MsgBox msg, vbCritical + vbOKOnly, "エラー"
End Sub

'--------------------------------------------------------------
' ShowInfo：情報メッセージをMsgBoxで表示する
'--------------------------------------------------------------
Public Sub ShowInfo(ByVal msg As String)
    MsgBox msg, vbInformation + vbOKOnly, "完了"
End Sub

'--------------------------------------------------------------
' ConfirmYesNo：はい/いいえの確認ダイアログを表示する
' 戻り値：はいならTrue、いいえならFalse
'--------------------------------------------------------------
Public Function ConfirmYesNo(ByVal msg As String) As Boolean
    Dim result As Integer
    result = MsgBox(msg, vbQuestion + vbYesNo, "確認")
    ConfirmYesNo = (result = vbYes)
End Function

'--------------------------------------------------------------
' SafeString：Variant値を安全に文字列へ変換する
' Null・Empty・Errorも空文字として返す
' セルの値を扱う際は必ずこの関数を通す
'--------------------------------------------------------------
Public Function SafeString(ByVal v As Variant) As String
    If IsNull(v) Or IsEmpty(v) Or IsError(v) Then
        SafeString = ""
    Else
        SafeString = CStr(v)
    End If
End Function

'--------------------------------------------------------------
' TodayString：今日の日付を yyyymmdd 形式の文字列で返す
' 出力ファイル名の生成に使用する
'--------------------------------------------------------------
Public Function TodayString() As String
    TodayString = Format(Now(), "yyyymmdd")
End Function
