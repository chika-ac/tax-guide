Attribute VB_Name = "ModConfig"
Option Explicit

'==============================================================
' ModConfig：設定シートから設定値を読み込むモジュール
' 他のモジュールはすべてこのモジュール経由で設定値を参照する
' セル番地ではなくラベル名で検索するため行順が変わっても壊れない
'==============================================================

Private Const SETTINGS_SHEET As String = "設定"
Private Const LABEL_COL      As Long = 2
Private Const VALUE_COL      As Long = 3
Private Const START_ROW      As Long = 3

'--------------------------------------------------------------
' GetConfig：ラベル名に対応する設定値を返す
' 引数  labelName：設定シートのB列に書かれているラベル名
' 戻り値：対応するC列の値。見つからなければ空文字
'--------------------------------------------------------------
Public Function GetConfig(ByVal labelName As String) As String
    Dim ws      As Worksheet
    Dim i       As Long
    Dim lastRow As Long

    On Error GoTo ErrHandler
    Set ws = ThisWorkbook.Sheets(SETTINGS_SHEET)
    lastRow = ws.Cells(ws.Rows.Count, LABEL_COL).End(xlUp).Row

    For i = START_ROW To lastRow
        If Trim(ws.Cells(i, LABEL_COL).Value) = Trim(labelName) Then
            GetConfig = ModUtil.SafeString(ws.Cells(i, VALUE_COL).Value)
            Exit Function
        End If
    Next i

    GetConfig = ""
    Exit Function
ErrHandler:
    Call ModUtil.ShowError("設定シートの読み込みに失敗しました。シート名「設定」を確認してください。")
    GetConfig = ""
End Function

'--------------------------------------------------------------
' GetFolderA：A投入フォルダのフルパスを返す
'--------------------------------------------------------------
Public Function GetFolderA() As String
    Dim fn As String
    fn = GetConfig("A投入フォルダ名")
    If fn = "" Then fn = "01_A投入"
    GetFolderA = ThisWorkbook.Path & "\" & fn
End Function

'--------------------------------------------------------------
' GetFolderB：B投入フォルダのフルパスを返す
'--------------------------------------------------------------
Public Function GetFolderB() As String
    Dim fn As String
    fn = GetConfig("B投入フォルダ名")
    If fn = "" Then fn = "02_B投入"
    GetFolderB = ThisWorkbook.Path & "\" & fn
End Function

'--------------------------------------------------------------
' GetFolderOut：出力フォルダのフルパスを返す
'--------------------------------------------------------------
Public Function GetFolderOut() As String
    Dim fn As String
    fn = GetConfig("出力フォルダ名")
    If fn = "" Then fn = "03_出力"
    GetFolderOut = ThisWorkbook.Path & "\" & fn
End Function

'--------------------------------------------------------------
' GetDefaultSheets：デフォルト比較シート名の配列を返す
'--------------------------------------------------------------
Public Function GetDefaultSheets() As String()
    Dim results(1 To 3) As String
    Dim count           As Long
    Dim val             As String
    Dim i               As Long
    count = 0
    For i = 1 To 3
        val = GetConfig("デフォルト比較シート" & i)
        If val <> "" Then
            count = count + 1
            results(count) = val
        End If
    Next i
    If count = 0 Then
        GetDefaultSheets = Split("", ",")
        Exit Function
    End If
    Dim output() As String
    ReDim output(1 To count)
    For i = 1 To count
        output(i) = results(i)
    Next i
    GetDefaultSheets = output
End Function

'--------------------------------------------------------------
' GetBangoHeader：項番列のヘッダー名を返す
'--------------------------------------------------------------
Public Function GetBangoHeader() As String
    Dim val As String
    val = GetConfig("項番列のヘッダー名")
    If val = "" Then val = "項番"
    GetBangoHeader = val
End Function

'--------------------------------------------------------------
' GetDiffLimit：差分表示の上限件数を返す
'--------------------------------------------------------------
Public Function GetDiffLimit() As Long
    Dim val As String
    val = GetConfig("差分表示上限（項番数）")
    If val = "" Or Not IsNumeric(val) Then
        GetDiffLimit = 100
    Else
        GetDiffLimit = CLng(val)
    End If
End Function

'--------------------------------------------------------------
' GetOutputSuffix：出力ファイル接尾辞を返す
'--------------------------------------------------------------
Public Function GetOutputSuffix() As String
    Dim val As String
    val = GetConfig("出力ファイル接尾辞")
    If val = "" Then val = "_A"
    GetOutputSuffix = val
End Function
