VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmProgress
   Caption         =   "処理中"
   ClientHeight    =   1500
   ClientLeft      =   108
   ClientTop       =   456
   ClientWidth     =   4800
   OleObjectBlob   =   "frmProgress.frx":0000
   StartUpPosition =   1  'オーナーの中央
End
Attribute VB_Name = "frmProgress"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

'==============================================================
' frmProgress：処理中表示フォーム
' 重い処理の実行中にメッセージを表示するシンプルなフォーム
' 呼び出し元が Show vbModeless で表示し、完了後に Unload する
'==============================================================

'--------------------------------------------------------------
' SetMessage：表示メッセージを外部から更新する
'--------------------------------------------------------------
Public Sub SetMessage(ByVal msg As String, Optional ByVal detail As String = "")
    lblMessage.Caption = msg
    lblDetail.Caption  = detail
    DoEvents
End Sub

'--------------------------------------------------------------
' UserForm_QueryClose：×ボタンで閉じられないようにする
'--------------------------------------------------------------
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        Cancel = True  ' 処理中に誤って閉じるのを防ぐ
    End If
End Sub
