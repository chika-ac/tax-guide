VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmStart
   Caption         =   "差分レビュー・反映ツール"
   ClientHeight    =   7200
   ClientLeft      =   108
   ClientTop       =   456
   ClientWidth     =   6300
   OleObjectBlob   =   "frmStart.frx":0000
   StartUpPosition =   1  'オーナーの中央
End
Attribute VB_Name = "frmStart"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

'==============================================================
' frmStart：開始画面フォーム
' A/B投入状況の確認・比較シート選択・比較実行を行う
'==============================================================

Private m_ChkBoxes  As Collection
Private m_FilePathA As String
Private m_FilePathB As String

'--------------------------------------------------------------
' UserForm_Initialize：フォームが開いたときの初期化処理
'--------------------------------------------------------------
Private Sub UserForm_Initialize()
    Set m_ChkBoxes = New Collection
    Call LoadFileStatus
    Call BuildSheetCheckBoxes
End Sub

'--------------------------------------------------------------
' LoadFileStatus：A/Bフォルダのファイル状況を確認して表示する
'--------------------------------------------------------------
Private Sub LoadFileStatus()
    Dim pathA As String
    Dim pathB As String

    pathA = ModFileIO.GetSingleFilePath(ModConfig.GetFolderA())
    pathB = ModFileIO.GetSingleFilePath(ModConfig.GetFolderB())

    If pathA <> "" Then
        m_FilePathA       = pathA
        lblAFile.Caption  = Dir(pathA)
        lblAFile.ForeColor = RGB(0, 0, 0)
    Else
        m_FilePathA       = ""
        lblAFile.Caption  = "（ファイルが見つかりません）"
        lblAFile.ForeColor = RGB(200, 0, 0)
    End If

    If pathB <> "" Then
        m_FilePathB       = pathB
        lblBFile.Caption  = Dir(pathB)
        lblBFile.ForeColor = RGB(0, 0, 0)
    Else
        m_FilePathB       = ""
        lblBFile.Caption  = "（ファイルが見つかりません）"
        lblBFile.ForeColor = RGB(200, 0, 0)
    End If

    btnRun.Enabled = (m_FilePathA <> "" And m_FilePathB <> "")
End Sub

'--------------------------------------------------------------
' BuildSheetCheckBoxes：A・B共通シートのチェックボックスを動的生成する
'--------------------------------------------------------------
Private Sub BuildSheetCheckBoxes()
    Dim wbA          As Workbook
    Dim wbB          As Workbook
    Dim sheetNames() As String
    Dim defaults()   As String
    Dim i            As Long
    Dim topPos       As Single
    Dim chk          As MSForms.CheckBox
    Dim isDefault    As Boolean
    Dim j            As Long

    If m_FilePathA = "" Or m_FilePathB = "" Then Exit Sub

    Set wbA = ModFileIO.OpenWorkbookReadOnly(m_FilePathA)
    Set wbB = ModFileIO.OpenWorkbookReadOnly(m_FilePathB)

    If wbA Is Nothing Or wbB Is Nothing Then
        Call ModFileIO.CloseWorkbook(wbA)
        Call ModFileIO.CloseWorkbook(wbB)
        Exit Sub
    End If

    sheetNames = ModFileIO.GetCommonSheetNames(wbA, wbB)

    If UBound(sheetNames) < LBound(sheetNames) Then
        lblNote.Caption   = "※ A・B両方に共通するシートが見つかりませんでした"
        lblNote.ForeColor = RGB(200, 0, 0)
        btnRun.Enabled    = False
        Call ModFileIO.CloseWorkbook(wbA)
        Call ModFileIO.CloseWorkbook(wbB)
        Exit Sub
    End If

    defaults = ModConfig.GetDefaultSheets()
    topPos   = 8

    For i = LBound(sheetNames) To UBound(sheetNames)
        isDefault = False
        For j = LBound(defaults) To UBound(defaults)
            If defaults(j) = sheetNames(i) Then
                isDefault = True
                Exit For
            End If
        Next j

        Set chk = fraSheets.Controls.Add("Forms.CheckBox.1", "chkSheet_" & i)
        With chk
            .Caption   = sheetNames(i)
            .Value     = isDefault
            .Tag       = sheetNames(i)
            .Left      = 8
            .Top       = topPos
            .Width     = 360
            .Height    = 20
            .Font.Size = 10
        End With
        m_ChkBoxes.Add chk
        topPos = topPos + 26
    Next i

    fraSheets.ScrollHeight = topPos + 8
    Call ModFileIO.CloseWorkbook(wbA)
    Call ModFileIO.CloseWorkbook(wbB)
End Sub

'--------------------------------------------------------------
' btnRun_Click：「比較実行」ボタン
'--------------------------------------------------------------
Private Sub btnRun_Click()
    Dim selectedSheets() As String
    Dim count            As Long
    Dim i                As Long
    Dim chk              As MSForms.CheckBox
    Dim wbA              As Workbook
    Dim wbB              As Workbook

    count = 0
    ReDim selectedSheets(1 To m_ChkBoxes.Count)

    For Each chk In m_ChkBoxes
        If chk.Value = True Then
            count = count + 1
            selectedSheets(count) = chk.Tag
        End If
    Next chk

    If count = 0 Then
        Call ModUtil.ShowError("比較対象シートを1つ以上選択してください。")
        Exit Sub
    End If

    ReDim Preserve selectedSheets(1 To count)

    frmProgress.lblMessage.Caption = "比較処理中です。しばらくお待ちください..."
    frmProgress.lblDetail.Caption  = ""
    frmProgress.Show vbModeless
    DoEvents

    Set wbA = ModFileIO.OpenWorkbookReadOnly(m_FilePathA)
    Set wbB = ModFileIO.OpenWorkbookReadOnly(m_FilePathB)

    If wbA Is Nothing Or wbB Is Nothing Then
        Unload frmProgress
        Call ModFileIO.CloseWorkbook(wbA)
        Call ModFileIO.CloseWorkbook(wbB)
        Exit Sub
    End If

    Dim diffBySheet() As Variant
    ReDim diffBySheet(1 To count)

    For i = 1 To count
        frmProgress.lblDetail.Caption = "比較中：" & i & " / " & count & " シート目（" & selectedSheets(i) & "）"
        DoEvents

        Dim wsA As Worksheet
        Dim wsB As Worksheet
        On Error Resume Next
        Set wsA = wbA.Sheets(selectedSheets(i))
        Set wsB = wbB.Sheets(selectedSheets(i))
        On Error GoTo 0

        If wsA Is Nothing Or wsB Is Nothing Then
            diffBySheet(i) = Empty
        Else
            diffBySheet(i) = ModCompare.CompareSheets(wsA, wsB)
        End If
        Set wsA = Nothing
        Set wsB = Nothing
    Next i

    Unload frmProgress

    With frmReview
        Call .InitReview(diffBySheet, selectedSheets, wbA, wbB, m_FilePathA)
    End With

    Me.Hide
    frmReview.Show
    Unload Me
End Sub

'--------------------------------------------------------------
' btnClose_Click：「閉じる」ボタン
'--------------------------------------------------------------
Private Sub btnClose_Click()
    Unload Me
End Sub

'--------------------------------------------------------------
' UserForm_QueryClose：×ボタンで閉じる際の処理
'--------------------------------------------------------------
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        Unload Me
    End If
End Sub
