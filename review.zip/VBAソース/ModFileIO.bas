Attribute VB_Name = "ModFileIO"
Option Explicit

'==============================================================
' ModFileIO：ファイル入出力モジュール
' A/Bフォルダのファイル検索、ブックの開閉、出力ファイルの保存を担当
' ファイル操作に関するすべての処理をここに集める
'==============================================================

'--------------------------------------------------------------
' GetSingleFilePath：フォルダ内のExcelファイルを1件取得する
' 0件または複数件の場合はエラーメッセージを表示して空文字を返す
'--------------------------------------------------------------
Public Function GetSingleFilePath(ByVal folderPath As String) As String
    Dim fileName As String
    Dim filePath As String
    Dim count    As Long

    ' フォルダの存在確認
    If Not EnsureFolderExists(folderPath) Then
        GetSingleFilePath = ""
        Exit Function
    End If

    count    = 0
    filePath = ""

    ' xlsx / xlsm / xls を順に検索する（ツール自身は除外）
    Dim exts(1 To 3) As String
    exts(1) = "*.xlsx"
    exts(2) = "*.xlsm"
    exts(3) = "*.xls"

    Dim ei As Long
    For ei = 1 To 3
        fileName = Dir(folderPath & "\" & exts(ei))
        Do While fileName <> ""
            ' ツール自身（このブック）は除外する
            If LCase(fileName) <> LCase(ThisWorkbook.Name) Then
                count    = count + 1
                filePath = folderPath & "\" & fileName
            End If
            fileName = Dir()
        Loop
    Next ei

    Select Case count
        Case 0
            GetSingleFilePath = ""
        Case 1
            GetSingleFilePath = filePath
        Case Else
            Call ModUtil.ShowError("フォルダにExcelファイルが複数あります。1ファイルのみ入れてください。" & vbCrLf & folderPath)
            GetSingleFilePath = ""
    End Select
End Function

'--------------------------------------------------------------
' OpenWorkbookReadOnly：ブックを読み取り専用で開いて返す
' 元ファイルを変更しないための安全策
'--------------------------------------------------------------
Public Function OpenWorkbookReadOnly(ByVal filePath As String) As Workbook
    On Error GoTo ErrHandler
    Set OpenWorkbookReadOnly = Workbooks.Open( _
        Filename:=filePath, _
        ReadOnly:=True, _
        UpdateLinks:=False)
    Exit Function
ErrHandler:
    Call ModUtil.ShowError("ファイルを開けませんでした。" & vbCrLf & filePath & vbCrLf & vbCrLf & _
        "読み取り専用推奨・パスワード保護がある場合は事前に解除してください。")
    Set OpenWorkbookReadOnly = Nothing
End Function

'--------------------------------------------------------------
' CloseWorkbook：ブックを保存せずに閉じる
'--------------------------------------------------------------
Public Sub CloseWorkbook(ByVal wb As Workbook)
    On Error Resume Next
    If Not wb Is Nothing Then
        wb.Close SaveChanges:=False
    End If
    On Error GoTo 0
End Sub

'--------------------------------------------------------------
' SaveOutputFile：AブックをコピーしてOutputフォルダへ保存する
' 元のAファイルは上書きしない
'--------------------------------------------------------------
Public Function SaveOutputFile( _
    ByVal wbA As Workbook, _
    ByVal outputFolder As String, _
    ByVal originalName As String) As String

    Dim newFileName As String
    Dim newFilePath As String

    On Error GoTo ErrHandler

    ' 出力フォルダの存在確認
    If Not EnsureFolderExists(outputFolder) Then
        Call ModUtil.ShowError("出力フォルダが見つかりません。" & vbCrLf & outputFolder)
        SaveOutputFile = ""
        Exit Function
    End If

    ' 出力ファイル名を生成する（例：顧客一覧_A20260406.xlsx）
    newFileName = BuildOutputFileName(originalName)
    newFilePath = outputFolder & "\" & newFileName

    ' 同名ファイルが既にある場合は確認する
    If Dir(newFilePath) <> "" Then
        If Not ModUtil.ConfirmYesNo("出力先に同名ファイルがあります。上書きしますか？" & vbCrLf & newFileName) Then
            SaveOutputFile = ""
            Exit Function
        End If
    End If

    ' xlsx形式で保存する
    wbA.SaveAs Filename:=newFilePath, FileFormat:=xlOpenXMLWorkbook

    SaveOutputFile = newFilePath
    Exit Function
ErrHandler:
    Call ModUtil.ShowError("ファイルの保存に失敗しました。" & vbCrLf & newFilePath)
    SaveOutputFile = ""
End Function

'--------------------------------------------------------------
' BuildOutputFileName：出力ファイル名を生成する
' 例：顧客一覧.xlsx → 顧客一覧_A20260406.xlsx
'--------------------------------------------------------------
Public Function BuildOutputFileName(ByVal originalName As String) As String
    Dim baseName As String
    Dim suffix   As String
    Dim today    As String

    ' 拡張子を除いたファイル名を取得する
    baseName = Left(originalName, InStrRev(originalName, ".") - 1)
    suffix   = ModConfig.GetOutputSuffix()
    today    = ModUtil.TodayString()

    BuildOutputFileName = baseName & suffix & today & ".xlsx"
End Function

'--------------------------------------------------------------
' EnsureFolderExists：フォルダが存在するか確認する
'--------------------------------------------------------------
Public Function EnsureFolderExists(ByVal folderPath As String) As Boolean
    EnsureFolderExists = (Dir(folderPath, vbDirectory) <> "")
End Function

'--------------------------------------------------------------
' GetCommonSheetNames：A・B共通シート名の配列を返す
' frmStartのシート選択チェックボックス生成に使用する
'--------------------------------------------------------------
Public Function GetCommonSheetNames( _
    ByVal wbA As Workbook, _
    ByVal wbB As Workbook) As String()

    Dim ws        As Worksheet
    Dim results() As String
    Dim count     As Long
    count = 0
    ReDim results(1 To wbA.Sheets.Count)

    For Each ws In wbA.Sheets
        On Error Resume Next
        Dim wsB As Worksheet
        Set wsB = wbB.Sheets(ws.Name)
        On Error GoTo 0
        If Not wsB Is Nothing Then
            count          = count + 1
            results(count) = ws.Name
            Set wsB = Nothing
        End If
    Next ws

    If count = 0 Then
        GetCommonSheetNames = Split("", ",")
        Exit Function
    End If

    Dim output() As String
    ReDim output(1 To count)
    Dim i As Long
    For i = 1 To count
        output(i) = results(i)
    Next i
    GetCommonSheetNames = output
End Function
