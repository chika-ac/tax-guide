VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmReview
   Caption         =   "差分レビュー画面"
   ClientHeight    =   9600
   ClientLeft      =   108
   ClientTop       =   456
   ClientWidth     =   12000
   OleObjectBlob   =   "frmReview.frx":0000
   StartUpPosition =   1  'オーナーの中央
End
Attribute VB_Name = "frmReview"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

'==============================================================
' frmReview：差分レビュー画面フォーム
' 差分を項番ブロック単位で表示しセルごとに反映チェックを行う
'==============================================================

Private Const COLOR_DIFF   As Long = 16777140  ' RGB(255,255,180) 黄色
Private Const COLOR_WARN   As Long = 16763580  ' RGB(255,220,180) 薄オレンジ
Private Const COLOR_NORMAL As Long = 16777215  ' RGB(255,255,255) 白

Private m_DiffBySheet()  As Variant
Private m_SheetNames()   As String
Private m_CurrentSheet   As Long
Private m_SheetCount     As Long
Private m_WbA            As Workbook
Private m_WbB            As Workbook
Private m_FilePathA      As String
Private m_CheckBoxes     As Collection

'--------------------------------------------------------------
' InitReview：frmStartから呼ばれる初期化処理
'--------------------------------------------------------------
Public Sub InitReview( _
    ByRef diffBySheet() As Variant, _
    ByRef sheetNames()  As String, _
    ByVal wbA           As Workbook, _
    ByVal wbB           As Workbook, _
    ByVal filePathA     As String)

    Dim i As Long
    m_SheetCount = UBound(sheetNames)
    ReDim m_DiffBySheet(1 To m_SheetCount)
    ReDim m_SheetNames(1 To m_SheetCount)

    For i = 1 To m_SheetCount
        m_DiffBySheet(i) = diffBySheet(i)
        m_SheetNames(i)  = sheetNames(i)
    Next i

    Set m_WbA      = wbA
    Set m_WbB      = wbB
    m_FilePathA    = filePathA
    m_CurrentSheet = 1
    Set m_CheckBoxes = New Collection
End Sub

'--------------------------------------------------------------
' UserForm_Initialize：フォームが開いたときの処理
'--------------------------------------------------------------
Private Sub UserForm_Initialize()
    If m_SheetCount = 0 Then Exit Sub
    Call RenderCurrentSheet
End Sub

'--------------------------------------------------------------
' RenderCurrentSheet：現在シートの差分ブロックをfraMainに描画する
'--------------------------------------------------------------
Private Sub RenderCurrentSheet()
    Dim diffs     As Variant
    Dim diffCount As Long
    Dim i         As Long
    Dim topPos    As Single

    Call ClearFrameMain

    diffs = m_DiffBySheet(m_CurrentSheet)
    lblSheetName.Caption = "対象シート：" & m_SheetNames(m_CurrentSheet)

    If IsEmpty(diffs) Or VarType(diffs) = vbString Then
        lblDiffCount.Caption = "差分項番数：0 件"
        Call AddNoDataLabel
        Call UpdateNavigationButtons
        Exit Sub
    End If

    diffCount = UBound(diffs) - LBound(diffs) + 1
    lblDiffCount.Caption = "差分項番数：" & diffCount & " 件"

    topPos = 8
    For i = LBound(diffs) To UBound(diffs)
        topPos = RenderDiffBlock(diffs(i), i - LBound(diffs) + 1, topPos)
        topPos = topPos + 16
    Next i

    fraMain.ScrollHeight = topPos + 20
    Call UpdateNavigationButtons
End Sub

'--------------------------------------------------------------
' RenderDiffBlock：1つの項番ブロックを描画する
'--------------------------------------------------------------
Private Function RenderDiffBlock( _
    ByRef block    As ModCompare.DiffBlock, _
    ByVal blockNum As Long, _
    ByVal topPos   As Single) As Single

    Dim fra      As MSForms.Frame
    Dim lbl      As MSForms.Label
    Dim chk      As MSForms.CheckBox
    Dim innerTop As Single

    ' 項番ブロックのFrameを生成する
    Set fra = fraMain.Controls.Add("Forms.Frame.1", "fraBlock_" & blockNum)
    With fra
        .Left          = 8
        .Top           = topPos
        .Width         = 748
        .Height        = 60
        .BorderStyle   = 1
        .BorderColor   = RGB(180, 180, 180)
        .SpecialEffect = 0
    End With

    innerTop = 8

    ' 見出しラベルを生成する（項番＋状態）
    Set lbl = fra.Controls.Add("Forms.Label.1", "lblBlockHeader_" & blockNum)
    With lbl
        .Caption   = "項番：" & block.Bango & "　　状態：" & block.Status
        .Left      = 8
        .Top       = innerTop
        .Width     = 500
        .Height    = 18
        .Font.Bold = True
        .Font.Size = 10
        Select Case block.Status
            Case "差分あり"
                .ForeColor = RGB(0, 0, 150)
            Case "Aのみ", "Bのみ", "重複あり"
                .ForeColor = RGB(180, 80, 0)
        End Select
    End With
    innerTop = innerTop + 22

    ' 状態別の描画処理
    Select Case block.Status

        Case "差分あり"
            ' 項番一括チェックを生成する
            Set chk = fra.Controls.Add("Forms.CheckBox.1", "chkBlockAll_" & blockNum)
            With chk
                .Caption   = "この項番をすべて反映（※すべて反映ボタンでも一括操作できます）"
                .Left      = 8
                .Top       = innerTop
                .Width     = 400
                .Height    = 18
                .Font.Size = 9
                .Tag       = CStr(blockNum)
            End With
            m_CheckBoxes.Add chk, "chkBlockAll_" & blockNum
            innerTop = innerTop + 24

            ' 差分列ごとに ヘッダー/A値/B値/チェック を横に並べる
            Dim cells   As Variant
            Dim colLeft As Single
            Dim colNum  As Long
            Dim dc      As ModCompare.DiffCell
            Dim ci      As Long

            cells   = block.DiffCells
            colLeft = 8
            colNum  = 0

            For ci = LBound(cells) To UBound(cells)
                dc     = cells(ci)
                colNum = colNum + 1

                ' 右端に近い場合は折り返す
                If colLeft + 148 > 740 Then
                    colLeft  = 8
                    innerTop = innerTop + 80
                End If

                ' 列ヘッダーラベル（黄色背景）
                Set lbl = fra.Controls.Add("Forms.Label.1", "lblColHeader_" & blockNum & "_" & colNum)
                With lbl
                    .Caption   = dc.ColHeader
                    .Left      = colLeft
                    .Top       = innerTop
                    .Width     = 140
                    .Height    = 18
                    .BackColor = COLOR_DIFF
                    .Font.Bold = True
                    .Font.Size = 9
                    .TextAlign = fmTextAlignCenter
                End With

                ' A値ラベル
                Set lbl = fra.Controls.Add("Forms.Label.1", "lblValA_" & blockNum & "_" & colNum)
                With lbl
                    .Caption   = "A：" & dc.ValA
                    .Left      = colLeft
                    .Top       = innerTop + 20
                    .Width     = 140
                    .Height    = 18
                    .BackColor = COLOR_NORMAL
                    .Font.Size = 9
                End With

                ' B値ラベル（黄色背景）
                Set lbl = fra.Controls.Add("Forms.Label.1", "lblValB_" & blockNum & "_" & colNum)
                With lbl
                    .Caption   = "B：" & dc.ValB
                    .Left      = colLeft
                    .Top       = innerTop + 40
                    .Width     = 140
                    .Height    = 18
                    .BackColor = COLOR_DIFF
                    .Font.Size = 9
                End With

                ' 反映チェックボックス
                Dim chkName As String
                Dim tagVal  As String
                chkName = "chkDiff_" & blockNum & "_" & colNum
                ' Tagに「シート名|行番号|列番号|B値」を格納する
                tagVal  = m_SheetNames(m_CurrentSheet) & "|" & _
                          block.RowIndexA & "|" & _
                          dc.ColIndex & "|" & _
                          dc.ValB

                Set chk = fra.Controls.Add("Forms.CheckBox.1", chkName)
                With chk
                    .Caption   = "反映"
                    .Left      = colLeft
                    .Top       = innerTop + 60
                    .Width     = 140
                    .Height    = 18
                    .Font.Size = 9
                    .Tag       = tagVal
                    .Value     = False
                End With
                m_CheckBoxes.Add chk, chkName

                colLeft = colLeft + 148
            Next ci

            ' Frameの高さを実際の内容に合わせて更新する
            fra.Height = innerTop + 88

        Case "Aのみ"
            ' Aにのみ存在する場合の警告表示
            fra.BackColor = COLOR_WARN
            Set lbl = fra.Controls.Add("Forms.Label.1", "lblStatus_" & blockNum)
            With lbl
                .Caption   = "Bには存在しない項番です（Aにのみ存在）。反映チェックなし。"
                .Left      = 8
                .Top       = innerTop
                .Width     = 720
                .Height    = 18
                .Font.Size = 9
                .ForeColor = RGB(150, 60, 0)
            End With
            fra.Height = innerTop + 28

        Case "Bのみ"
            ' Bにのみ存在する場合の警告表示
            fra.BackColor = COLOR_WARN
            Set lbl = fra.Controls.Add("Forms.Label.1", "lblStatus_" & blockNum)
            With lbl
                .Caption   = "Bにのみ存在する項番です（Aには存在しません）。初版：表示のみ。"
                .Left      = 8
                .Top       = innerTop
                .Width     = 720
                .Height    = 18
                .Font.Size = 9
                .ForeColor = RGB(150, 60, 0)
            End With
            fra.Height = innerTop + 28

        Case "重複あり"
            ' 重複がある場合の警告表示
            fra.BackColor = COLOR_WARN
            Set lbl = fra.Controls.Add("Forms.Label.1", "lblStatus_" & blockNum)
            With lbl
                .Caption   = "この項番は重複しています。目視で確認してください。反映チェックなし。"
                .Left      = 8
                .Top       = innerTop
                .Width     = 720
                .Height    = 18
                .Font.Size = 9
                .ForeColor = RGB(150, 60, 0)
            End With
            fra.Height = innerTop + 28

    End Select

    ' このブロックの下端位置を返す
    RenderDiffBlock = topPos + fra.Height
End Function

'--------------------------------------------------------------
' ClearFrameMain：fraMain内のコントロールを全削除する
'--------------------------------------------------------------
Private Sub ClearFrameMain()
    Dim ctrl       As MSForms.Control
    Dim ctrlNames() As String
    Dim i          As Long
    Dim count      As Long

    count = 0
    ReDim ctrlNames(1 To fraMain.Controls.Count + 1)

    For Each ctrl In fraMain.Controls
        count = count + 1
        ctrlNames(count) = ctrl.Name
    Next ctrl

    For i = 1 To count
        On Error Resume Next
        fraMain.Controls.Remove ctrlNames(i)
        On Error GoTo 0
    Next i

    Set m_CheckBoxes = New Collection
    fraMain.ScrollTop = 0
End Sub

'--------------------------------------------------------------
' AddNoDataLabel：差分なし時のメッセージを表示する
'--------------------------------------------------------------
Private Sub AddNoDataLabel()
    Dim lbl As MSForms.Label
    Set lbl = fraMain.Controls.Add("Forms.Label.1", "lblNoData")
    With lbl
        .Caption   = "このシートに差分はありませんでした。"
        .Left      = 20
        .Top       = 20
        .Width     = 700
        .Height    = 24
        .Font.Size = 11
        .ForeColor = RGB(100, 100, 100)
    End With
End Sub

'--------------------------------------------------------------
' UpdateNavigationButtons：前/次シートボタンの状態を更新する
'--------------------------------------------------------------
Private Sub UpdateNavigationButtons()
    btnPrevSheet.Enabled = (m_CurrentSheet > 1)
    btnNextSheet.Enabled = (m_CurrentSheet < m_SheetCount)
End Sub

'--------------------------------------------------------------
' btnCheckAll_Click：「すべて反映」ボタン
'--------------------------------------------------------------
Private Sub btnCheckAll_Click()
    Dim chk As MSForms.CheckBox
    For Each chk In m_CheckBoxes
        chk.Value = True
    Next chk
End Sub

'--------------------------------------------------------------
' btnUncheckAll_Click：「すべて外す」ボタン
'--------------------------------------------------------------
Private Sub btnUncheckAll_Click()
    Dim chk As MSForms.CheckBox
    For Each chk In m_CheckBoxes
        chk.Value = False
    Next chk
End Sub

'--------------------------------------------------------------
' btnPrevSheet_Click：「← 前のシート」ボタン
'--------------------------------------------------------------
Private Sub btnPrevSheet_Click()
    If m_CurrentSheet > 1 Then
        m_CurrentSheet = m_CurrentSheet - 1
        Call RenderCurrentSheet
    End If
End Sub

'--------------------------------------------------------------
' btnNextSheet_Click：「次のシート →」ボタン
'--------------------------------------------------------------
Private Sub btnNextSheet_Click()
    If m_CurrentSheet < m_SheetCount Then
        m_CurrentSheet = m_CurrentSheet + 1
        Call RenderCurrentSheet
    End If
End Sub

'--------------------------------------------------------------
' btnApply_Click：「反映して保存」ボタン
'--------------------------------------------------------------
Private Sub btnApply_Click()
    If Not ModUtil.ConfirmYesNo( _
        "チェックした差分をAファイルへ反映して保存します。よろしいですか？") Then
        Exit Sub
    End If

    Dim allItems() As ModApply.ApplyItem
    Dim itemCount  As Long
    allItems  = CollectCheckedItems()
    itemCount = 0

    On Error Resume Next
    itemCount = UBound(allItems) - LBound(allItems) + 1
    On Error GoTo 0

    If itemCount = 0 Then
        Call ModUtil.ShowError("反映するセルが選択されていません。" & vbCrLf & _
            "チェックボックスを入れてから「反映して保存」を押してください。")
        Exit Sub
    End If

    frmProgress.lblMessage.Caption = "反映処理中です。しばらくお待ちください..."
    frmProgress.lblDetail.Caption  = ""
    frmProgress.Show vbModeless
    DoEvents

    ' Aブックを書き込み可能な状態で開き直す
    Dim wbAWrite     As Workbook
    Dim originalName As String
    originalName = Dir(m_FilePathA)

    ' 読み取り専用で開いていたブックを一度閉じる
    Call ModFileIO.CloseWorkbook(m_WbA)

    Set wbAWrite = Workbooks.Open( _
        Filename:=m_FilePathA, _
        ReadOnly:=False, _
        UpdateLinks:=False)

    If wbAWrite Is Nothing Then
        Unload frmProgress
        Call ModUtil.ShowError("Aファイルを書き込み可能な状態で開けませんでした。")
        Exit Sub
    End If

    ' 全シート分の差分を反映する
    Call ModApply.ApplyAllSheets(wbAWrite, allItems)

    ' 出力フォルダへ保存する
    Dim savedPath As String
    savedPath = ModFileIO.SaveOutputFile( _
        wbAWrite, _
        ModConfig.GetFolderOut(), _
        originalName)

    ' ブックを閉じる
    Call ModFileIO.CloseWorkbook(wbAWrite)
    Call ModFileIO.CloseWorkbook(m_WbB)

    Unload frmProgress

    If savedPath <> "" Then
        Call ModUtil.ShowInfo("反映が完了しました。" & vbCrLf & vbCrLf & "保存先：" & savedPath)
        Unload Me
    End If
End Sub

'--------------------------------------------------------------
' CollectCheckedItems：チェック済みのApplyItemを収集して返す
'--------------------------------------------------------------
Private Function CollectCheckedItems() As ModApply.ApplyItem()
    Dim results() As ModApply.ApplyItem
    Dim count     As Long
    Dim chk       As MSForms.CheckBox
    Dim parts()   As String
    Dim item      As ModApply.ApplyItem

    count = 0
    ReDim results(1 To 500)

    For Each chk In m_CheckBoxes
        ' chkDiff_ プレフィックスの差分チェックのみ対象にする
        If Left(chk.Name, 8) = "chkDiff_" Then
            If chk.Value = True Then
                ' TagからApplyItemを生成する（書式：シート名|行番号|列番号|B値）
                parts = Split(chk.Tag, "|")
                If UBound(parts) >= 3 Then
                    count = count + 1
                    If count > UBound(results) Then
                        ReDim Preserve results(1 To UBound(results) + 100)
                    End If
                    item.SheetName = parts(0)
                    item.RowIndex  = CLng(parts(1))
                    item.ColIndex  = CLng(parts(2))
                    item.NewValue  = parts(3)
                    results(count) = item
                End If
            End If
        End If
    Next chk

    If count = 0 Then
        CollectCheckedItems = results
        Exit Function
    End If

    ReDim Preserve results(1 To count)
    CollectCheckedItems = results
End Function

'--------------------------------------------------------------
' btnClose_Click：「閉じる」ボタン
'--------------------------------------------------------------
Private Sub btnClose_Click()
    If ModUtil.ConfirmYesNo("レビュー画面を閉じます。反映されていない差分は破棄されます。よろしいですか？") Then
        Call ModFileIO.CloseWorkbook(m_WbA)
        Call ModFileIO.CloseWorkbook(m_WbB)
        Unload Me
    End If
End Sub

'--------------------------------------------------------------
' UserForm_QueryClose：×ボタンで閉じる際の処理
'--------------------------------------------------------------
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        Cancel = True
        Call btnClose_Click
    End If
End Sub
