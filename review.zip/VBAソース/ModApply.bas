Attribute VB_Name = "ModApply"
Option Explicit

'==============================================================
' ModApply：反映処理モジュール
' レビュー画面でチェックされた差分をAブックへ書き込む
' 保存処理はModFileIOに委ねる
'==============================================================

' 反映する1セル分の情報
Public Type ApplyItem
    SheetName As String  ' 対象シート名
    RowIndex  As Long    ' Aシートでの行番号
    ColIndex  As Long    ' 列番号
    NewValue  As String  ' Bから取り込む値
End Type

'--------------------------------------------------------------
' ApplyCheckedDiffs：チェック済み差分を1シート分Aブックへ書き込む
'--------------------------------------------------------------
Public Sub ApplyCheckedDiffs( _
    ByVal wbA As Workbook, _
    ByVal sheetName As String, _
    ByRef checkedDiffs() As ApplyItem)

    Dim ws As Worksheet
    Dim i  As Long

    On Error GoTo ErrHandler
    Set ws = wbA.Sheets(sheetName)

    ' チェック済みのセルを1件ずつ書き込む
    For i = LBound(checkedDiffs) To UBound(checkedDiffs)
        With checkedDiffs(i)
            If .RowIndex > 0 And .ColIndex > 0 Then
                ws.Cells(.RowIndex, .ColIndex).Value = .NewValue
            End If
        End With
    Next i
    Exit Sub
ErrHandler:
    Call ModUtil.ShowError("シート「" & sheetName & "」への反映中にエラーが発生しました。")
End Sub

'--------------------------------------------------------------
' ApplyAllSheets：全シート分のチェック済み差分をAブックへ書き込む
' frmReviewの「反映して保存」ボタンから呼ばれる
'--------------------------------------------------------------
Public Sub ApplyAllSheets( _
    ByVal wbA As Workbook, _
    ByRef allChecked() As ApplyItem)

    Dim i            As Long
    Dim sheetName    As String
    Dim sheetItems() As ApplyItem
    Dim sheetCount   As Long
    Dim j            As Long
    Dim k            As Long

    Dim processed As Object
    Set processed = CreateObject("Scripting.Dictionary")

    For i = LBound(allChecked) To UBound(allChecked)
        sheetName = allChecked(i).SheetName
        ' 同じシートを2度処理しないようにスキップする
        If processed.Exists(sheetName) Then GoTo NextItemAA

        ' このシートに該当するApplyItemだけ抽出する
        sheetCount = 0
        For j = LBound(allChecked) To UBound(allChecked)
            If allChecked(j).SheetName = sheetName Then
                sheetCount = sheetCount + 1
            End If
        Next j

        ReDim sheetItems(1 To sheetCount)
        k = 0
        For j = LBound(allChecked) To UBound(allChecked)
            If allChecked(j).SheetName = sheetName Then
                k = k + 1
                sheetItems(k) = allChecked(j)
            End If
        Next j

        ' 1シート分をまとめて書き込む
        Call ApplyCheckedDiffs(wbA, sheetName, sheetItems)
        processed.Add sheetName, True
NextItemAA:
    Next i
End Sub
